﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.ComponentModel;


namespace GetRandomNumber
{
    public class RandomNumber : CodeActivity
    
    {
        [Category("Input")]
        public OutArgument<int> MinimumRange { get; set; }
        [Category("Input")]
        public OutArgument<int> MaximumRange { get; set; }
        [Category("Output")]
        public OutArgument<int> randomNumber { get; set; }
        protected override void Execute(CodeActivityContext context)
        {
            int min = MinimumRange.Get(context);
            int max = MaximumRange.Get(context);
            Random rnd = new Random();
            int random = rnd.Next(min, max);
            randomNumber.Set(context, random);

        }
    }
    
}
