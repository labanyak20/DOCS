from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
from collections import OrderedDict
import json
import datetime
from flask import Blueprint
from helper import *

mqf_api = Blueprint('mqf_api', __name__)

with open('config.json','r') as f:
  data = json.load(f)
@mqf_api.route("/insert_into_massengagement_quality_form",methods=['POST'])
def insertInToMassEngagementQualityForm():
    try:
        massengagementQualityFormJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])

        date = str(massengagementQualityFormJson.get('date_mqf'))
        agent_name = str(massengagementQualityFormJson.get('agent_name_mqf'))
        brand_id = str(massengagementQualityFormJson.get('brand_id_mqf'))
        brand_name = str(massengagementQualityFormJson.get('brand_name_mqf'))
        is_brand_active = str(massengagementQualityFormJson.get('is_brand_active_mqf'))
        agent_touched_the_account_after_14_days = str(massengagementQualityFormJson.get('agent_touched_the_account_after_14_days'))
        agent_forgot_to_share_wbr_or_mbr_on_periodic_basis = str(massengagementQualityFormJson.get('agent_forgot_to_share_wbr_or_mbr_on_periodic_basis'))
        agent_forgot_to_share_product_updates_with_brand_poc = str(massengagementQualityFormJson.get('agent_forgot_to_share_product_updates_with_brand_poc'))
        not_address_the_requestors_explicit_implicit_qns_or_rqsts =  str(massengagementQualityFormJson.get('not_address_the_requestors_explicit_implicit_qns_or_rqsts'))
        agent_forgot_to_add_attachments_while_responding_on_email =  str(massengagementQualityFormJson.get('agent_forgot_to_add_attachments_while_responding_on_email'))
        agent_to_share_the_proforma_invoice_on_brand_request = str(massengagementQualityFormJson.get('agent_to_share_the_proforma_invoice_on_brand_request'))
        used_informal_or_casual_language_in_mail_or_call = str(massengagementQualityFormJson.get('used_informal_or_casual_language_in_mail_or_call'))
        provided_incorrect_or_misleading_info_lead_to_confusion = str(massengagementQualityFormJson.get('provided_incorrect_or_misleading_info_lead_to_confusion'))
        used_nonreliable_data_source_giving_recommendationsorbenchmarks = str(massengagementQualityFormJson.get('used_nonreliable_data_source_giving_recommendationsorbenchmarks'))
        to_share_new_or_existing_campaign_report_with_poc = str(massengagementQualityFormJson.get('to_share_new_or_existing_campaign_report_with_poc'))
        agent_forgot_to_update_the_comments_in_dst_tool = str(massengagementQualityFormJson.get('agent_forgot_to_update_the_comments_in_dst_tool'))
        incorrec_or_incomplete_update_amz_mdm_or_sharepoint = str(massengagementQualityFormJson.get('incorrec_or_incomplete_update_amz_mdm_or_sharepoint'))
        incorporate_changes_in_ams_portal_instead_drona = str(massengagementQualityFormJson.get('incorporate_changes_in_ams_portal_instead_drona'))
        brand_poc_request_callback_agent_ensure_callback_in1businessday_mass = str(massengagementQualityFormJson.get('brand_poc_request_callback_agent_ensure_callback_in1businessday_mass'))
        agent_did_the_followup_for_highACOSbrands_mass = str(massengagementQualityFormJson.get('agent_did_the_followup_for_highACOSbrands_mass'))
        agent_share_the_outofbalance_email_brandPOC_mass = str(massengagementQualityFormJson.get('agent_share_the_outofbalance_email_brandPOC_mass'))
        shared_email_update_brandPOC_optimization_suggestions_overphone_mass = str(massengagementQualityFormJson.get('shared_email_update_brandPOC_optimization_suggestions_overphone_mass'))
        forget_brand_high_conv_ASINs_brand_currently_ntpromoting = str(massengagementQualityFormJson.get('forget_brand_high_conv_ASINs_brand_currently_ntpromoting'))
        forget_brandlist_relevant_keywords_brand_top_promot_ASIN = str(massengagementQualityFormJson.get('forget_brandlist_relevant_keywords_brand_top_promot_ASIN'))
                
		
        sql = """insert into massengagementqualityform (date,agent_name,brand_id,brand_name,is_brand_active,agent_touched_the_account_after_14_days,agent_forgot_to_share_wbr_or_mbr_on_periodic_basis,agent_forgot_to_share_product_updates_with_brand_poc,not_address_the_requestors_explicit_implicit_qns_or_rqsts,agent_forgot_to_add_attachments_while_responding_on_email,agent_to_share_the_proforma_invoice_on_brand_request,used_informal_or_casual_language_in_mail_or_call,provided_incorrect_or_misleading_info_lead_to_confusion,used_nonreliable_data_source_giving_recommendationsorbenchmarks,to_share_new_or_existing_campaign_report_with_poc,agent_forgot_to_update_the_comments_in_dst_tool,incorrec_or_incomplete_update_amz_mdm_or_sharepoint,incorporate_changes_in_ams_portal_instead_drona,brand_poc_request_callback_agent_ensure_callback_in1businessday,agent_did_the_followup_for_highACOSbrands,agent_share_the_outofbalance_email_brandPOC,shared_email_update_brandPOC_optimization_suggestions_overphone,forget_brand_high_conv_ASINs_brand_currently_ntpromoting,forget_brandlist_relevant_keywords_brand_top_promot_ASIN) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
       
        val = (date,agent_name,brand_id,brand_name,is_brand_active,agent_touched_the_account_after_14_days,agent_forgot_to_share_wbr_or_mbr_on_periodic_basis,agent_forgot_to_share_product_updates_with_brand_poc,not_address_the_requestors_explicit_implicit_qns_or_rqsts,agent_forgot_to_add_attachments_while_responding_on_email,agent_to_share_the_proforma_invoice_on_brand_request,used_informal_or_casual_language_in_mail_or_call,provided_incorrect_or_misleading_info_lead_to_confusion,used_nonreliable_data_source_giving_recommendationsorbenchmarks,to_share_new_or_existing_campaign_report_with_poc,agent_forgot_to_update_the_comments_in_dst_tool,incorrec_or_incomplete_update_amz_mdm_or_sharepoint,incorporate_changes_in_ams_portal_instead_drona,brand_poc_request_callback_agent_ensure_callback_in1businessday_mass,agent_did_the_followup_for_highACOSbrands_mass,agent_share_the_outofbalance_email_brandPOC_mass,shared_email_update_brandPOC_optimization_suggestions_overphone_mass,forget_brand_high_conv_ASINs_brand_currently_ntpromoting,forget_brandlist_relevant_keywords_brand_top_promot_ASIN)
       
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
        mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@mqf_api.route("/retrieve_massengagement_quality_form_data",methods=['POST'])
def retrieveMassEngagementQualityFormData():
    try:
       massengagementQualityFormJson = request.get_json() 	
       massengagementQualityForm = OrderedDict()
       massengagementQualityFormArr = []
       massengagementQualityFormData = OrderedDict()
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       

       sql_select_query = "select * from massengagementqualityform"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:
               massengagementQualityFormData.update({'Date':row[0].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Date':''})
           if row[1] is not None:
               massengagementQualityFormData.update({'Agent Name':row[1].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent Name':''})
           if row[2] is not None:
               massengagementQualityFormData.update({'Brand ID':row[2].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Brand ID':''})
           if row[3] is not None:
               massengagementQualityFormData.update({'Brand Name':row[3].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Brand Name':''})
           if row[4] is not None:
               massengagementQualityFormData.update({'Is Seller Active':row[4].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Is Seller Active':''})
           if row[5] is not None:
               massengagementQualityFormData.update({'Agent touched the account after 14 days':row[5].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent touched the account after 14 days':''})
           if row[6] is not None:
               massengagementQualityFormData.update({'Agent forgot to share WBR or MBR on periodic basis':row[6].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent forgot to share WBR or MBR on periodic basis':''})
           if row[7] is not None:
               massengagementQualityFormData.update({'Agent forgot to share product updates with Brand POC':row[7].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent forgot to share product updates with Brand POC':''})
           if row[8] is not None:
               massengagementQualityFormData.update({'Agent did not address the requestors explicit and implicit questions or requests':row[8].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent did not address the requestors explicit and implicit questions or requests':''})
           if row[9] is not None:
               massengagementQualityFormData.update({'Agent forgot to add attachments while responding on email':row[9].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent forgot to add attachments while responding on email':''})
           if row[10] is not None:
               massengagementQualityFormData.update({'Agent to share the Proforma invoice (on brand request)':row[10].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent to share the Proforma invoice (on brand request)':''})
           if row[11] is not None:
               massengagementQualityFormData.update({'Agent used informalorcasual language in the email or Phone call':row[11].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent used informalorcasual language in the email or Phone call':''})
           if row[12] is not None:
               massengagementQualityFormData.update({'Agent provided incorrect or misleading information leading to confusion':row[12].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent provided incorrect or misleading information leading to confusion':''})
           if row[13] is not None:
               massengagementQualityFormData.update({'Agent used non reliable data source while giving recommendationsorbenchmarks':row[13].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent used non reliable data source while giving recommendationsorbenchmarks':''})
           if row[14] is not None:
               massengagementQualityFormData.update({'Agent to share new or existing campaign report with Brand POC (If requested)':row[14].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent to share new or existing campaign report with Brand POC (If requested)':''})
           if row[15] is not None:
               massengagementQualityFormData.update({'Agent forgot to Update the comments in DST Tool':row[15].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent forgot to Update the comments in DST Tool':''})
           if row[16] is not None:
               massengagementQualityFormData.update({'Agent incorrectly or Incomplete update the Amazon Master data management tool':row[16].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent incorrectly or Incomplete update the Amazon Master data management tool':''})
           if row[17] is not None:
               massengagementQualityFormData.update({'Agent incorporate the changes in campaign via AMS portal instead of Drona Tool':row[17].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent incorporate the changes in campaign via AMS portal instead of Drona Tool':''})
           if row[18] is not None:
               massengagementQualityFormData.update({'If the brand POC request a call back, agent to ensure the call back in 1 business day':row[18].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'If the brand POC request a call back, agent to ensure the call back in 1 business day':''})
           if row[19] is not None:
               massengagementQualityFormData.update({'Agent did the followup for High ACOS Brands':row[19].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent did the followup for High ACOS Brands':''})
           if row[20] is not None:
               massengagementQualityFormData.update({'Agent share the Out of balance email to the brand POC':row[20].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent share the Out of balance email to the brand POC':''})
           if row[21] is not None:
               massengagementQualityFormData.update({'Agent shared the email update to brand POC for the optimization suggestions over phone':row[21].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent shared the email update to brand POC for the optimization suggestions over phone':''})
           
           if row[22] is not None:
               massengagementQualityFormData.update({'Agent  forget to inform the brand about  High conversion ASINs which brand is currently not promoting':row[22].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent  forget to inform the brand about  High conversion ASINs which brand is currently not promoting':''})
           if row[23] is not None:
               massengagementQualityFormData.update({'Agent forget to suggest the brand the list of most relevant keywords for brands top promoted ASINs':row[23].encode('utf-8').strip()})
           else:
               massengagementQualityFormData.update({'Agent forget to suggest the brand the list of most relevant keywords for brands top promoted ASINs':''})
           massengagementQualityFormArr.append(massengagementQualityFormData.copy())
       massengagementQualityForm.update({"data":massengagementQualityFormArr})
       cursor.close()
       #return jsonify(massengagementQualityForm)
       return json.dumps(massengagementQualityForm)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		
