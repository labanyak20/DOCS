from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
from collections import OrderedDict
import json
import datetime
from flask import Blueprint
from helper import *

sqf_api = Blueprint('sqf_api', __name__)

with open('config.json','r') as f:
  data = json.load(f)
@sqf_api.route("/insert_into_selleradvertising_quality_form",methods=['POST'])
def insertInToSellerAdvertisingQualityForm():
    try:
        selleradvertisingQualityFormJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])

        date = str(selleradvertisingQualityFormJson.get('date_sqf'))
        agent_name = str(selleradvertisingQualityFormJson.get('agent_name_sqf'))
        brand_id = str(selleradvertisingQualityFormJson.get('brand_id_sqf'))
        brand_name = str(selleradvertisingQualityFormJson.get('brand_name_sqf'))
        is_brand_active = str(selleradvertisingQualityFormJson.get('is_brand_active_sqf'))
        brand_acos__is_greater_than_3_months_average_acos = str(selleradvertisingQualityFormJson.get('brand_acos_is_greater_than_3_months_average_acos_and_no_follow_up_from_agent_on_high_acos'))
        budget_under_over_utilized_nofollow = str(selleradvertisingQualityFormJson.get('brand_budget_is_under_or_over_utilized_and_agent_didnt_make_any_follow_up_modification_in_the_brand_campaigns'))
        agent_touched_the_account_after_14_days = str(selleradvertisingQualityFormJson.get('agent_touched_the_account_after_14_days'))
        no_active_sponsor_campaign_min_1inr_spend_week =  str(selleradvertisingQualityFormJson.get('brand_has_no_active_sponsored_brand_campaign_minimum_1_inr_spend_per_week_in_last_4_weeks'))
        forgot_to_share_wbr_or_mbr_on_periodic_basis =  str(selleradvertisingQualityFormJson.get('agent_forgot_to_share_wbr_mbr_on_periodic_basis'))
        accountmanager_disucss_impo_product_features = str(selleradvertisingQualityFormJson.get('account_manager_has_to_disucss_all_the_important_product_features_with_brands'))
        forgot_share_product_updates_brand_poc = str(selleradvertisingQualityFormJson.get('agent_forgot_to_share_product_updates_with_sellerpoc'))
        nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail = str(selleradvertisingQualityFormJson.get('agent_did_not_address_the_requestors_explicit_and_implicit_questions_or_requests'))
        not_use_the_clientorstandard_template_wherever_applicable = str(selleradvertisingQualityFormJson.get('agent_did_not_use_the_clientstandard_template_wherever_applicable'))
        agent_forgot_to_add_attachments_while_responding_on_email = str(selleradvertisingQualityFormJson.get('agent_forgot_to_add_attachments_while_responding_on_email'))
        no_factor_advertiser_restrictions = str(selleradvertisingQualityFormJson.get('agent_did_not_factor_in_the_advertiser_restrictions_wherever_applicable_moderation_policy'))
        used_informal_or_casual_language_in_email_or_call = str(selleradvertisingQualityFormJson.get('agent_used_informalcasual_language_in_the_email_phone_call'))
        provided_incorrect_or_misleading_info_lead_to_confusion = str(selleradvertisingQualityFormJson.get('agent_provided_incorrect_or_misleading_information_leading_to_confusion'))
        used_nonreliable_data_source_giving_recommendations = str(selleradvertisingQualityFormJson.get('agent_used_non_reliable_data_source_while_giving_recommendationsbenchmarks'))
        ensure_all_mails_toresponded_in1business_day = str(selleradvertisingQualityFormJson.get('agent_to_ensure_all_the_emails_to_be_responded_in_1_business_day_if_a_seller_is_requesting_a_call_back_agent_to_ensure_call_the_seller_poc_in_1_business_day'))
        follow_optimization_or_seller_request_within_1busday = str(selleradvertisingQualityFormJson.get('agent_followed_the_optimization_seller_request_with_in_1_business_day_complete_the_action_item_in_the_duration'))
        toshare_new_or_existing_campaign_report_with_seller_poc = str(selleradvertisingQualityFormJson.get('agent_to_share_new_existing_campaign_report_with_seller_poc_if_requested'))
        agent_forgot_to_update_the_comments_in_dst_tool = str(selleradvertisingQualityFormJson.get('agent_forgot_to_update_the_comments_in_dst_tool'))
        incorrec_or_incomplete_update_amz_mdm_or_sharepoint = str(selleradvertisingQualityFormJson.get('agent_incorrectly_incomplete_update_the_amazon_mdm_scheduler_on_amz_share_point'))
        incorporate_changes_in_ams_portal_instead_drona = str(selleradvertisingQualityFormJson.get('agent_incorporate_the_changes_in_campaign_via_ams_portal_instead_of_drona_tool'))
        
		
        sql = """insert into selleradvertisingqualityform (date,agent_name,brand_id,brand_name,is_brand_active,brand_acos__is_greater_than_3_months_average_acos,budget_under_over_utilized_nofollow,agent_touched_the_account_after_14_days,no_active_sponsor_campaign_min_1inr_spend_week,forgot_to_share_wbr_or_mbr_on_periodic_basis,accountmanager_disucss_impo_product_features,forgot_share_product_updates_brand_poc,nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail,not_use_the_clientorstandard_template_wherever_applicable,agent_forgot_to_add_attachments_while_responding_on_email,no_factor_advertiser_restrictions,used_informal_or_casual_language_in_email_or_call,provided_incorrect_or_misleading_info_lead_to_confusion,used_nonreliable_data_source_giving_recommendations,ensure_all_mails_toresponded_in1business_day,follow_optimization_or_seller_request_within_1busday,toshare_new_or_existing_campaign_report_with_seller_poc,agent_forgot_to_update_the_comments_in_dst_tool,incorrec_or_incomplete_update_amz_mdm_or_sharepoint,incorporate_changes_in_ams_portal_instead_drona) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
       
        val = (date,agent_name,brand_id,brand_name,is_brand_active,brand_acos__is_greater_than_3_months_average_acos,budget_under_over_utilized_nofollow,agent_touched_the_account_after_14_days,no_active_sponsor_campaign_min_1inr_spend_week,forgot_to_share_wbr_or_mbr_on_periodic_basis,accountmanager_disucss_impo_product_features,forgot_share_product_updates_brand_poc,nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail,not_use_the_clientorstandard_template_wherever_applicable,agent_forgot_to_add_attachments_while_responding_on_email,no_factor_advertiser_restrictions,used_informal_or_casual_language_in_email_or_call,provided_incorrect_or_misleading_info_lead_to_confusion,used_nonreliable_data_source_giving_recommendations,ensure_all_mails_toresponded_in1business_day,follow_optimization_or_seller_request_within_1busday,toshare_new_or_existing_campaign_report_with_seller_poc,agent_forgot_to_update_the_comments_in_dst_tool,incorrec_or_incomplete_update_amz_mdm_or_sharepoint,incorporate_changes_in_ams_portal_instead_drona)
       
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
        mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@sqf_api.route("/retrieve_selleradvertising_quality_form_data",methods=['POST'])
def retrievedevelopmentQualityFormData():
    try:
       selleradvertisingQualityFormJson = request.get_json() 	
       selleradvertisingQualityForm = OrderedDict()
       selleradvertisingQualityFormArr = []
       selleradvertisingQualityFormData = OrderedDict()
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       

       sql_select_query = "select * from selleradvertisingqualityform"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records: 
           selleradvertisingQualityFormData.update({'Date':row[0].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent Name':row[1].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Brand ID':row[2].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Brand Name':row[3].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Is Seller Active':row[4].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Brand ACoS%  is greater than 3 months average ACoS%, and No follow up from Agent on High ACoS%':row[5].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Brand budget is under or Over utilized and agent didnt make any follow up modification in the brand campaigns':row[6].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent touched the account after 14 days':row[7].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Brand has no active Sponsored Brand Campaign (minimum 1 INR spend per week, in last 4 weeks)':row[8].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent forgot to share WBR MBR on periodic basis':row[9].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Account manager has to disucss all the important product features with Brands':row[10].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent forgot to share product updates with SellerPOC':row[11].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent did not address the requestors explicit and implicit questions or requests':row[12].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent did not use the clientstandard template (wherever applicable)':row[13].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent forgot to add attachments while responding on email':row[14].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent did not factor in the advertiser restrictions, wherever applicable (Moderation Policy)':row[15].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent used informalcasual language in the email Phone call':row[16].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent provided incorrect or misleading information leading to confusion':row[17].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent used non reliable data source while giving recommendationsbenchmarks':row[18].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent to ensure all the emails to be responded in 1 business day, if a Seller is requesting a call back, agent to ensure call the Seller POC in 1 business day':row[19].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent followed the Optimization Seller request with in 1 business day (complete the action item in the duration)':row[20].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent to share new existing campaign report with Seller POC (If requested)':row[21].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent forgot to Update the comments in DST Tool':row[22].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent incorrectly Incomplete update the Amazon MDM Scheduler on AMZ Share point':row[23].encode('utf-8').strip()})
           selleradvertisingQualityFormData.update({'Agent incorporate the changes in campaign via AMS portal instead of Drona Tool':row[24].encode('utf-8').strip()})
           selleradvertisingQualityFormArr.append(selleradvertisingQualityFormData.copy())
       selleradvertisingQualityForm.update({"data":selleradvertisingQualityFormArr})
       cursor.close()
       #return jsonify(selleradvertisingQualityForm)
       return json.dumps(selleradvertisingQualityForm)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		
