$(document).ready(function(){
	
	var data;
	$('#horizontalform').hide();
    $('#brandstoreform').hide();
	$('#developmentform').hide();
	$('#selleradvertisingform').hide();
	$('#massengagementform').hide();
	
	$("#selectTeam").on("change",function (event) {
		if($('#selectTeam').val() === "Growth"){
			$('#horizontalform').show();
			$('#brandstoreform').hide();
			$('#developmentform').hide();
			$('#selleradvertisingform').hide();
			$('#massengagementform').hide();
		}else if($('#selectTeam').val() === "Brand Store"){
			$('#horizontalform').hide();
			$('#brandstoreform').show();
			$('#developmentform').hide();
			$('#selleradvertisingform').hide();
			$('#massengagementform').hide();
		}else if($('#selectTeam').val() === "Development"){	
			$('#horizontalform').hide();
			$('#brandstoreform').hide();
			$('#developmentform').show();
			$('#selleradvertisingform').hide();
			$('#massengagementform').hide();
		}else if($('#selectTeam').val() === "Seller Advertising"){	
			$('#horizontalform').hide();
			$('#brandstoreform').hide();
			$('#developmentform').hide();
			$('#selleradvertisingform').show();
			$('#massengagementform').hide();
		}else if($('#selectTeam').val() === "Mass Engagement"){	
			$('#horizontalform').hide();
			$('#brandstoreform').hide();
			$('#developmentform').hide();
			$('#selleradvertisingform').hide();
			$('#massengagementform').show();
		}
			
    });
	
	$.ajax({
		url: "static/csv/brands.csv",
		async: false,
		success: function (csvd) {
			csvd = csvd.replace(/\n|\r/g, ",");
			csvd = csvd.replace(/,,/g, ",");
			data = csvd.split(',');
		},
		dataType: "text",
		complete: function () {
			
		}
	});

	var brands = [];	
	for (var i = 0; i < data.length; i += 2) {
	  var val = {};
	  val[data[i]] = data[i + 1];
	  brands.push(val);
	}
	
	$("#brandid").on("change input",function (event) {		
		
		var key = $('#brandid').val();
		var value;
		if(typeof brands.find(b => key.indexOf(Object.keys(b)) > -1) !== 'undefined'){
			value = brands.find(b => key.indexOf(Object.keys(b)) > -1)[key];
			$("#brandname:text").val(value);
		}else{
			$("#brandname:text").val('');
		}
	});
	
	
	$("#post").click(function(){
		
		 event.preventDefault();
	
		 var siteurl = "https://amsjarvis.cognizant.com/insert_into_growth_quality_form"
		
		 var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		 currentDateTime = new Date(currentDateTime);
		
		 if($('#agentname').val() === ""){
			alert("Please enter agent name");
			return false;
		 }
		 else if($('#brandid').val() === ""){
			alert("Please enter Brand ID");
			return false;
		 }
		 else if($('#brandname').val() === ""){
			alert("Please enter brand name");
			return false;
		 }
		 else if($('#isbrandactive').val() === "" || $('#nofollowupfromagentonhighacos').val() === "" || $('#brandbudgetisunderutilized').val() === "" || $('#agenttouchedtheaccountafterfourteendays').val() === "" || $('#brandhasnoactivesponsoredbrandcampaign').val() === "" || $('#agentforgottosharewbrmbr').val() === "" || $('#agentforgottoshareproductupdates').val() === "" || $('#accountmanagerdiscussimportantproductfeatures').val() === "" || $('#agenttoensurepacingofbudget').val() === "" || $('#campaignmanagersdoesmonthlybudgetalignment').val() === "" || $('#agentincorrectlyupdatedamazonmdmtool').val() === "" || $('#agentdidnotfollowedtheoutofbalancesop').val() === ""){
			alert("Please select required fields");
			return false;
		 }
		 else { 
			var data = {
				"date": currentDateTime.toString('yyyy-MM-dd'),
				"agent_name": $('#agentname').val(),
				"brand_id": $('#brandid').val(),
				"brand_name": $('#brandname').val(),
				"is_brand_active": $('#isbrandactive').val(),
				"no_follow_up_from_agent_on_high_acos": $('#nofollowupfromagentonhighacos').val(),
				"brand_budget_is_under_utilized": $('#brandbudgetisunderutilized').val(),
				"agent_touched_the_account_after_fourteen_days": $('#agenttouchedtheaccountafterfourteendays').val(),
				"campaign_managers_does_monthly_budget_alignment": $('#campaignmanagersdoesmonthlybudgetalignment').val(),
				"brand_has_no_active_sponsored_brand_campaign": $('#brandhasnoactivesponsoredbrandcampaign').val(),
				"agent_forgot_to_share_wbr_or_mbr": $('#agentforgottosharewbrmbr').val(),
				"account_manager_discuss_important_product_features": $('#accountmanagerdiscussimportantproductfeatures').val(),
				"agent_to_ensure_pacing_of_budget": $('#agenttoensurepacingofbudget').val(),
				"agent_forgot_to_share_product_updates_with_brand_poc": $('#agentforgottoshareproductupdates').val(),
				"agent_didnot_address_the_requestors_questions": $('#addresstherequestorsexplicitandimplicitquestions').val(),
				"agent_used_informal_language_in_the_email": $('#agentusedinformallanguageintheemail').val(),
				"agent_didnot_use_the_client_template": $('#agentdidnotusetheclienttemplate').val(),
				"agent_forgot_to_add_attachments_while_responding_on_email": $('#agentforgottoaddattachmentsonemail').val(),
				"agent_to_share_the_proforma_invoice": $('#agenttosharetheproformainvoice').val(),
				"agent_didnot_followed_the_out_of_balance_sop": $('#agentdidnotfollowedtheoutofbalancesop').val(),
				"agent_didnot_factor_in_the_advertiser_restrictions": $('#agentdidnotfactorintheadvertiserrestrictions').val(),
				"agent_used_informal_language_in_email_or_phone": $('#agentusedinformallanguageinemailphone').val(),
				"agent_provided_incorrect_information": $('#agentprovidedincorrectinformation').val(),
				"agent_used_non_reliable_data_source_while_giving_recommendations": $('#agentusednonreliabledatasource').val(),
				"agent_to_ensure_all_the_emails_to_be_responded": $('#agenttoensurealltheemailstoberesponded').val(),
				"agent_followed_the_brand_request": $('#agentfollowedthebrandrequest').val(),
				"agent_to_share_new_or_existing_campaign_report": $('#agenttosharecampaignreport').val(),
				"agent_forgot_to_update_comments_in_dst": $('#agentforgottoupdatecomments').val(),
				"agent_incorrectly_updated_amazon_mdm_tool": $('#agentincorrectlyupdatedamazonmdmtool').val(),
				"agent_forgot_to_update_oob_tracker": $('#agentforgottoupdateoob').val(),
				"agent_changes_campaign_via_ams_portal_instead_of_drona": $('#agentchangescampaignviaamsportalinsteadofdrona').val(),
				"agent_incorrectlyorincomplete_update_amz_mdmtool": $('#agentincorrectlyorincompleteupdatetheamazonmasterdatamanagementtool').val(),
				"agent_not_followed_oob_porprocedure": $('#agentdidnotfollowedtheoutofbalancesoporprocedure').val()
				
			};
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Quality form response recorded successfully");
					location.reload();					
				},
				error: function (error) {
					alert("Error occured while recording quality form response. Please resubmit");
					location.reload();
				}
			});
		 }
	});
	
	$("#post_brandstore").click(function(){
		
		event.preventDefault();
	
		var siteurl = "https://amsjarvis.cognizant.com/insert_into_brandstore_quality_form"
		
		if($('#entrydate').val() === ""){
			alert("Please enter entry date");
			return false;
		}
		else if($('#entityid').val() === ""){
			alert("Please enter entity id");
			return false;
		}
		else if($('#brandnamebrandstore').val() === ""){
			alert("Please enter brand name");
			return false;
		}
		else if($('#storesubmissiondate').val() === "" || $('#atleast2pagesunderhomepage').val() === "" || $('#atleast1productgridoneachpage').val() === "" || $('#use3differenttiletypesonhomepage').val() === "" || $('#top2widgetstobeclickable').val() === "" || $('#ctaonimagetilesifactionable').val() === "" || $('#useofmobileoptimizationfeatureforimagetiles').val() === ""){
			alert("Please select required fields");
			return false;
		}
		else if($('#rejectioncount').val() === ""){
			alert("Please enter rejection count");
			return false;
		}
		else { 
			var data = {
				"entry_date": $('#entrydate').val(),
				"entity_id": $('#entityid').val(),
				"brand_name_brandstore": $('#brandnamebrandstore').val(),
				"store_submission_date": $('#storesubmissiondate').val(),
				"atleast_2_pages_under_home_page": $('#atleast2pagesunderhomepage').val(),
				"atleast_1_product_grid_on_each_page": $('#atleast1productgridoneachpage').val(),
				"use_3_different_tile_types_on_home_page": $('#use3differenttiletypesonhomepage').val(),
				"top_2_widgets_to_be_clickable": $('#top2widgetstobeclickable').val(),
				"cta_on_image_tiles_if_actionable": $('#ctaonimagetilesifactionable').val(),
				"use_of_mobile_optimization_feature_for_image_tiles": $('#useofmobileoptimizationfeatureforimagetiles').val(),
				"rejection_count": $('#rejectioncount').val(),
				};
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Brand Store Quality form response recorded successfully");
					location.reload();					
				},
				error: function (error) {
					alert("Error occured while recording quality form response. Please resubmit");
					location.reload();
				}
			});
		}
    });
	
	$("#post_development").click(function(){
		
		 event.preventDefault();
	
		 var siteurl = "https://amsjarvis.cognizant.com/insert_into_developement_quality_form"
		
		 var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		 currentDateTime = new Date(currentDateTime);
		
		 if($('#agentnamedqf').val() === ""){
			alert("Please enter agent name");
			return false;
		 }
		 else if($('#brandiddqf').val() === ""){
			alert("Please enter Brand ID");
			return false;
		 }
		 else if($('#brandnamedqf').val() === ""){
			alert("Please enter brand name");
			return false;
		 }
		 else if($('#isbrandactivedqf').val() === "" || $('#15kspentinm0m2period').val() === "" || $('#creationofspmanual').val() === "" || $('#20+Keywords').val() === "" || $('#lmsquiz').val() === "" || $('#touchedaccountafter14days').val() === "" || $('#noactivesponsorcamp1inrspendperweeklast4week').val() === "" || $('#forgottosharewbrormbrperiodicbasis').val() === "" || $('#forgotshareproductupdatesbrandpoc').val() === "" || $('#ntaddrsrqstsexplicitimplicitqnsrqstsmail').val() === "" || $('#ntfollowedoobsopprocedure').val() === "" || $('#incorrectincompleteupdateamazonmdm').val() === ""){
			alert("Please select required fields");
			return false;
		 }
		 else { 
			var data = {
				"date_dqf": currentDateTime.toString('yyyy-MM-dd'),
				"agent_name_dqf": $('#agentnamedqf').val(),
				"brand_id_dqf": $('#brandiddqf').val(),
				"brand_name_dqf": $('#brandnamedqf').val(),
				"is_brand_active_dqf": $('#isbrandactivedqf').val(),
				"15k_spent_in_m0m2_period": $('#15kspentinm0m2period').val(),
				"creation_of_sp_manual": $('#creationofspmanual').val(),
				"20_keywords": $('#20+Keywords').val(),
				"lms_quiz": $('#lmsquiz').val(),
				"touched_account_after_14_days": $('#touchedaccountafter14days').val(),
				"no_active_sponsor_camp_1inrspend_perweeklast4week": $('#noactivesponsorcamp1inrspendperweeklast4week').val(),
				"forgot_to_share_wbr_mbr_periodic_basis": $('#forgottosharewbrormbrperiodicbasis').val(),
				"forgot_share_product_updates_brand_poc": $('#forgotshareproductupdatesbrandpoc').val(),
				"nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail": $('#ntaddrsrqstsexplicitimplicitqnsrqstsmail').val(),
				"used_informal_casual_language_inmail": $('#usedinformalcasuallanguageinmail').val(),
				"nt_use_client_stndrd_templt_applicable": $('#ntuseclientstndrdtempltapplicable').val(),
				"forgot_to_add_attmts_responding_onmail": $('#forgottoaddattmtsrespondingonmail').val(),
				"share_proforma_invoice_on_brand_request": $('#shareproformainvoiceonbrandrequest').val(),
				"nt_followed_oob_sop_procedure": $('#ntfollowedoobsopprocedure').val(),
				"nt_fctr_in_advertiser_restns_applicable_policy": $('#ntfctrinadvertiserrestnsapplicablepolicy').val(),
				"nt_addrs_rqsts_explicit_implicit_qns_rqsts": $('#ntaddrsrqstsexplicitimplicitqnsrqsts').val(),
				"used_informal_language_inmail_phone": $('#usedinformallanguageinmailphone').val(),
				"incorct_mislead_informn_lead_confusion": $('#incorctmisleadinformnleadconfusion').val(),
				"nonreliable_datasource_giving_recommendation_benchmark": $('#nonreliabledatasourcegivingrecommendationbenchmark').val(),
				"share_newexisting_campaign_report_with_brand_poc": $('#sharenewexistingcampaignreportwithbrandpoc').val(),
				"forgot_toupdate_comments_dsttool": $('#forgottoupdatecommentsdsttool').val(),
				"incorrect_incomplete_update_amazon_mdm": $('#incorrectincompleteupdateamazonmdm').val(),
				"forgot_to_update_the_oob_tracker": $('#forgottoupdatetheoobtracker').val(),
				"incorporate_changes_in_ams_portal_instead_drona": $('#incorporatechangesinamsportalinsteaddrona').val(),
				"agent_incorrectly_incomplete_update_amazon_MDM": $('#agentincorrectlyorincompleteupdatetheamazonmasterdatamanagement').val(),
				"agent_didnot_followed_oob_SOP_procedure": $('#agentdidnotfollowedtheoutofbalanceSOPorprocedure').val(),
				"agent_did_followup_for_high_ACOS_brands": $('#agentdidthefollowupforhighACOSbrands').val(),
				
			};
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Quality form response recorded successfully");
					location.reload();					
				},
				error: function (error) {
					alert("Error occured while recording quality form response. Please resubmit");
					location.reload();
				}
			});
		 }
	});
	
	$("#post_selleradvertising").click(function(){
		
		 event.preventDefault();
	
		 var siteurl = "https://amsjarvis.cognizant.com/insert_into_selleradvertising_quality_form"
		
		 var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		 currentDateTime = new Date(currentDateTime);
		
		 if($('#agentnamesqf').val() === ""){
			alert("Please enter agent name");
			return false;
		 }
		 else if($('#brandidsqf').val() === ""){
			alert("Please enter Brand ID");
			return false;
		 }
		 else if($('#brandnamesqf').val() === ""){
			alert("Please enter brand name");
			return false;
		 }
		 else if($('#isbrandactivesqf').val() === "" || $('#brandacosisgreaterthan3monthsaverageacosandnofollowupfromagentonhighacos').val() === "" || $('#brandbudgetisunderoroverutilizedandagentdidntmakeanyfollowupmodificationinthebrandcampaigns').val() === "" || $('#agenttouchedtheaccountafter14days').val() === "" || $('#brandhasnoactivesponsoredbrandcampaignminimum1inrspendperweekinlast4weeks').val() === "" || $('#agentforgottosharewbrmbronperiodicbasis').val() === "" || $('#accountmanagerhastodisucssalltheimportantproductfeatureswithbrands').val() === "" || $('#agentforgottoshareproductupdateswithsellerpoc').val() === "" || $('#agentdidnotaddresstherequestorsexplicitandimplicitquestionsorrequests').val() === "" || $('#agentdidnotusetheclientstandardtemplatewhereverapplicable').val() === ""){
			alert("Please select required fields");
			return false;
		 }
		 else { 
			var data = {
				"date_sqf": currentDateTime.toString('yyyy-MM-dd'),
				"agent_name_sqf": $('#agentnamesqf').val(),
				"brand_id_sqf": $('#brandidsqf').val(),
				"brand_name_sqf": $('#brandnamesqf').val(),
				"is_brand_active_sqf": $('#isbrandactivesqf').val(),
				"brand_acos_is_greater_than_3_months_average_acos_and_no_follow_up_from_agent_on_high_acos": $('#brandacosisgreaterthan3monthsaverageacosandnofollowupfromagentonhighacos').val(),
	        	"brand_budget_is_under_or_over_utilized_and_agent_didnt_make_any_follow_up_modification_in_the_brand_campaigns": $('#brandbudgetisunderoroverutilizedandagentdidntmakeanyfollowupmodificationinthebrandcampaigns').val(),
				"agent_touched_the_account_after_14_days": $('#agenttouchedtheaccountafter14days').val(),
				"brand_has_no_active_sponsored_brand_campaign_minimum_1_inr_spend_per_week_in_last_4_weeks": $('#brandhasnoactivesponsoredbrandcampaignminimum1inrspendperweekinlast4weeks').val(),
				"agent_forgot_to_share_wbr_mbr_on_periodic_basis": $('#agentforgottosharewbrmbronperiodicbasis').val(),
				"account_manager_has_to_disucss_all_the_important_product_features_with_brands": $('#accountmanagerhastodisucssalltheimportantproductfeatureswithbrands').val(),
				"agent_forgot_to_share_product_updates_with_sellerpoc": $('#agentforgottoshareproductupdateswithsellerpoc').val(),
				"agent_did_not_address_the_requestors_explicit_and_implicit_questions_or_requests": $('#agentdidnotaddresstherequestorsexplicitandimplicitquestionsorrequests').val(),
				"agent_did_not_use_the_clientstandard_template_wherever_applicable": $('#agentdidnotusetheclientstandardtemplatewhereverapplicable').val(),
				"agent_forgot_to_add_attachments_while_responding_on_email": $('#agentforgottoaddattachmentswhilerespondingonemail').val(),
				"agent_did_not_factor_in_the_advertiser_restrictions_wherever_applicable_moderation_policy": $('#agentdidnotfactorintheadvertiserrestrictionswhereverapplicablemoderationpolicy').val(),
				"agent_used_informalcasual_language_in_the_email_phone_call": $('#agentusedinformalcasuallanguageintheemailphonecall').val(),
				"agent_provided_incorrect_or_misleading_information_leading_to_confusion": $('#agentprovidedincorrectormisleadinginformationleadingtoconfusion').val(),
				"agent_used_non_reliable_data_source_while_giving_recommendationsbenchmarks": $('#agentusednonreliabledatasourcewhilegivingrecommendationsbenchmarks').val(),
				"agent_to_ensure_all_the_emails_to_be_responded_in_1_business_day_if_a_seller_is_requesting_a_call_back_agent_to_ensure_call_the_seller_poc_in_1_business_day": $('#agenttoensurealltheemailstoberespondedin1businessdayifasellerisrequestingacallbackagenttoensurecallthesellerpocin1businessday').val(),
				"agent_followed_the_optimization_seller_request_with_in_1_business_day_complete_the_action_item_in_the_duration": $('#agentfollowedtheoptimizationsellerrequestwithin1businessdaycompletetheactionitemintheduration').val(),
				"agent_to_share_new_existing_campaign_report_with_seller_poc_if_requested": $('#agenttosharenewexistingcampaignreportwithsellerpocifrequested').val(),
				"agent_forgot_to_update_the_comments_in_dst_tool": $('#agentforgottoupdatethecommentsindsttool').val(),
				"agent_incorrectly_incomplete_update_the_amazon_mdm_scheduler_on_amz_share_point": $('#agentincorrectlyincompleteupdatetheamazonmdmscheduleronamzsharepoint').val(),
				"agent_incorporate_the_changes_in_campaign_via_ams_portal_instead_of_drona_tool": $('#agentincorporatethechangesincampaignviaamsportalinsteadofdronatool').val(),
				
			};
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Quality form response recorded successfully");
					location.reload();					
				},
				error: function (error) {
					alert("Error occured while recording quality form response. Please resubmit");
					location.reload();
				}
			});
		 }
	});
	
	$("#post_massengagement").click(function(){
		
		 event.preventDefault();
	
		 var siteurl = "https://amsjarvis.cognizant.com/insert_into_massengagement_quality_form"
		
		 var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		 currentDateTime = new Date(currentDateTime);
		
		 if($('#agent_name_mqf').val() === ""){
			alert("Please enter agent name");
			return false;
		 }
		 else if($('#brand_id_mqf').val() === ""){
			alert("Please enter Brand ID");
			return false;
		 }
		 else if($('#brand_name_mqf').val() === ""){
			alert("Please enter brand name");
			return false;
		 }
		 else if($('#is_brand_active_mqf').val() === "" || $('#agent_touched_the_account_after_14_days').val() === "" || $('#agent_forgot_to_share_wbr_or_mbr_on_periodic_basis').val() === "" || $('#agent_forgot_to_share_product_updates_with_brand_poc').val() === "" || $('#not_address_the_requestors_explicit_implicit_qns_or_rqsts').val() === "" || $('#used_informal_or_casual_language_in_mail_or_call').val() === "" || $('#provided_incorrect_or_misleading_info_lead_to_confusion').val() === "" || $('#used_nonreliable_data_source_giving_recommendationsorbenchmarks').val() === "" || $('#incorrec_or_incomplete_update_amz_mdm_or_sharepoint').val() === "" || $('#brand_poc_request_callback_agent_ensure_callback_in1businessday_mass').val() === "" || $('#shared_email_update_brandPOC_optimization_suggestions_overphone_mass').val() === ""){
			alert("Please select required fields");
			return false;
		 }
		 else { 
			var data = {
				"date_mqf": currentDateTime.toString('yyyy-MM-dd'),
				"agent_name_mqf": $('#agent_name_mqf').val(),
				"brand_id_mqf": $('#brand_id_mqf').val(),
				"brand_name_mqf": $('#brand_name_mqf').val(),
				"is_brand_active_mqf": $('#is_brand_active_mqf').val(),
				"agent_touched_the_account_after_14_days": $('#agent_touched_the_account_after_14_days').val(),
   	    "agent_forgot_to_share_wbr_or_mbr_on_periodic_basis": $('#agent_forgot_to_share_wbr_or_mbr_on_periodic_basis').val(),
				"agent_forgot_to_share_product_updates_with_brand_poc": $('#agent_forgot_to_share_product_updates_with_brand_poc').val(),
				"not_address_the_requestors_explicit_implicit_qns_or_rqsts": $('#not_address_the_requestors_explicit_implicit_qns_or_rqsts').val(),
				"agent_forgot_to_add_attachments_while_responding_on_email": $('#agent_forgot_to_add_attachments_while_responding_on_email').val(),
				"agent_to_share_the_proforma_invoice_on_brand_request": $('#agent_to_share_the_proforma_invoice_on_brand_request').val(),
				"used_informal_or_casual_language_in_mail_or_call": $('#used_informal_or_casual_language_in_mail_or_call').val(),
				"provided_incorrect_or_misleading_info_lead_to_confusion": $('#provided_incorrect_or_misleading_info_lead_to_confusion').val(),
				"used_nonreliable_data_source_giving_recommendationsorbenchmarks": $('#used_nonreliable_data_source_giving_recommendationsorbenchmarks').val(),
				"to_share_new_or_existing_campaign_report_with_poc": $('#to_share_new_or_existing_campaign_report_with_poc').val(),
				"agent_forgot_to_update_the_comments_in_dst_tool": $('#agent_forgot_to_update_the_comments_in_dst_tool').val(),
				"incorrec_or_incomplete_update_amz_mdm_or_sharepoint": $('#incorrec_or_incomplete_update_amz_mdm_or_sharepoint').val(),
				"incorporate_changes_in_ams_portal_instead_drona": $('#incorporate_changes_in_ams_portal_instead_drona').val(),
				"brand_poc_request_callback_agent_ensure_callback_in1businessday_mass": $('#brand_poc_request_callback_agent_ensure_callback_in1businessday_mass').val(),
				"agent_did_the_followup_for_highACOSbrands_mass": $('#agent_did_the_followup_for_highACOSbrands_mass').val(),
				"agent_share_the_outofbalance_email_brandPOC_mass": $('#agent_share_the_outofbalance_email_brandPOC_mass').val(),
				"shared_email_update_brandPOC_optimization_suggestions_overphone_mass": $('#shared_email_update_brandPOC_optimization_suggestions_overphone_mass').val(),
				//"incorrectly_incomplete_update_amazon_masterdatamanagement_tool_mass": $('#incorrectly_incomplete_update_amazon_masterdatamanagement_tool_mass').val(),
        "forget_brand_high_conv_ASINs_brand_currently_ntpromoting": $('#forget_brand_high_conv_ASINs_brand_currently_ntpromoting').val(),
				"forget_brandlist_relevant_keywords_brand_top_promot_ASIN": $('#forget_brandlist_relevant_keywords_brand_top_promot_ASIN').val()		
				
			};
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
        
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Quality form response recorded successfully");
					location.reload();					
				},
				error: function (error) {
					alert("Error occured while recording quality form response. Please resubmit");
					location.reload();
				}
			});
		 }
	});
	
	$("#get").click(function(){
		if($('#selectTeam').val() === "Growth"){
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_growth_quality_form_data"
			data = {};
		
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
                dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		}
		else if($('#selectTeam').val() === "Brand Store"){
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_brandstore_quality_form_data"
			data = {};
		
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
                dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		}
		else if($('#selectTeam').val() === "Development"){
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_development_quality_form_data"
			data = {};
		
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
                dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		}
		else if($('#selectTeam').val() === "Seller Advertising"){
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_selleradvertising_quality_form_data"
			data = {};
		
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
                dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		}
		else if($('#selectTeam').val() === "Mass Engagement"){
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_massengagement_quality_form_data"
			data = {};
		
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
                dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		}
		else{
			alert("Plese select a team.");
		}
	});
	
 /*function JSONToCSVConvertor(data, ShowLabel) {
	console.log(JSON.stringify(data));	
	var jsonDstData = JSON.stringify(data);
	var jsonObj = JSON.parse(jsonDstData);
	var JSONData = JSON.stringify(jsonObj.data);
	
    var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
    var CSV = '';
    if (ShowLabel) {
        var row = "";
        for (var index in arrData[0]) {
				    row += index + ',';
        }
        row = row.slice(0, -1);
        CSV += row + '\r\n';
    }

    for (var i = 0; i < arrData.length; i++) {
        var row = "";
        for (var index in arrData[i]) {	
				    row += '"' + arrData[i][index] + '",';
        }
        row.slice(0, row.length - 1);
        CSV += row + '\r\n';
    }

    if (CSV == '') {        
        alert("Invalid data");
        return;
    }   
    
    //Generate a file name
    if($('#selectTeam').val() === "Growth"){
		var fileName = "Growth_Quality_Form";
	}
	else if($('#selectTeam').val() === "Brand Store"){
		var fileName = "Brand_Store_Quality_Form";
	}
    var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
    var link = document.createElement("a");    
    link.href = uri;
    link.style = "visibility:hidden";
    link.download = fileName + ".csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}*/
function JSONToCSVConvertor(data, ShowLabel){

         var jsonDstData = JSON.stringify(data);
         var jsonObj = JSON.parse(jsonDstData);
	     var JSONData = JSON.stringify(jsonObj.data);
         var parseData = JSON.parse(JSONData);        
         /* create workbook & set props*/
         const wb = { SheetNames: [], Sheets: {} };
         wb.Props = {
                  Title: "Quality Form Data",
                  Author: "Unknown"
         };

         /*create sheet data & add to workbook*/
         var ws = XLSX.utils.json_to_sheet(parseData);
         var ws_name = "Quality Form Data";
         XLSX.utils.book_append_sheet(wb, ws, ws_name);
		 if($('#selectTeam').val() === "Growth"){
         XLSX.writeFile(wb, "Growth_Quality_Form.xlsx");
		 }
		 else if($('#selectTeam').val() === "Brand Store"){
		 XLSX.writeFile(wb, "Brand_Store_Quality_Form.xlsx");
		 }
		 else if($('#selectTeam').val() === "Development"){
		 XLSX.writeFile(wb, "Development_Quality_Form.xlsx");
		 }
		 else if($('#selectTeam').val() === "Seller Advertising"){
		 XLSX.writeFile(wb, "Seller_Advertising_Quality_Form.xlsx");
		 }
		 else if($('#selectTeam').val() === "Mass Engagement"){
		 XLSX.writeFile(wb, "Mass_Engagement_Quality_Form.xlsx");
		 }
}
});