$(document).ready(function(){
	
	$('#form-container').hide();
	$('#brandLaunchDate').hide();
	$('#brandRemovedDate').hide();
	$('#brandreallocationdate').hide();
	$('#brandaccessfrombrandPOC').hide();
	$('#case_notes1').hide();
	$('#case_notes2').hide();
	$('#case_notes3').hide();
	$('#case_notes4').hide();
	$('#portfolionumberofsubbrands').hide();
	$('#portfoliosubbrandname').hide();
	//$('#exportData').hide();
	
	$('#addNewBrand').click(function(){
		$("#horizontalform").trigger("reset");
		$("#brandid").prop("readonly", false);
		$("#brandname").prop("readonly", false);
		$("#category").prop("disabled", false);
		$("#allocationDateToCTS").prop("disabled", false);
		$("#accessFromBrandPOC").prop("disabled", false);
		$("#changesIncorporationInBrand").prop("disabled", false);
		$('#form-container').show();
		$("#submit_brand").show();
	});
 
 
 	var searchBrand = document.getElementById("searchBrandId");
	searchBrand.addEventListener("keyup", function(event) {
  		if (event.keyCode === 13) {
   			event.preventDefault();
   			document.getElementById("modifyBrand").click();
  		}
	});
 
 	$(function(){
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		if(month < 10)
			month = '0' + month.toString();
		if(day < 10)
			day = '0' + day.toString();
		maxDate = year + '-' + month + '-' + day;		
		$('#allocationDateToCTS').attr('max', maxDate);
		$('#launchDate').attr('max', maxDate);
		$('#accessFromBrandPOC').attr('max', maxDate);
		$('#changesIncorporationInBrand').attr('max', maxDate);
		$('#removedDate').attr('max', maxDate);
	});
	
	//adding and removing sub brand names function
	
	var max_fields      = 50;
	var wrapper         = $(".input_fields_wrap"); 
	var add_button      = $("#add_field_button");
	var remove_button   = $("#remove_field_button");

	$(add_button).click(function(){
		var total_fields = wrapper[0].childNodes.length;
		if(total_fields < max_fields){
			$(wrapper).append('<input type="text" class="form-control subbrandname" placeholder="Sub Brand Name" name="subbrandname"/>');
		}
	});
	$(remove_button).click(function(){ 
		var total_fields = wrapper[0].childNodes.length;
		if(total_fields>1){
			wrapper[0].childNodes[total_fields-1].remove();
		}
	});
	//----------------------------------------------
	
	var pexNameData;
	$.ajax({
		url: "https://amsjarvis.cognizant.com/retrieve_associate_name",
		type: "POST",
		data: {},
		headers: {
		         "Accept": "application/json",
					   "Content-Type": "application/json"
		},
		success: function (associatename) {        
		         window.sessionStorage.setItem("associatename", associatename.toString());
				 console.log(associatename);
		},
		error: function (error) {
					alert('Not able to fetch associate name. Please log out and log in again!!');            
		}
	});
	$.ajax({
		url: "static/csv/pexteam.csv",
		async: false,
		dataType: "text",
		success: function (csvd) {
			pexNameData = data = csvd.split('\n');
		},
		complete: function () {
			for(var i = 0; i < pexNameData.length; i++) {
				associateName = window.sessionStorage.getItem("associatename");
				//console.log(pexNameData[i].toString());
				//console.log(associateName.toString());
				if(pexNameData[i].toString().trim() !== associateName.toString().trim()){
					//console.log('if');
					document.getElementById("exportData").disabled = true;
					$('#retrieveBrandCategory').prop("disabled", true);
					$('.filterSubCategory').prop("disabled", true);
				}
				else if(pexNameData[i].toString().trim() === associateName.toString().trim()){
					document.getElementById("exportData").disabled = false;
					$('#retrieveBrandCategory').prop("disabled", false);
					$('.filterSubCategory').prop("disabled", false);
					//console.log('else');
					break;
				}
			}
		}
	});
	
	$.ajax({
		url: "static/csv/brands.csv",
		async: false,
		success: function (csvd) {
			csvd = csvd.replace(/\n|\r/g, ",");
			csvd = csvd.replace(/,,/g, ",");
			data = csvd.split(',');
		},
		dataType: "text",
		complete: function () {
			
		}
	});

	var brands = [];	
	for (var i = 0; i < data.length; i += 2) {
	  var val = {};
	  val[data[i]] = data[i + 1];
	  brands.push(val);
	}
	
	$("#brandid").on("change input",function (event) {		
		
		var key = $('#brandid').val();
		var value;
		if(typeof brands.find(b => key.indexOf(Object.keys(b)) > -1) !== 'undefined'){
			value = brands.find(b => key.indexOf(Object.keys(b)) > -1)[key];
			$("#brandname:text").val(value);
		}else{
			$("#brandname:text").val('');
		}
    
     var brandId = {"brand_id":$('#brandid').val()} 
      $.ajax({
				url: "https://amsjarvis.cognizant.com/check_brand_id",
				type: "POST",
				data: JSON.stringify(brandId),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
             if(data !== ""){
                  alert(data);
                  location.reload();
             }   
				},
				error: function (error) {
             location.reload();
				}
		  });   
   
	});

	$("#teamname").on("change",function (event) {
		if($('#teamname').val() === "Development"){
			$('#brandLaunchDate').show();
		}else{
			$('#brandLaunchDate').hide();
		}
		console.log(window.sessionStorage.getItem("team_name"));
		console.log($('#teamname').val());
		if(window.sessionStorage.getItem("team_name") === $('#teamname').val()){
			$("#accessFromBrandPOC").prop("disabled", true);
		}else{
			$("#accessFromBrandPOC").prop("disabled", false);
		}		
    	});
		
	$("#accessgiven").on("change",function (event) {
		if($('#accessgiven').val() === "Yes"){
			$('#brandaccessfrombrandPOC').show();
		}else{
			$('#brandaccessfrombrandPOC').hide();
			$('#accessFromBrandPOC').val("");
		}	
    });	
		
	$("#brandtype").on("change",function (event) {
		if($('#brandtype').val() === "Reactivation Brand"){
			$('#brandreallocationdate').show();
		}else{
			$('#brandreallocationdate').hide();
			$('#reallocationdate').val("");
		}	
        });
	
	$("#brandtype").on("change",function (event) {
		if($('#brandtype').val() === "Portfolio Brand"){
			$('#portfolionumberofsubbrands').show();
			$('#portfoliosubbrandname').show();
		}else{
			$('#portfolionumberofsubbrands').hide();
			$('#portfoliosubbrandname').hide();
			$('#numberofsubbrands').val("");
			$('#subbrandname').val("");
		}	
        });
	
	$("#brandStatus").on("change",function (event) {
		if($('#brandStatus').val() === "Removed"){
			$('#brandRemovedDate').show();
		}else{
			$('#brandRemovedDate').hide();
			$('#removedDate').val("");
		}	
        });

	
	$("#submitbrand").click(function(){
		
		event.preventDefault();
		
		var siteurl = "https://amsjarvis.cognizant.com/insertinto_brand_mdm"
		
		if($('#brandtype').val() === ""){
			alert("Brand ID must be filled out");
			return false;
		}
		else if($('#brandid').val() === ""){
			alert("Brand ID must be filled out");
			return false;
		}
		else if($('#brandname').val() === ""){
			alert("Brand Name must be filled out");
			return false;
		}
		else if($('#brandtype').val() == "Portfolio Brand" && $('#numberofsubbrands').val() == ""){
				alert("Please enter Number of Sub Brands.");
				return false;
		}
		else if($('#brandtype').val() == "Portfolio Brand" && $('#subbrandname').val() == ""){
				alert("Please enter Sub Brand Names.");
				return false;
		}
		else if($('#category').val() === ""){
				alert("Please select brand category");
				return false;
		}
	    else if($('#subcategory').val() === ""){
				alert("Sub Category must be filled out");
				return false;
		}
		else if($('#sourcechannel').val() === ""){
				alert("Sourcechannel must be filled out");
				return false;
		}
	    else if($('#teamname').val() === ""){
				alert("Please select team name");
				return false;
		}
		else if($('#teamname').val() === "Development" && $('#launchDate').val() === ""){
				alert("Please select brand launch date");
				return false;
		}
	    else if($('#servicetype').val() === ""){
				alert("Please select service type");
				return false;
		}
		else if($('#accessgiven').val() === ""){
				alert("Access Given must be filled out");
				return false;
		}
		else if($('#accessgiven').val() == "Yes" && $('#accessFromBrandPOC').val() === ""){
				alert("Please select Access from Brand POC date.");
				return false;
		}
		else if($('#changesIncorporationInBrand').val() === ""){
				alert("Changes Incorporation In Brand must be filled out");
				return false;
		}
	    else if($('#brandStatus').val() !== "Removed" && $('#allocationDateToCTS').val() === ""){
				alert("Please select allocation date to CTS");
				return false;
		}
	    else if($('#brandStatus').val() === ""){
				alert("Please select Brand Status");
				return false;
		}
		else if($('#brandtype').val() == "Reactivation Brand" && $('#reallocationdate').val() === ""){
				alert("Please select Reallocation date to CTS");
				return false;
		}
		else if($('#brandStatus').val() === "Removed" && $('#removedDate').val() === ""){
				alert("Please select brand removed date");
				return false;
		}
		
		else if($('#invitesreceived').val() === ""){
				alert("Invites Received must be filled out");
				return false;
		}
		else if($('#action').val() === ""){
				alert("Action must be filled out");
				return false;
		}
		else if($('#brandstore').val() === ""){
				alert("Brandstore must be filled out");
				return false;
		}
	    else if($('#brandPocName1').val() === ""){
				alert("Brand POC Name 1 must be filled out");
				return false;
		}
	    else if($('#brandPocPhone1').val() === ""){
				alert("Brand POC Phone 1 must be filled out");
				return false;
		}
	    else if($('#brandPocEmailAddress1').val() === ""){
				alert("Brand POC Email Address1 must be filled out");
				return false;
		}
	    else if($('#amazonContactPointName').val() === ""){
				alert("Amazon Contact Point Name must be filled out");
				return false;
		}
	    else if($('#amazonContactPointEmailAddress').val() === ""){
				alert("Amazon Contact Point Email Address must be filled out");
				return false;
		}
	    else if($('#cognizantContactPoint').val() === ""){
				alert("Cognizant Contact Point must be filled out");
				return false;
		}							
		else {
			var sb_names = [];
			if($('#brandtype').val() === "Portfolio Brand"){
				var portfolio_brand = {}
				portfolio_brand["brand_id"] = $('#brandid').val();
                portfolio_brand["number_of_sub_brands"] = $('#numberofsubbrands').val();
				
				var sb_name =  $('.subbrandname');
				for(var i = 0; i < sb_name.length; i++){
					console.log($(sb_name[i]).val());
					sb_names.push($(sb_name[i]).val());
				}
				
			}
			var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
			currentDateTime = new Date(currentDateTime); 
			var mdmdata = {
				"brand_type":$('#brandtype').val(),
				"brand_id":$('#brandid').val(), 
				"brand_name":$('#brandname').val(),
				"number_of_sub_brands":$('#numberofsubbrands').val(),
				"sub_brand_name":sb_names.toString(),
				"category":$('#category').val(),
				"sub_category":$('#subcategory').val(),
				"source_channel":$('#sourcechannel').val(),
				"team_name":$('#teamname').val(),
				"service_type":$('#servicetype').val(),
				"monthly_budget":$('#monthlybudget').val(),
				"launch_date":$('#launchDate').val(),
				"allocation_date_to_cts":$('#allocationDateToCTS').val(),
				//"allocation_date_to_cts":$('#allocationDateToCTS').val(),
				"access_given":$('#accessgiven').val(),
				"access_from_brand_poc":$('#accessFromBrandPOC').val(),
				"changes_incorporation_in_brand":$('#changesIncorporationInBrand').val(),
				"reallocation_date":$('#reallocationdate').val(),
				"brand_status":$('#brandStatus').val(),
				"removed_date":$('#removedDate').val(),
				
				"invites_received":$('#invitesreceived').val(),
				"action":$('#action').val(),
				"brand_store":$('#brandstore').val(),
				"brand_poc_name1":$('#brandPocName1').val(),
				"brand_poc_phone1":$('#brandPocPhone1').val(),
				"brand_poc_email1":$('#brandPocEmailAddress1').val(),
				"brand_poc_name2":$('#brandPocName2').val(),
				"brand_poc_phone2":$('#brandPocPhone2').val(),
				"brand_poc_email2":$('#brandPocEmailAddress2').val(),
				"brand_poc_name3":$('#brandPocName3').val(),
				"brand_poc_phone3":$('#brandPocPhone3').val(),
				"brand_poc_email3":$('#brandPocEmailAddress3').val(),
				"amazon_contact_point_name":$('#amazonContactPointName').val(),
				"amazon_contact_point_email_address":$('#amazonContactPointEmailAddress').val(),
				"cognizant_contact_point":$('#cognizantContactPoint').val(),
				"brand_modification_date":currentDateTime.toString('MM-dd-yyyy'),
			}
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(mdmdata),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Data uploaded successfully"); 
					location.reload();					
				},
				error: function (error) {
					alert(JSON.stringify(error));
					location.reload();
				}
			});
		}
 	});
	
	$("#modifyBrand").click(function(){
		
		$('#case_notes1').hide();
		$('#case_notes2').hide();
		$('#case_notes3').hide();
		$('#case_notes4').hide();
		$("#submit_brand").show();
	
		if($('#searchBrandId').val() === ""){
			$('#form-container').hide();
				alert("Please enter Brand ID!!");
				return false;
        	}else{
				var siteurl = "https://amsjarvis.cognizant.com/retrieve_brand_data"
				var brandData = {"brand_id":$('#searchBrandId').val()}

				$.ajax({
					url: siteurl,
					type: "POST",
					data: JSON.stringify(brandData),
								dataType: 'json',
					headers: {
						"Accept": "application/json",
						"Content-Type": "application/json"
						},
						success: function (data) {
							displayJsonData(data, true);
						},
						error: function (error) {
							alert(JSON.stringify(error));
						}
				});
			}
    	});
	
	$("#brandDetails").click(function(){
		
		$("#submit_brand").hide();
		
		if($('#searchBrandId').val() === ""){
			$('#form-container').hide();
			alert("Please enter Brand ID!!");
			return false;
        }else{
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_brand_details"
			var brandData = {"brand_id":$('#searchBrandId').val()}

			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(brandData),
							dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
					},
					success: function (data) {
						displayJsonData(data, true);
					},
					error: function (error) {
						alert(JSON.stringify(error));
					}
			});
		}
    });
	
	
	$("#exportData").click(function(){

		var siteurl = "https://amsjarvis.cognizant.com/retrieve_brand_report"
		var filterData = {};
		
		var filterFromDateStr = $("#filterFromDate").val();
		var filterFromDate = new Date(filterFromDateStr);
		filterFromDate = filterFromDate.toString('yyyy-MM-dd');
		
		var  filterToDateStr = $("#filterToDate").val();
		var filterToDate = new Date(filterToDateStr);
		filterToDate = filterToDate.toString('yyyy-MM-dd');
		
		if($('#retrieveBrandCategory').val() === "allocation_date_to_cts"){
			filterData = {
				"filterCategory": $('#retrieveBrandCategory').val(),
				"filterFromDate": filterFromDate,
				"filterToDate": filterToDate
			}
		}else if($('#retrieveBrandCategory').val() === "team_name"){
			filterData = {
				"filterCategory": $('#retrieveBrandCategory').val(),
				"filterValue": $("#filterTeamName").val()
			}
		}else if($('#retrieveBrandCategory').val() === "category"){
			filterData = {
				"filterCategory": $('#retrieveBrandCategory').val(),
				"filterValue": $("#filterBrandCategory").val()
			}
		}else if($('#retrieveBrandCategory').val() === "brand_status"){
			filterData = {
				"filterCategory": $('#retrieveBrandCategory').val(),
				"filterValue": $("#filterBrandStatus").val()
			}
		}else if($('#retrieveBrandCategory').val() === ""){
			filterData = {
				"filterCategory": "",
				"filterValue": ""
			}
		}
		
			
		$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(filterData),
                                dataType: 'json',
				headers: {
					"Accept": "application/json",
                    			"Content-Type": "application/json"
				},
				success: function (data) {	
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
		});
    });
	
});


function displayJsonData(data){
	
    
	var jsonBrandData = JSON.stringify(data);
	var brandObj = JSON.parse(jsonBrandData);
	
	$("#brandtype").val(brandObj.brand_type);
	if(brandObj.brand_type == "Portfolio Brand"){
		$('#portfolionumberofsubbrands').show();
		$('#portfoliosubbrandname').show();
	}
	$("#brandid").val(brandObj.brand_id);  	
	$("#brandid").prop("readonly", true);
	$('#brand_name').show();
	$("#brandname").val(brandObj.brand_name);
	$("#brandname").prop("readonly", true);
	$("#numberofsubbrands").val(brandObj.number_of_sub_brands);
	var sub_brands_list = (brandObj.sub_brand_name).split(',');
	if(sub_brands_list.length>0){
	for(i=0;i<sub_brands_list.length;i++){
		var parent = document.getElementById("sub_brand_name_input_fields");
		var input = document.createElement("input");
		input.type = "text";
		input.className = "form-control subbrandname";
		input.placeholder = 'Sub Brand Name';
		input.name = "subbrandname";
		input.value = sub_brands_list[i].toString();
		parent.appendChild(input);
	}
	}
	$("#category").val(brandObj.category);
    //if(brandObj.category != ""){
		//$("#category").prop("disabled", true);
	//} 
	$("#subcategory").val(brandObj.sub_category);
	$("#sourcechannel").val(brandObj.source_channel);
	$("#teamname").val(brandObj.team_name);
	$("#servicetype").val(brandObj.service_type);
	$("#monthlybudget").val(brandObj.monthly_budget);
	
	if(brandObj.case_note1){
		$('#case_notes1').show();
		$("#casenotes1").val(brandObj.case_note1);
		
	}
	if(brandObj.case_note2){
		$('#case_notes2').show();
		$("#casenotes2").val(brandObj.case_note2);
	}
	if(brandObj.case_note3){
		$('#case_notes3').show();
		$("#casenotes3").val(brandObj.case_note3);
	}
	if(brandObj.case_note4){
		$('#case_notes4').show();
		$("#casenotes4").val(brandObj.case_note4);
	}
	
	if(brandObj.createdby1 && brandObj.date1 && brandObj.communicationType1){
		$('#case-note1-details').show();
		var caseNote1Details = "Added by: " + brandObj.createdby1 + "<br/>" + "Date: " + brandObj.date1 + "<br/>" + "Communication Type: " + brandObj.communicationType1;
		$("#case-note1-details").html(caseNote1Details);
	}
	
	if(brandObj.createdby2 && brandObj.date2 && brandObj.communicationType2){
		$('#case-note2-details').show();
		var caseNote1Details = "Added by: " + brandObj.createdby2 + "<br/>"+"Date: " + brandObj.date2 + "<br/>"+"Communication Type: " + brandObj.communicationType2;
		$("#case-note2-details").html(caseNote1Details);
	}
	
	if(brandObj.createdby3 && brandObj.date3 && brandObj.communicationType3){
		$('#case-note3-details').show();
		var caseNote1Details = "Added by: " + brandObj.createdby3 + "<br/>"+"Date: " + brandObj.date3 + "<br/>"+"Communication Type: " + brandObj.communicationType3;
		$("#case-note3-details").html(caseNote1Details);
	}
	
	if(brandObj.createdby4 && brandObj.date4 && brandObj.communicationType4){
		$('#case-note4-details').show();
		var caseNote1Details = "Added by: " + brandObj.createdby4 + "<br/>"+"Date: " + brandObj.date4 + "<br/>"+"Communication Type: " + brandObj.communicationType4;
		$("#case-note4-details").html(caseNote1Details);
	}
	
	if(brandObj.team_name == "Development"){
		$('#brandLaunchDate').show();
		$("#launchDate").val(brandObj.launch_date);
	}
	$("#allocationDateToCTS").val(brandObj.allocation_date_to_cts);
    if(brandObj.allocation_date_to_cts != ""){
		$("#allocationDateToCTS").prop("disabled", true);
	}
	/*$("#accessFromBrandPOC").val(brandObj.access_from_brand_poc);
	if(brandObj.access_from_brand_poc != ""){
        $("#accessFromBrandPOC").prop("disabled", true);
    }*/
	$("#accessgiven").val(brandObj.access_given);
	if(brandObj.access_given == "Yes"){
		$('#brandaccessfrombrandPOC').show();
		$("#accessFromBrandPOC").val(brandObj.access_from_brand_poc);
		if(brandObj.access_from_brand_poc != ""){
        $("#accessFromBrandPOC").prop("disabled", true);
    }
	}
	$("#changesIncorporationInBrand").val(brandObj.changes_incorporation_in_brand);
	if(brandObj.brand_type == "Reactivation Brand"){
		$('#brandreallocationdate').show();
		$("#reallocationdate").val(brandObj.reallocation_date);
	}
	$("#brandStatus").val(brandObj.brand_status);
	if(brandObj.brand_status == "Removed"){
		$('#brandRemovedDate').show();
		$("#removedDate").val(brandObj.removed_date);
	}
  	//$("#accessgiven").val(brandObj.access_given);
  	$("#invitesreceived").val(brandObj.invites_received);
  	$("#action").val(brandObj.action);
    $("#brandstore").val(brandObj.brand_store);
	$("#brandPocName1").val(brandObj.brand_poc_name1);
	$("#brandPocPhone1").val(brandObj.brand_poc_phone1);
	$("#brandPocEmailAddress1").val(brandObj.brand_poc_email1);
	$("#brandPocName2").val(brandObj.brand_poc_name2);
	$("#brandPocPhone2").val(brandObj.brand_poc_phone2);
	$("#brandPocEmailAddress2").val(brandObj.brand_poc_email2);
	$("#brandPocName3").val(brandObj.brand_poc_name3);
	$("#brandPocPhone3").val(brandObj.brand_poc_phone3);
	$("#brandPocEmailAddress3").val(brandObj.brand_poc_email3);

	$("#amazonContactPointName").val(brandObj.amazon_contact_point_name);
	$("#amazonContactPointEmailAddress").val(brandObj.amazon_contact_point_email_address);
	$("#cognizantContactPoint").val(brandObj.cognizant_contact_point);
	
	$('#form-container').show();
	window.sessionStorage.setItem("team_name", brandObj.team_name)
	
}



$(function(){
    $('#retrieveBrandCategory').on('change', function(){
        var val = $(this).val();
        
		if(val === "team_name" || val === ""){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterBrandCategory').hide();
			$('#filterBrandStatus').hide();
			$("#retrieveBrandCategory").css({"width":"40%","margin-left":"8%"});
			$('#filterTeamName').show();
			
			var sub = $('#filterTeamName');
			$('option', sub).filter(function(){
				if (
					 $(this).attr('data-group') === val 
				  || $(this).attr('data-group') === 'SHOW'
				) {
				  if ($(this).parent('span').length) {
					$(this).unwrap();
				  }
				} else {
				  if (!$(this).parent('span').length) {
					$(this).wrap( "<span>" ).parent().hide();
				  }
				}
			});
		}
		else if(val === "allocation_date_to_cts"){
			$('#filterTeamName').hide();
			$("#retrieveBrandCategory").css({"width":"23%", "margin-left":"0%"});
			$('#filterBrandCategory').hide();
			$('#filterBrandStatus').hide();
			$('#filterFromDate').show();
			$('#filterToDate').show();
		}
		else if(val === "category"){
			$('#filterTeamName').hide();
			$("#retrieveBrandCategory").css({"width":"40%","margin-left":"8%"});
			$('#filterBrandStatus').hide();
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterBrandCategory').show();
			
			var sub = $('#filterBrandCategory');
			$('option', sub).filter(function(){
				if (
					 $(this).attr('data-group') === val 
				  || $(this).attr('data-group') === 'SHOW'
				) {
				  if ($(this).parent('span').length) {
					$(this).unwrap();
				  }
				} else {
				  if (!$(this).parent('span').length) {
					$(this).wrap( "<span>" ).parent().hide();
				  }
				}
			});
		}
		else if(val === "brand_status"){
			$('#filterTeamName').hide();
			$("#retrieveBrandCategory").css({"width":"40%","margin-left":"8%"});
			$('#filterBrandCategory').hide();
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterBrandStatus').show();
		}
    });
    $('#filtercategory').trigger('change');
});


function JSONToCSVConvertor(data, ShowLabel) {
	
	console.log(JSON.stringify(data));
	var jsonBrandData = JSON.stringify(data);
	var jsonObj = JSON.parse(jsonBrandData);
	var JSONData = JSON.stringify(jsonObj.brand);
         var parseData = JSON.parse(JSONData);
         
         /* create workbook & set props*/
         const wb = { SheetNames: [], Sheets: {} };
         wb.Props = {
                  Title: "MDM Data",
                  Author: "Unknown"
         };

         /*create sheet data & add to workbook*/
         var ws = XLSX.utils.json_to_sheet(parseData);
         var ws_name = "MDM Data";
         XLSX.utils.book_append_sheet(wb, ws, ws_name);
         XLSX.writeFile(wb, "Brand_MDM_Report.xlsx");
}
