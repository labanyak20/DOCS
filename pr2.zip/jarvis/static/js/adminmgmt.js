$(document).ready(function(){

	var pexNameData;
	$.ajax({
		url: "https://amsjarvis.cognizant.com/retrieve_associate_name",
		type: "POST",
		data: {},
		headers: {
		         "Accept": "application/json",
					   "Content-Type": "application/json"
		},
		success: function (associatename) {        
		         window.sessionStorage.setItem("associatename", associatename.toString());
				 //console.log('associate name---')
				 //console.log(associatename);
		},
		error: function (error) {
					alert('Not able to fetch associate name. Please log out and log in again!!');            
		}
	});
	$.ajax({
		url: "static/csv/pexteam.csv",
		async: false,
		dataType: "text",
		success: function (csvd) {
			pexNameData = data = csvd.split('\n');
		},
		complete: function () {
			for(var i = 0; i < pexNameData.length; i++) {
				associateName = window.sessionStorage.getItem("associatename");
				//console.log(pexNameData[i].toString());
				//console.log(associateName.toString());
				if(pexNameData[i].toString().trim() !== associateName.toString().trim()){
					//console.log('if');
					document.getElementById("get").disabled = true;
				}
				else if(pexNameData[i].toString().trim() === associateName.toString().trim()){
					document.getElementById("get").disabled = false;
					//console.log('else');
					break;
				}
			}
		}
	});
	$("#get").click(function(){
		
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_attendance_data"
			data = {};
		
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
                dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					console.log(data)
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		});
});		
function JSONToCSVConvertor(data){
         var json_admin_mgmtData = JSON.stringify(data);
         var jsonObj = JSON.parse(json_admin_mgmtData);
	     var JSONData = JSON.stringify(jsonObj.data);
         var parseData = JSON.parse(JSONData);        
         /* create workbook & set props*/
         const wb = { SheetNames: [], Sheets: {} };
         wb.Props = {
                  Title: "Agent Attendence",
                  Author: "Unknown"
         };

         /*create sheet data & add to workbook*/
         var ws = XLSX.utils.json_to_sheet(parseData);
         var ws_name = "Agent Attendence";
         XLSX.utils.book_append_sheet(wb, ws, ws_name);
		 XLSX.writeFile(wb, "Agent_Attendence.xlsx");
		 
}
