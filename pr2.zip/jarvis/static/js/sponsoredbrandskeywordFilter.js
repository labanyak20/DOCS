google.charts.load('current', {'packages':['corechart']});
google.charts.load('current', {'packages':['table']});
google.charts.load('current', {'packages':['corechart', 'controls']});

//$(document).ready(function(){
	
var oFileIn;
var json_object;
var dataTableArr;
var acos;
var dataTableData;
var table;
var filteredView;
var adSpentValue = 0;
var dashboard;

$('#acos').change(function(){
	acos = this.value;
});

$('#excelSuccessAlert').hide();

$(function() {
	oFileIn = document.getElementById('my_file_input');
	if(oFileIn.addEventListener) {
		oFileIn.addEventListener('change', filePicked, false);
	}
});

function filePicked(oEvent) {
	
	$('#excelSuccessAlert').show();
	
	$("#progressbar").progressbar({
		value: false
	});
	
	var oFile = oEvent.target.files[0];
	var sFilename = oFile.name;
	var reader = new FileReader();
	
	reader.onload = function(e) {
		
		var data = e.target.result;
		var workbook = XLSX.read(data, {
		type: 'binary'
		});

		workbook.SheetNames.forEach(function(sheetName) {
			var sheet2csv = XLSX.utils.sheet_to_csv(workbook.Sheets[sheetName]);
			//console.log("CSV : " + sheet2csv);
			
			dataTableArr = $.csv.toArrays(sheet2csv);
			//console.log("Data table Array : " + dataTableArr);
			
			dataTableData = new google.visualization.arrayToDataTable(dataTableArr,false); 
			//console.log("Data Table : " + dataTableData);
			
			dataTableData.insertColumn(7, 'number', 'Impressions');
			dataTableData.insertColumn(9, 'number', 'Clicks');
			dataTableData.insertColumn(11, 'number', 'CTR');
			dataTableData.insertColumn(14, 'number', 'Spend');
			dataTableData.insertColumn(16, 'number', 'ACoS');
			dataTableData.insertColumn(19, 'number', 'Sales');
			dataTableData.insertColumn(21, 'number', 'Orders');
			dataTableData.insertColumn(23, 'number', 'Units');
			
			for (var i = 0; i < dataTableData.getNumberOfRows(); i++) {
				
				var val1 = dataTableData.getValue(i, 8);
				if (val1 != '' && val1 != null) {
					dataTableData.setValue(i, 7, new Number(val1).valueOf());
				}
				
				var val2 = dataTableData.getValue(i, 10);
				if (val2 != '' && val2 != null) {
					dataTableData.setValue(i, 9, new Number(val2).valueOf());
				}
				
				var val3 = dataTableData.getValue(i, 12);
				
				if (val3 != '' && val3 != null) {
					val3 = val3.replace('%','');
					dataTableData.setValue(i, 11, new Number(val3).valueOf());
				}
				
				var val4 = dataTableData.getValue(i, 15);
				if (val4 != '' && val4 != null) {
					val4 = val4.replace('₹ ','');
					val4 = val4.replace(',','');
					dataTableData.setValue(i, 14, parseFloat(val4));
					adSpentValue = adSpentValue + parseFloat(val4);
				}
				
				var val5 = dataTableData.getValue(i, 17);
				if (val5 != '' && val5 != null) {
					val5 = val5.replace('%','');
					dataTableData.setValue(i, 16, new Number(val5).valueOf());
				}
				
				var val6 = dataTableData.getValue(i, 20);
				if (val6 != '' && val6 != null) {
					val6 = val6.replace('₹ ','');
					val6 = val6.replace(',','');
					dataTableData.setValue(i, 19, parseFloat(val6));
				}
				
							
				var val7 = dataTableData.getValue(i, 22);
				if (val7 != '' && val7 != null) {
					dataTableData.setValue(i, 21, new Number(val7).valueOf());
				}
				
				var val8 = dataTableData.getValue(i, 24);
				if (val8 != '' && val8 != null) {
					dataTableData.setValue(i, 23, new Number(val8).valueOf());
				}
				
			}
			
			window.sessionStorage.setItem("csvData", sheet2csv);
			
			filterData();
			
		});
	};
			
	reader.onerror = function(ex) {
		console.log(ex);
	};

	reader.readAsBinaryString(oFile);
	
}//end of filepicked function


document.getElementById("exportCSV").addEventListener("click", function () {
	var csvData = table.getDataTable(); //google visualization DataTable to download	
	export_CSV("exportCSV", csvData);
	
});

function export_CSV(elementID, data) {

	var csvColumns;
	var csvContent;
	var downloadLink;

	// build column headings
	csvColumns = '';
	for (var i = 0; i < data.getNumberOfColumns(); i++) {
		csvColumns += data.getColumnLabel(i);
		if (i < data.getNumberOfColumns() - 1) {
			csvColumns += ',';
		}
	}
	csvColumns += '\n';

	// get data rows
	csvContent = csvColumns + google.visualization.dataTableToCsv(data);

	//New Download Link - works in chrome and mozilla
	downloadLink = document.getElementById(elementID);
	downloadLink.href = 'data:text/csv;charset=utf-16,' + escape(csvContent);
	downloadLink.download = 'data.csv';
	downloadLink.target = '_blank';
	
}//end of export csv

function dataHandler(e) {
	
	var adSpentSavedValue = 0;
	var filteredDataTableData = table.getDataTable(); //google visualization DataTable to download	
	for (var i = 0; i < filteredDataTableData.getNumberOfRows(); i++) {
		if(filteredDataTableData.getValue(i, 11) != null || filteredDataTableData.getValue(i, 11) != ''){
			var val = filteredDataTableData.getValue(i, 11);
			if (val != '' && val != null) {
				adSpentSavedValue = adSpentSavedValue + parseFloat(val);
			}
		}
	}
	
	if(adSpentValue !== adSpentSavedValue) {
		adSpentSavedValue = adSpentValue - adSpentSavedValue;
		$('#adSpentLabel').text("Ad Spent:");
		$('#adSpentValue').text(Math.round(adSpentValue * 100) / 100);
		$('#adSpentSavedLabel').text("Ad Spent Saved:");
		$('#adSpentSavedValue').text(Math.round(adSpentSavedValue * 100) / 100);
		$('#adSpentSavedLabel').show();
		$('#adSpentSavedValue').show();
		$('#topKeywordBtn').show().css("margin-left","53%");
	}
	
	if(adSpentValue === adSpentSavedValue) {
		$('#adSpentLabel').text("Ad Spent:");
		$('#adSpentValue').text(Math.round(adSpentValue * 100) / 100);
		$('#adSpentSavedLabel').hide();
		$('#adSpentSavedValue').hide();
		$('#topKeywordBtn').show().css("margin-left","65%");
	}
	
}

function analyzeKeyword(){
	var keyword = $('#keyword').val();
	window.sessionStorage.setItem("keyword",keyword);
}

function filterData(){
	
	var acosSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control1',
	  'options': {
		'filterColumnLabel': 'ACoS',
		'minValue': $('#acosMinValue').val(),
		'maxValue': $('#acosMaxValue').val()
	  }
	});
			
	var ctrSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control3',
	  'options': {
		'filterColumnLabel': 'CTR',
		'minValue': $('#ctrMinValue').val(),
		'maxValue': $('#ctrMaxValue').val()
	  }
	});
	
	var impressionsSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control5',
	  'options': {
		'filterColumnLabel': 'Impressions',
		'minValue': $('#impressionsMinValue').val(),
		'maxValue': $('#impressionsMaxValue').val()
	  }
	});
	
	var clickSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control7',
	  'options': {
		'filterColumnLabel': 'Clicks',
		'minValue': $('#clickMinValue').val(),
		'maxValue': $('#clickMaxValue').val()
	  }
	});
	
	var spendSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control9',
	  'options': {
		'filterColumnLabel': 'Spend',
		'minValue': $('#spendMinValue').val(),
		'maxValue': $('#spendMaxValue').val()
	  }
	});
	
	var salesSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control11',
	  'options': {
		'filterColumnLabel': 'Sales',
		'minValue': $('#salesMinValue').val(),
		'maxValue': $('#salesMaxValue').val()
	  }
	});
	
	var ordersSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control13',
	  'options': {
		'filterColumnLabel': 'Orders',
		'minValue': $('#ordersMinValue').val(),
		'maxValue': $('#ordersMaxValue').val()
	  }
	});
	
	var unitsSlider = new google.visualization.ControlWrapper({
	  'controlType': 'NumberRangeFilter',
	  'containerId': 'control15',
	  'options': {
		'filterColumnLabel': 'Units',
		'minValue': $('#unitsMinValue').val(),
		'maxValue': $('#unitsMaxValue').val()
	  }
	});
	
	var matchTypeSlider = new google.visualization.ControlWrapper({
	  'controlType': 'CategoryFilter',
	  'containerId': 'control17',
	  'options': {
		'filterColumnLabel': 'Match Type'
	  }
	});
	
	table = new google.visualization.ChartWrapper({
		'chartType': 'Table',
		'containerId': 'chart_div',
		'options': {
			'width': 1300,
			'height': 600,
			'legend': 'right',
			'pageSize':200,
			'alternatingRowStyle': true
		}		
	});
	
	filteredView = new google.visualization.DataView(dataTableData);
	
	filteredView.setColumns([0,1,2,3,4,5,6,7,9,11,13,14,16,18,19,21,23,25,26,27,28,29,30,31,32,33]);
	
	dashboard = new google.visualization.Dashboard(document.getElementById('dashboard_div'));
	
		
	dashboard.bind(acosSlider,table);
	dashboard.bind(ctrSlider,table);
	dashboard.bind(impressionsSlider,table);
	dashboard.bind(clickSlider,table);
	dashboard.bind(spendSlider,table);
	dashboard.bind(salesSlider,table);
	dashboard.bind(ordersSlider,table);
	dashboard.bind(unitsSlider,table);
	dashboard.bind(matchTypeSlider,table);
	
	$('#excelForm').hide();
	$('#progressbar').hide();
	dashboard.draw(filteredView);
	$('#exportCSV').show();	
	$('#analyzeKeyword').show();
	$('#adSpentLabel').show();
	$('#adSpentValue').show();
	$('#adSpentSavedLabel').show();
	$('#adSpentSavedValue').show();
	$('#resetBtn').hide();
	$('#topKeywordBtn').show();
	
	$('#acosMinValue').show().css("display", "initial");
	$('#ctrMinValue').show().css("display", "initial");
	$('#impressionsMinValue').show().css("display", "initial");
	$('#clickMinValue').show().css("display", "initial");
	$('#spendMinValue').show().css("display", "initial");
	$('#salesMinValue').show().css("display", "initial");
	$('#ordersMinValue').show().css("display", "initial");
	$('#unitsMinValue').show().css("display", "initial");
	
		
	$('#acosMaxValue').show().css("display", "initial");
	$('#ctrMaxValue').show().css("display", "initial");
	$('#impressionsMaxValue').show().css("display", "initial");
	$('#clickMaxValue').show().css("display", "initial");
	$('#spendMaxValue').show().css("display", "initial");
	$('#salesMaxValue').show().css("display", "initial");
	$('#ordersMaxValue').show().css("display", "initial");
	$('#unitsMaxValue').show().css("display", "initial");
	
	google.visualization.events.addListener(table, 'ready', dataHandler);
	
}	
	
function topKeywords(){
	
	var currentTableData = new google.visualization.DataTable();
	
	currentTableData = dataTableData.clone();
	currentTableData.sort({column: 7, desc:true});
	
	var highestImpression = currentTableData.getFormattedValue(0, 7);
	highestImpression = highestImpression.replace(',','');
	var eightyPercentOfHighestImpressionInt = parseInt(highestImpression);
	
	var eightyPercentOfHighestImpression = Math.round(eightyPercentOfHighestImpressionInt * 0.2);
	
	filteredView = new google.visualization.DataView(currentTableData);
	filteredView.setRows(currentTableData.getFilteredRows([{column: 7, minValue: eightyPercentOfHighestImpression},{column: 9, minValue: 1},{column: 19, minValue: 1}]));
	filteredView.setColumns([0,1,2,3,4,5,6,7,9,11,13,14,16,18,19,21,23,25,26,27,28,29,30,31,32,33]);
	dashboard.draw(filteredView);
	
	$('#topKeywordBtn').hide();
	$('#resetBtn').show();
	
	google.visualization.events.addListener(table, 'ready', topKeywordDataHandler);
	
}

function topKeywordDataHandler(e) {
	
	var adSpentSavedValue = 0;
	var filteredDataTableData = table.getDataTable(); //google visualization DataTable to download	
	for (var i = 0; i < filteredDataTableData.getNumberOfRows(); i++) {
		if(filteredDataTableData.getValue(i, 11) != null || filteredDataTableData.getValue(i, 11) != ''){
			var val = filteredDataTableData.getValue(i, 11);
			if (val != '' && val != null) {
				adSpentSavedValue = adSpentSavedValue + parseFloat(val);
			}
		}
	}
	
	if(adSpentValue !== adSpentSavedValue) {
		adSpentSavedValue = adSpentValue - adSpentSavedValue;
		$('#adSpentLabel').text("Ad Spent:");
		$('#adSpentValue').text(Math.round(adSpentValue * 100) / 100);
		$('#adSpentSavedLabel').text("Ad Spent Saved:");
		$('#adSpentSavedValue').text(Math.round(adSpentSavedValue * 100) / 100);
		$('#adSpentSavedLabel').show();
		$('#adSpentSavedValue').show();
		$('#topKeywordBtn').hide();
	}
	
	if(adSpentValue === adSpentSavedValue) {
		$('#adSpentLabel').text("Ad Spent:");
		$('#adSpentValue').text(Math.round(adSpentValue * 100) / 100);
		$('#adSpentSavedLabel').hide();
		$('#adSpentSavedValue').hide();
		$('#topKeywordBtn').show().css("margin-left","65%");
	}
	
}