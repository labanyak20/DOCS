
$(document).ready(function(){
	
	$('#summary-div').hide();
	
	if($('#brandstorerequesttype').val() === "New brand store creation"){
		$('#contacted-date-time-div').hide();
		$('#request-type-div').hide();
		$('#query-status-div').hide();
		$('#query-remarks-div').hide();
		$('#additionalissue-div').hide();
	}
		
	$("#brandstorerequesttype").on("change input",function () {
		if($('#brandstorerequesttype').val() === "New brand store creation"){
			$('#contacted-date-time-div').hide();
			$('#request-type-div').hide();
			$('#query-status-div').hide();
			$('#query-remarks-div').hide();
			$('#additionalissue-div').hide();
			$('#new-brand-store-creation-div').show();
		}else{
			$('#contacted-date-time-div').show();
			$('#request-type-div').show();
			$('#query-status-div').show();
			$('#query-remarks-div').show();
			$('#additionalissue-div').show();
			$('#source-channel-div').hide();
			$('#new-brand-store-creation-div').hide();
		}
	});
	
	$.ajax({
		url: "static/csv/brandsStoreTracker.csv",
		async: false,
		success: function (csvd) {
			associatesNameData = data = csvd.split('\n');
		},
		dataType: "text",
		complete: function () {
			var list = associatesNameData;
			var sel = document.getElementById('ctspoc');
			var opt = document.createElement('option');
			opt.innerHTML = "-- Select --";
			sel.appendChild(opt);
			for(var i = 0; i < list.length; i++) {
				opt = document.createElement('option');
				opt.innerHTML = list[i];
				sel.appendChild(opt);
			}
		}
	});
 
 
 	var searchBrand = document.getElementById("modifyBrandId");
	searchBrand.addEventListener("keyup", function(event) {
  		if (event.keyCode === 13) {
   			event.preventDefault();
   			document.getElementById("modifyBrandStoreData").click();
  		}
	});
 
 	$(function(){
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		if(month < 10)
			month = '0' + month.toString();
		if(day < 10)
			day = '0' + day.toString();
		maxDate = year + '-' + month + '-' + day;		
		$('#allocationDateToCTS').attr('max', maxDate);
		$('#launchDate').attr('max', maxDate);
		$('#accessFromBrandPOC').attr('max', maxDate);
		$('#changesIncorporationInBrand').attr('max', maxDate);
		$('#removedDate').attr('max', maxDate);
	});
	
	$.ajax({
		url: "static/csv/brands.csv",
		async: false,
		success: function (csvd) {
			csvd = csvd.replace(/\n|\r/g, ",");
			csvd = csvd.replace(/,,/g, ",");
			data = csvd.split(',');
		},
		dataType: "text",
		complete: function () {
			
		}
	});

	var brands = [];	
	for (var i = 0; i < data.length; i += 2) {
	  var val = {};
	  val[data[i]] = data[i + 1];
	  brands.push(val);
	}
	
	$("#brandid").on("change input",function (event) {		
		
		var key = $('#brandid').val();
		var value;
		if(typeof brands.find(b => key.indexOf(Object.keys(b)) > -1) !== 'undefined'){
			value = brands.find(b => key.indexOf(Object.keys(b)) > -1)[key];
			$("#brandname:text").val(value);
		}else{
			$("#brandname:text").val('');
		}
				
		var brandId = {"brand_id":$('#brandid').val()} 
		$.ajax({
				url: "https://amsjarvis.cognizant.com/check_brand_strore_tracker_for_duplicate",
				type: "POST",
				data: JSON.stringify(brandId),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
			 if(data !== ""){
				  alert(data);
				  location.reload();
			 }   
				},
				error: function (error) {
			 location.reload();
				}
		}); 
			
	});

	$("#additionalissue-subissue").on("change input",function (event) {		
		  if($('#additionalissue-subissue').val() === "Any other"){
        $('#summary-div').show();
      }else{
        $('#summary-div').hide();
      }
    });  	
   
	$("#submitbrandstoredata").click(function(){
		
		event.preventDefault();
    var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		currentDateTime = new Date(currentDateTime);
		
		var siteurl = "https://amsjarvis.cognizant.com/insertinto_brand_store_tracker"
		
		if($('#brandid').val() === ""){
			alert("Brand ID must be filled out");
			return false;
		}
		else if($('#brandname').val() === ""){
			alert("Brand Name must be filled out");
			return false;
		}
		else if($('#ctspoc').val() === "-- Select --"){
				alert("Please select brand Account Manager/CTS POC");
				return false;
		}
	    else if($('#amspoc').val() === ""){
				alert("AMS POC must be filled out");
				return false;
		}
	    else if($('#brandcontactname1').val() === ""){
				alert("Brand Contact Name 1 must be filled out");
				return false;
		}
	    else if($('#brandcontactnumber1').val() === ""){
				alert("Brand Contact Phone 1 must be filled out");
				return false;
		}
	    else if($('#brandemailid1').val() === ""){
				alert("Brand Contact Email Address1 must be filled out");
				return false;
		}					
		else { 
		//console.log($('#trainingdate2subissue').val().toString())
			var brandstoretrackerdata = { 
				"brand_id":$('#brandid').val(), 
				"brand_name":$('#brandname').val(),
				"cts_poc":$('#ctspoc').val(),
				"ams_poc":$('#amspoc').val(),
				"source_channel":$('#sourcechannel').val(),
				"brand_contact_name1":$('#brandcontactname1').val(),
				"brand_contact_number1":$('#brandcontactnumber1').val(),
				"brand_email_id1":$('#brandemailid1').val(),
				"brand_contact_name2":$('#brandcontactname2').val(),
				"brand_contact_number2":$('#brandcontactnumber2').val(),
				"brand_email_id2":$('#brandemailid2').val(),
				"brand_contact_name3":$('#brandcontactname3').val(),
				"brand_contact_number3":$('#brandcontactnumber3').val(),
				"contacted_date":$('#contacteddate').val(),
				"contacted_time":$('#contactedtime').val(),
				"request_type":$('#requesttype').val(),
				"query_status":$('#querystatus').val(),
				"query_remarks":$('#queryremarks').val(),
				"pitch_date1_proposed_date":$('#pitchdate1proposeddate').val().toString(),
				"pitch_date1_proposed_time":$('#pitchdate1proposedtime').val().toString(),
				"pitch_date1_actual_date":$('#pitchdate1actualdate').val().toString(),
				"pitch_date1_sub_issue":$('#pitchdate1subissue').val().toString(),
				"pitch_date2_proposed_date":$('#pitchdate2proposeddate').val().toString(),
				"pitch_date2_proposed_time":$('#pitchdate2proposedtime').val().toString(),
				"pitch_date2_actual_date":$('#pitchdate2actualdate').val().toString(),
				"pitch_date2_sub_issue":$('#pitchdate2subissue').val().toString(),
				"training_date1_proposed_date":$('#trainingdate1proposeddate').val().toString(),	
				"training_date1_proposed_time":$('#trainingdate1proposedtime').val().toString(),	
				"training_date1_actual_date":$('#trainingdate1actualdate').val().toString(),	
				"training_date1_sub_issue":$('#trainingdate1subissue').val().toString(),	
				"training_date2_proposed_date":$('#trainingdate2proposeddate').val().toString(),	
				"training_date2_proposed_time":$('#trainingdate2proposedtime').val().toString(),	
				"training_date2_actual_date":$('#trainingdate2actualdate').val().toString(),
				"training_date2_sub_issue":$('#trainingdate2subissue').val().toString(),
				"training_date3_proposed_date":$('#trainingdate3proposeddate').val().toString(),	
				"training_date3_proposed_time":$('#trainingdate3proposedtime').val().toString(),	
				"training_date3_actual_date":$('#trainingdate3actualdate').val().toString(),	
				"training_date3_sub_issue":$('#trainingdate3subissue').val().toString(),	
				"training_date4_proposed_date":$('#trainingdate4proposeddate').val().toString(),	
				"training_date4_proposed_time":$('#trainingdate4proposedtime').val().toString(),	
				"training_date4_actual_date":$('#trainingdate4actualdate').val().toString(),	
				"training_date4_sub_issue":$('#trainingdate4subissue').val().toString(),	
				"training_date5_proposed_date":$('#trainingdate5proposeddate').val().toString(),	
				"training_date5_proposed_time":$('#trainingdate5proposedtime').val().toString(),	
				"training_date5_actual_date":$('#trainingdate5actualdate').val().toString(),	
				"training_date5_sub_issue":$('#trainingdate5subissue').val().toString(),	
				"brand_store_submission_date":$('#brandstoresubmissiondate').val().toString(),	
				"brand_store_approval_date":$('#brandstoreapprovaldate').val().toString(),	
				"store_status":$('#storestatus').val().toString(),
				"additional_issue_sub_issue":$('#additionalissue-subissue').val().toString(),
				"summary":$('#summary').val().toString(),
				"date": currentDateTime.toString("yyyy-MM-dd"),
				"pitch_date1_remarks":$('#pitchdate1remarks').val().toString(),
				"pitch_date2_remarks":$('#pitchdate2remarks').val().toString(),
				"training_date1_remarks":$('#trainingdate1remarks').val().toString(),
				"training_date2_remarks":$('#trainingdate2remarks').val().toString(),
				"training_date3_remarks":$('#trainingdate3remarks').val().toString(),
				"training_date4_remarks":$('#trainingdate4remarks').val().toString(),
				"training_date5_remarks":$('#trainingdate5remarks').val().toString()
			}
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(brandstoretrackerdata),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Data uploaded successfully"); 					
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		}
 	});
	
	$("#modifyBrandStoreData").click(function(){
		if($('#modifyBrandId').val() === ""){
			location.reload();
			alert("Please enter Brand ID!!");
			return false;
        }else{
			
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_brand_store_tracker"
			var brandData = {"brand_id":$('#modifyBrandId').val()}

			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(brandData),
				dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
					},
					success: function (data) {       
						displayJsonData(data);
					},
					error: function (error) {
						alert(JSON.stringify(error));
					}
			});
		}
    	});
	
	
	$("#exportData").click(function(){

		var siteurl = "https://amsjarvis.cognizant.com/retrieve_brand_store_tracker_report"
		var filterData = {};
		
		var filterFromDateStr = $("#filterFromDate").val();
		var filterFromDate = new Date(filterFromDateStr);
		filterFromDate = filterFromDate.toString('yyyy-MM-dd');
		
		var  filterToDateStr = $("#filterToDate").val();
		var filterToDate = new Date(filterToDateStr);
		filterToDate = filterToDate.toString('yyyy-MM-dd');
		
		if($('#retrieveCategory').val() === "pitch_date"){
			filterData = {
				"filterCategory": $('#retrieveCategory').val(),
				"filterFromDate": filterFromDate,
				"filterToDate": filterToDate
			}
		}else if($('#retrieveCategory').val() === "agent_name"){
			filterData = {
				"filterCategory": $('#retrieveCategory').val(),
				"filterValue": $("#filterAgentName").val()
			}
		}else if($('#retrieveBrandCategory').val() === ""){
			filterData = {
				"filterCategory": "",
				"filterValue": ""
			}
		}
		
			
		$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(filterData),
        dataType: 'json',
				headers: {
					"Accept": "application/json",
           "Content-Type": "application/json"
				},
				success: function (data) {	
					JSONToCSVConvertor(data);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
		});
    });
	
});


function displayJsonData(data){
	
  //console.log(JSON.stringify(data));
	var jsonBrandStoreData = JSON.stringify(data);
	var brandStoreObj = JSON.parse(jsonBrandStoreData); 
	
	if(brandStoreObj.brand_id != ""){ 
		$('#brandid').val(brandStoreObj.brand_id);
		$("#brandid").prop("disabled", true);
	}
	if(brandStoreObj.brand_name != ""){  
		$('#brandname').val(brandStoreObj.brand_name);
		$("#brandname").prop("disabled", true);
	}
	if(brandStoreObj.cts_poc != ""){ 
		$('#ctspoc').val(brandStoreObj.cts_poc);
		$("#ctspoc").prop("disabled", true);
	}
	if(brandStoreObj.ams_poc != ""){ 
		$('#amspoc').val(brandStoreObj.ams_poc);
		$("#amspoc").prop("disabled", true);
	}
	if(brandStoreObj.source_channel != ""){ 
		$('#sourcechannel').val(brandStoreObj.source_channel);
		$("#sourcechannel").prop("disabled", true);
	}
	if(brandStoreObj.brand_contact_name1 != ""){ 
		$('#brandcontactname1').val(brandStoreObj.brand_contact_name1);
		$("#brandcontactname1").prop("disabled", true);
	}
	if(brandStoreObj.brand_contact_number1 != ""){ 
		$('#brandcontactnumber1').val(brandStoreObj.brand_contact_number1);
		$("#brandcontactnumber1").prop("disabled", true);
	}
	if(brandStoreObj.brand_email_id1 != ""){ 
		$('#brandemailid1').val(brandStoreObj.brand_email_id1);
		$("#brandemailid1").prop("disabled", true);
	}
	if(brandStoreObj.brand_contact_name2 != ""){ 
		$('#brandcontactname2').val(brandStoreObj.brand_contact_name2);
		$("#brandcontactname2").prop("disabled", true);
	}
	if(brandStoreObj.brand_contact_number2 != ""){ 
		$('#brandcontactnumber2').val(brandStoreObj.brand_contact_number2);
		$("#brandcontactnumber2").prop("disabled", true);
	}
	if(brandStoreObj.brand_email_id2 != ""){ 
		$('#brandemailid2').val(brandStoreObj.brand_email_id2);
		$("#brandemailid2").prop("disabled", true);
	}
	if(brandStoreObj.brand_contact_name3 != ""){ 
		$('#brandcontactname3').val(brandStoreObj.brand_contact_name3);
		$("#brandcontactname3").prop("disabled", true);
	}
	if(brandStoreObj.brand_contact_number3 != ""){ 
		$('#brandcontactnumber3').val(brandStoreObj.brand_contact_number3);
		$("#brandcontactnumber3").prop("disabled", true);
	}
	if(brandStoreObj.brand_email_id3 != ""){ 
		$('#brandemailid3').val(brandStoreObj.brand_email_id3);
		$("#brandemailid3").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date1_proposed_date != ""){ 
		$('#pitchdate1proposeddate').val(brandStoreObj.pitch_date1_proposed_date);
		$("#pitchdate1proposeddate").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date1_proposed_time != ""){ 
		$('#pitchdate1proposedtime').val(brandStoreObj.pitch_date1_proposed_time);
		$("#pitchdate1proposedtime").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date1_actual_date != ""){ 
		$('#pitchdate1actualdate').val(brandStoreObj.pitch_date1_actual_date);
		$("#pitchdate1actualdate").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date1_sub_issue != ""){ 
		$('#pitchdate1subissue').val(brandStoreObj.pitch_date1_sub_issue);
		$("#pitchdate1subissue").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date2_proposed_date != ""){ 
		$('#pitchdate2proposeddate').val(brandStoreObj.pitch_date2_proposed_date);
		$("#pitchdate2proposeddate").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date2_proposed_time != ""){ 
		$('#pitchdate2proposedtime').val(brandStoreObj.pitch_date2_proposed_time);
		$("#pitchdate2proposedtime").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date2_actual_date != ""){ 
		$('#pitchdate2actualdate').val(brandStoreObj.pitch_date2_actual_date);
		$("#pitchdate2actualdate").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date2_sub_issue != ""){ 
		$('#pitchdate2subissue').val(brandStoreObj.pitch_date2_sub_issue);
		$("#pitchdate2subissue").prop("disabled", true);
	}
	if(brandStoreObj.training_date1_proposed_date != ""){ 
		$('#trainingdate1proposeddate').val(brandStoreObj.training_date1_proposed_date);
		$("#trainingdate1proposeddate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date1_proposed_time != ""){ 
		$('#trainingdate1proposedtime').val(brandStoreObj.training_date1_proposed_time);
		$("#trainingdate1proposedtime").prop("disabled", true);
	}	
	if(brandStoreObj.training_date1_actual_date != ""){ 
		$('#trainingdate1actualdate').val(brandStoreObj.training_date1_actual_date);
		$("#trainingdate1actualdate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date1_sub_issue != ""){ 
		$('#trainingdate1subissue').val(brandStoreObj.training_date1_sub_issue);
		$("#trainingdate1subissue").prop("disabled", true);
	}	
	if(brandStoreObj.training_date2_proposed_date != ""){ 
		$('#trainingdate2proposeddate').val(brandStoreObj.training_date2_proposed_date);
		$("#trainingdate2proposeddate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date2_proposed_time != ""){ 
		$('#trainingdate2proposedtime').val(brandStoreObj.training_date2_proposed_time);
		$("#trainingdate2proposedtime").prop("disabled", true);
	}	
	if(brandStoreObj.training_date2_actual_date != ""){ 
		$('#trainingdate2actualdate').val(brandStoreObj.training_date2_actual_date);
		$("#trainingdate2actualdate").prop("disabled", true);
	}
	console.log(brandStoreObj.training_date2_sub_issue);
	if(brandStoreObj.training_date2_sub_issue != ""){ 
		$('#trainingdate2subissue').val(brandStoreObj.training_date2_sub_issue);
		$("#trainingdate2subissue").prop("disabled", true);
	}	
	if(brandStoreObj.training_date3_proposed_date != ""){ 
		$('#trainingdate3proposeddate').val(brandStoreObj.training_date3_proposed_date);
		$("#trainingdate3proposeddate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date3_proposed_time != ""){ 
		$('#trainingdate3proposedtime').val(brandStoreObj.training_date3_proposed_time);
		$("#trainingdate3proposedtime").prop("disabled", true);
	}	
	if(brandStoreObj.training_date3_actual_date != ""){ 
		$('#trainingdate3actualdate').val(brandStoreObj.training_date3_actual_date);
		$("#trainingdate3actualdate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date3_sub_issue != ""){ 
		$('#trainingdate3subissue').val(brandStoreObj.training_date3_sub_issue);
		$("#trainingdate3subissue").prop("disabled", true);
	}	
	if(brandStoreObj.training_date4_proposed_date != ""){ 
		$('#trainingdate4proposeddate').val(brandStoreObj.training_date4_proposed_date);
		$("#trainingdate4proposeddate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date4_proposed_time != ""){ 
		$('#trainingdate4proposedtime').val(brandStoreObj.training_date4_proposed_time);
		$("#trainingdate4proposedtime").prop("disabled", true);
	}	
	if(brandStoreObj.training_date4_actual_date != ""){ 
		$('#trainingdate4actualdate').val(brandStoreObj.training_date4_actual_date);
		$("#trainingdate4actualdate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date4_sub_issue != ""){ 
		$('#trainingdate4subissue').val(brandStoreObj.training_date4_sub_issue);
		$("#trainingdate4subissue").prop("disabled", true);
	}	
	if(brandStoreObj.training_date5_proposed_date != ""){ 
		$('#trainingdate5proposeddate').val(brandStoreObj.training_date5_proposed_date);
		$("#trainingdate5proposeddate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date5_proposed_time != ""){ 
		$('#trainingdate5proposedtime').val(brandStoreObj.training_date5_proposed_time);
		$("#trainingdate5proposedtime").prop("disabled", true);
	}	
	if(brandStoreObj.training_date5_actual_date != ""){ 
		$('#trainingdate5actualdate').val(brandStoreObj.training_date5_actual_date);
		$("#trainingdate5actualdate").prop("disabled", true);
	}	
	if(brandStoreObj.training_date5_sub_issue != ""){ 
		$('#trainingdate5subissue').val(brandStoreObj.training_date5_sub_issue);
		$("#trainingdate5subissue").prop("disabled", true);
	}	
	if(brandStoreObj.brand_store_submission_date != ""){ 
		$('#brandstoresubmissiondate').val(brandStoreObj.brand_store_submission_date);
		$("#brandstoresubmissiondate").prop("disabled", true);
	}	
	if(brandStoreObj.brand_store_approval_date != ""){ 
		$('#brandstoreapprovaldate').val(brandStoreObj.brand_store_approval_date);
		$("#brandstoreapprovaldate").prop("disabled", true);
	}	
	if(brandStoreObj.store_status != ""){ 
		$('#storestatus').val(brandStoreObj.store_status);
		$("#storestatus").prop("disabled", true);
	}
	if(brandStoreObj.additional_issue_sub_issue != ""){ 
		$('#additionalissue-subissue').val(brandStoreObj.additional_issue_sub_issue);
		//$("#additionalissue-subissue").prop("disabled", true);
	}
	if(brandStoreObj.summary != ""){
		$('#summary-div').show(); 
		$('#summary').val(brandStoreObj.summary);
		$("#summary").prop("disabled", true);
	}
	if(brandStoreObj.pitch_date1_remarks != ""){
		$('#pitchdate1remarks').val(brandStoreObj.pitch_date1_remarks);
	}
	if(brandStoreObj.pitch_date2_remarks != ""){
		$('#pitchdate2remarks').val(brandStoreObj.pitch_date2_remarks);
	}
	if(brandStoreObj.training_date1_remarks != ""){
		$('#trainingdate1remarks').val(brandStoreObj.training_date1_remarks);
	}
	if(brandStoreObj.training_date2_remarks != ""){
		$('#trainingdate2remarks').val(brandStoreObj.training_date2_remarks);
	}
	if(brandStoreObj.training_date3_remarks != ""){
		$('#trainingdate3remarks').val(brandStoreObj.training_date3_remarks);
	}
	if(brandStoreObj.training_date4_remarks != ""){
		$('#trainingdate4remarks').val(brandStoreObj.training_date4_remarks);
	}
	if(brandStoreObj.training_date5_remarks != ""){
		$('#trainingdate5remarks').val(brandStoreObj.training_date5_remarks);
	}		
	if(brandStoreObj.contacted_date != ""){
		$('#contacted-date-time-div').show();
		$('#contacteddate').val(brandStoreObj.contacted_date);
	}
	if(brandStoreObj.contacted_time != ""){
		$('#contactedtime').val(brandStoreObj.contacted_time);
	}
	if(brandStoreObj.request_type != ""){
		$('#request-type-div').show();
		$('#requesttype').val(brandStoreObj.request_type);
	}
	if(brandStoreObj.query_status != ""){
		$('#query-status-div').show();
		$('#querystatus').val(brandStoreObj.query_status);
	}
	if(brandStoreObj.query_remarks != ""){
		$('#query-remarks-div').show();
		$('#queryremarks').val(brandStoreObj.query_remarks);
	}	
	}



$(function(){
    $('#retrieveCategory').on('change', function(){
        var val = $(this).val();
        
		if(val === ""){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$("#retrieveCategory").css({"width":"25%","margin-left":"30%"});
			$('#filterAgentName').hide();
			$('#emptySelect').show();
		}
		else if(val === "agent_name"){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$("#retrieveCategory").css({"width":"25%","margin-left":"30%"});
			$('#filterAgentName').show();
			$('#emptySelect').hide();
			
			$.ajax({
				url: "static/csv/brandsStoreTracker.csv",
				async: false,
				success: function (csvd) {
					associatesNameData = data = csvd.split('\n');
				},
				dataType: "text",
				complete: function () {
					var list = associatesNameData;
					var sel = document.getElementById('filterAgentName');
					var opt = document.createElement('option');
					opt.innerHTML = "-- Select --";
					sel.appendChild(opt);
					for(var i = 0; i < list.length; i++) {
						opt = document.createElement('option');
						opt.innerHTML = list[i];
						sel.appendChild(opt);
					}
				}
			});
		}
		else if(val === "pitch_date"){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$("#retrieveCategory").css({"width":"25%","margin-left":"5%"});
			$('#filterAgentName').hide();
			$('#emptySelect').hide();
			$('#filterFromDate').show();
			$('#filterToDate').show();
		}
    });
});


function JSONToCSVConvertor(data) {
	
	var jsonDstData = JSON.stringify(data);
	var jsonObj = JSON.parse(jsonDstData);
	var JSONData = JSON.stringify(jsonObj.bst);
	var parseData = JSON.parse(JSONData);

	/* create workbook & set props*/
	const wb = { SheetNames: [], Sheets: {} };
	wb.Props = {
		  Title: "Brand Store Data",
		  Author: "Unknown"
	};

	/*create sheet data & add to workbook*/
	var ws = XLSX.utils.json_to_sheet(parseData);
	var ws_name = "Brand Store Data";
	XLSX.utils.book_append_sheet(wb, ws, ws_name);
	XLSX.writeFile(wb, "Brand_Store_Tracker.xlsx");
}
