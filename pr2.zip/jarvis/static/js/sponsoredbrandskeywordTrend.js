google.charts.load("current", {'packages':["corechart"]});
google.charts.load('current', {'packages':['corechart', 'controls']});
google.charts.load('current', {'packages': ['corechart', 'line']});
google.charts.load('current', {'packages':['table']});
google.charts.setOnLoadCallback(drawImpressionChart);

function analyzeKeyword(){
	var keyword = $('#keyword').val();
	window.sessionStorage.setItem("keyword",keyword);
}

function formatDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return new Date([month, day, year].join('/'));
}

function drawImpressionChart() {
	
	var keyword = window.sessionStorage.getItem("keyword");
	var csvData = window.sessionStorage.getItem("csvData");
	
	var dataTableArr = $.csv.toArrays(csvData);
	var dataTableData = new google.visualization.arrayToDataTable(dataTableArr,false); 
	
	dataTableData.insertColumn(0, 'date', 'StartDate');
	dataTableData.insertColumn(8, 'number', 'Impressions');
	dataTableData.insertColumn(10, 'number', 'Clicks');
	dataTableData.insertColumn(13, 'number', 'cpc');
	
	for (var i = 0; i < dataTableData.getNumberOfRows(); i++) {
		var val1 = dataTableData.getValue(i, 1);
		if (val1 != '' && val1 != null) {
			console.log(formatDate(val1));
			dataTableData.setValue(i, 0, formatDate(val1));
		}
		var val2 = dataTableData.getValue(i, 9);
		if (val2 != '' && val2 != null) {
			dataTableData.setValue(i, 8, new Number(val2).valueOf());
		}
		var val3 = dataTableData.getValue(i, 11);
		if (val3 != '' && val3 != null) {
			dataTableData.setValue(i, 10, new Number(val3).valueOf());
		}
		var val4 = dataTableData.getValue(i, 14);
		if (val4 != '' && val4 != null) {
			val4 = val4.replace('₹ ','');
			dataTableData.setValue(i, 13, new Number(val4).valueOf());
		}
	}
	
	
	var impressionSlider = new google.visualization.ControlWrapper({
		'controlType': 'DateRangeFilter',
		'containerId': 'impressions_control_div',
		'options': {
			'filterColumnLabel': 'StartDate'
		}
	});
	
	var impressionsChart = new google.visualization.ChartWrapper({
		'chartType': 'ColumnChart',
		'containerId': 'impressions_div',
		'options': {
			'title': "Impression Count of the keyword",
			'width': 1300,
			'height': 400,
			'legend': 'right',
			'hAxis': {'title': 'Date'},
			'vAxis': {'title': 'Impressions'},
			'alternatingRowStyle': true
		}		
	});
	
	var clicksOptions = {
        title: "Clicks on the keyword",
		width: 1300,
		height: 400,
		hAxis: {'title': 'Date'},
		vAxis: {'title': 'Clicks'},
		bar: {groupWidth: "95%"},
		legend: { position: "right" }
    };
	
	var cpcOptions = {
        title: "Keyword Bid Value",
		width: 1300,
		height: 400,
		curve: 'function',
		hAxis: {'title': 'Date'},
		vAxis: {'title': 'CPC in Rupees'},
        legend: { position: 'right' }
    };
	
	
	var impressionsview = new google.visualization.DataView(dataTableData);
	impressionsview.setRows(dataTableData.getFilteredRows([{column: 6, value: keyword}]));	
	impressionsview.setColumns([0, 8]);			   
	var impressionDashboard = new google.visualization.Dashboard(document.getElementById('impressions_div'));
	impressionDashboard.bind(impressionSlider,impressionsChart);
	impressionDashboard.draw(impressionsview);
	
	google.visualization.events.addListener(impressionsChart, 'ready', function () {
		
		var startDate = impressionSlider.getState();
		var newDataTable = dataTableData.clone();
		
		var clicksView = new google.visualization.DataView(newDataTable);
		clicksView.setRows(newDataTable.getFilteredRows([{column: 0, minValue: startDate.lowValue, maxValue:startDate.highValue},{column: 6, value: keyword}]));	
		clicksView.setColumns([0, 10]);		
		var clicksDashboard = new google.visualization.ColumnChart(document.getElementById('clicks_div'));
		clicksDashboard.draw(clicksView,clicksOptions);
		
		newDataTable.sort([{column:0}]);
		var cpcView = new google.visualization.DataView(newDataTable);
		cpcView.setRows(newDataTable.getFilteredRows([{column: 0, minValue: startDate.lowValue, maxValue:startDate.highValue},{column: 6, value: keyword}]));
		cpcView.setColumns([0, 13]);	
		var cpcDashboard = new google.visualization.LineChart(document.getElementById('cpc_div'));
		cpcDashboard.draw(cpcView,cpcOptions);
	});
	
	$("#keywordTrend").text("Showing the keyword trend of - " + keyword); 
}


