$("#post_brandstore").click(function(){
		
		event.preventDefault();
	
		var siteurl = "https://amsjarvis.cognizant.com/insert_into_brandstore_quality_form"
		
		if($('#entrydate').val() === ""){
			alert("Please enter entry date");
			return false;
		}
		else if($('#entityid').val() === ""){
			alert("Please enter entity id");
			return false;
		}
		else if($('#brandnamebrandstore').val() === ""){
			alert("Please enter brand name");
			return false;
		}
		else if($('#storesubmissiondate').val() === "" || $('#atleast2pagesunderhomepage').val() === "" || $('#atleast1productgridoneachpage').val() === "" || $('#use3differenttiletypesonhomepage').val() === "" || $('#top2widgetstobeclickable').val() === "" || $('#ctaonimagetilesifactionable').val() === "" || $('#useofmobileoptimizationfeatureforimagetiles').val() === ""){
			alert("Please select required fields");
			return false;
		}
    else if($('#rejectioncount').val() === ""){
			alert("Please enter rejection count");
			return false;
		}
		else { 
			var data = {
				"entry_date": $('#entrydate').val(),
				"entity_id": $('#entityid').val(),
				"brand_name_brandstore": $('#brandnamebrandstore').val(),
				"store_submission_date": $('#storesubmissiondate').val(),
				"atleast_2_pages_under_home_page": $('#atleast2pagesunderhomepage').val(),
				"atleast_1_product_grid_on_each_page": $('#atleast1productgridoneachpage').val(),
				"use_3_different_tile_types_on_home_page": $('#use3differenttiletypesonhomepage').val(),
				"top_2_widgets_to_be_clickable": $('#top2widgetstobeclickable').val(),
				"cta_on_image_tiles_if_actionable": $('#ctaonimagetilesifactionable').val(),
				"use_of_mobile_optimization_feature_for_image_tiles": $('#useofmobileoptimizationfeatureforimagetiles').val(),
				"rejection_count": $('#rejectioncount').val(),
				};
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Brand Store Quality form response recorded successfully");
					location.reload();					
				},
				error: function (error) {
					alert("Error occured while recording quality form response. Please resubmit");
					location.reload();
				}
			});
		}
 });
