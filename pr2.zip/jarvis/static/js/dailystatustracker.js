$(document).ready(function(){
	
	var toast = new iqwerty.toast.Toast();
	var data;
	var callStartTime;
	var callStopTime;
	var maxDate;
	if(window.sessionStorage.getItem("callStartTime")){
		$("#start-call").prop('disabled', true);
	}else{
		$("#stop-call").prop('disabled', true);
	}

	$('#communicationestablished').children('option:gt(0)').hide();
    
	$('#communicationtype').change(function() {	
		if($('#communicationtype').val() === "Phone" || $('#communicationtype').val() === "Phone and E-mail"){
			$('#communicationestablished').children('option').hide();
			$('#communicationestablished').val("");
			$('#communicationestablished').children('option[value="Yes"]').show();
			$('#communicationestablished').children('option[value^="Ring"]').show();
		}
		else if($('#communicationtype').val() === "E-mail"){
			$('#communicationestablished').val("Yes");
			$('#communicationestablished').children('option').hide();
		}
		else if($('#communicationtype').val() === "None"){
			$('#communicationestablished').val("No");
			$('#communicationestablished').children('option').hide();
		}
    else if($('#communicationtype').val() === ""){
			$('#communicationestablished').val("");
		}
    });		
	
  $.ajax({
		url: "https://amsjarvis.cognizant.com/retrieve_associate_team_name",
		type: "POST",
		data: {},
		headers: {
		         "Accept": "application/json",
					   "Content-Type": "application/json"
		},
		success: function (teamname) {        
		         $("#teamname").val(teamname.toString());								
		},
		error: function (error) {
					alert('Not able to fecth teamname. Please select manually!!');
		}
	});

 $.ajax({
		url: "https://amsjarvis.cognizant.com/retrieve_associate_name",
		type: "POST",
		data: {},
		headers: {
		         "Accept": "application/json",
					   "Content-Type": "application/json"
		},
		success: function (associatename) {        
		         window.sessionStorage.setItem("associatename", associatename.toString());						
		},
		error: function (error) {
					alert('Not able to fetch associate name. Please log out and log in again!!');            
		}
	});
	
	$.ajax({
		url: "static/csv/pexteam.csv",
		async: false,
		dataType: "text",
		success: function (csvd) {
			pexNameData = data = csvd.split('\n');
		},
		complete: function () {
			for(var i = 0; i < pexNameData.length; i++) {
				associateName = window.sessionStorage.getItem("associatename");
				//console.log(pexNameData[i].toString());
				//console.log(associateName.toString());
				if(pexNameData[i].toString().trim() !== associateName.toString().trim()){
					console.log('if');
					$('#filtercategory').val('createdby');
					$('#filtercategory').prop("disabled", true);
					$('.filterSubCategory').prop("disabled", true);
				}
				else if(pexNameData[i].toString().trim() === associateName.toString().trim()){
					$('#filtercategory').val('');
					$('#filtercategory').prop("disabled", false);
					$('.filterSubCategory').prop("disabled", false);
					console.log('else');
					break;
				}
			}
		}
	});
   
	$.ajax({
		url: "static/csv/brands.csv",
		async: false,
		success: function (csvd) {
			csvd = csvd.replace(/\n|\r/g, ",");
			csvd = csvd.replace(/,,/g, ",");
			data = csvd.split(',');
		},
		dataType: "text",
		complete: function () {
			
		}
	});

	var brands = [];	
	for (var i = 0; i < data.length; i += 2) {
	  var val = {};
	  val[data[i]] = data[i + 1];
	  brands.push(val);
	}
	
	$("#brandid").on("change input",function (event) {		
		
		var key = $('#brandid').val();
		var value;
		if(typeof brands.find(b => key.indexOf(Object.keys(b)) > -1) !== 'undefined'){
			value = brands.find(b => key.indexOf(Object.keys(b)) > -1)[key];
			$("#brandname:text").val(value);
		}else{
			$("#brandname:text").val('');
		}
	});
	 
	$("#existingcampaign").on("keypress keyup blur",function (event) {    
           $(this).val($(this).val().replace(/[^\d].+/, ""));
            if ((event.which < 48 || event.which > 57)) {
                event.preventDefault();
            }
    });
	
	$("#campaignnewlyadded").on("keypress keyup blur",function (event) {    
           $(this).val($(this).val().replace(/[^\d].+/, ""));
            if ((event.which < 48 || event.which > 57)) {
                event.preventDefault();
            }
    });	
	
	$("#start-call").click(function(){
		$("#start-call").prop('disabled', true);
		$("#stop-call").prop('disabled', false);
		
		var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		currentDateTime = new Date(currentDateTime); 
		callStartTime = currentDateTime.toString('MM-dd-yyyy hh:mm:ss');
		window.sessionStorage.setItem("callStartTime", callStartTime);
	});
	
	$("#stop-call").click(function(){
		
		var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		currentDateTime = new Date(currentDateTime); 
		callStopTime = currentDateTime.toString('MM-dd-yyyy hh:mm:ss');
		window.sessionStorage.setItem("callStopTime", callStopTime);
			
		event.preventDefault();
		
		var siteurl = "https://amsjarvis.cognizant.com/insert_into_dst"
		
		var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		currentDateTime = new Date(currentDateTime);
		
		if($('#brandid').val() === ""){
			alert("Brand ID must be filled out");
			return false;
		}
		else if($('#brandname').val() === ""){
			alert("Brand Name must be filled out");
			return false;
		}
		else if($('#issuecategory').val() === ""){
			alert("Please select Issue Category");
			return false;
		}
		else if($('#issuesubcategory').val() === ""){
			alert("Please select Issue Sub Category");
			return false;
		}
		else if($('#casenotes').val() === ""){
			alert("Case notes must be filled out");
			return false;
		}
		else if($('#escalationRequired').val() === ""){
			alert("Please select escalation rqeuired");
			return false;
		}
    else if($('#teamname').val() === ""){
			alert("Please select team name");
			return false;
		}
   	else if($('#communicationtype').val() === ""){
			alert("Please select communication type");
			return false;
		}
		else if($('#communicationestablished').val() === ""){
			alert("Please select communication established");
			return false;
		}
		else { 
			var data = {
				"formid":$.now().toString(),
				"date": currentDateTime.toString('MM-dd-yyyy hh:mm:ss'),
				"teamname": $('#teamname').val(),
				"brandname": $('#brandname').val(),
        "parentbrandname": $('#parentbrandname').val(),
				"brandid": $('#brandid').val(), 
				"numberofexistingcampaign": $('#existingcampaign').val(),
				"numberofcampaignnewlyadded": $('#campaignnewlyadded').val(),
				"issuecategory": $('#issuecategory').val(),
				"sboptimization": $('#sboptimization').val(),
				"sboptimizationcategory": $('#sboptimizationcategory').val().toString(),
				"issuesubcategory": $('#issuesubcategory').val(),
				"casenotes": $('#casenotes').val(),
				"communicationtype": $('#communicationtype').val(),
				"communicationestablished": $('#communicationestablished').val(),
				"followupdate": $('#followupdate').val(),
				"additionalissuediscussed":$("#additionalissuediscussed").val().toString(),
				"escalationrequired":$("#escalationRequired").val(),
				"sponsoredbrandactive":$("#sponsoredbrandactive").val(),
				"inactivebrand":$("#inactivebrand").val(),
				"callstarttime":window.sessionStorage.getItem("callStartTime"),
				"callstoptime":window.sessionStorage.getItem("callStopTime"),
				"associatename":window.sessionStorage.getItem("associatename")
				
			};
			
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					toast.setText('Call time recorded successfully!').show();					
				},
				error: function (error) {
					toast.setText('Call time recording failed!').show();
				}
			});
			
			setTimeout(function(){
						location.reload(); 
			}, 2000); 
			
			window.sessionStorage.removeItem("callStartTime");
			window.sessionStorage.removeItem("callStopTime");
			$("#start-call").prop('disabled', false);
		}
			
	});
	
	$("#issuecategory").on("change",function (event) {
		if($('#issuecategory').val() === "Optimization"){
			$('#sboptimizationselection').show();
		}else{
			$('#sboptimizationselection').hide();
			$('#sboptimizationcategoryselection').hide();
			$('#sboptimizationcategory').val("");
			$('#sboptimizationcategoryselection').val("");
		}	
        });
	$("#sboptimization").on("change",function (event) {
		if($('#sboptimization').val() === "yes"){
			$('#sboptimizationcategoryselection').show();
		}else{
			$('#sboptimizationcategoryselection').hide();
			$('#sboptimizationcategoryselection').val("");
		}	
		});
	
	$("#post").click(function(){
		
		event.preventDefault();
		
		var siteurl = "https://amsjarvis.cognizant.com/insert_into_dst"
		
		var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		currentDateTime = new Date(currentDateTime);
		
		if($('#brandid').val() === ""){
			alert("Brand ID must be filled out");
			return false;
		}
		else if($('#brandname').val() === ""){
			alert("Brand Name must be filled out");
			return false;
		}
		else if($('#issuecategory').val() === ""){
			alert("Please select Issue Category");
			return false;
		}
		else if($('#issuesubcategory').val() === ""){
			alert("Please select Issue Sub Category");
			return false;
		}
		else if($('#casenotes').val() === ""){
			alert("Case notes must be filled out");
			return false;
		}
		else if($('#escalationRequired').val() === ""){
			alert("Please select escalation required");
			return false;
		}
		else if($('#teamname').val() === ""){
			alert("Please select team name");
			return false;
		}
   	else if($('#communicationtype').val() === ""){
			alert("Please select communication type");
			return false;
		}
		else if($('#communicationestablished').val() === ""){
			alert("Please select communication established");
			return false;
		}
		else { 
			var data = {
				"formid":$.now().toString(),
				"date": currentDateTime.toString('MM-dd-yyyy hh:mm:ss'),
				"teamname": $('#teamname').val(),
				"brandname": $('#brandname').val(),
				"parentbrandname": $('#parentbrandname').val(),
				"brandid": $('#brandid').val(), 
				"numberofexistingcampaign": $('#existingcampaign').val(),
				"numberofcampaignnewlyadded": $('#campaignnewlyadded').val(),
				"issuecategory": $('#issuecategory').val(),
				"sboptimization": $('#sboptimization').val(),
				"sboptimizationcategory": $('#sboptimizationcategory').val().toString(),
				"issuesubcategory": $('#issuesubcategory').val(),
				"casenotes": $('#casenotes').val(),
				"communicationtype": $('#communicationtype').val(),
				"communicationestablished": $('#communicationestablished').val(),
				"followupdate": $('#followupdate').val(),
				"additionalissuediscussed":$("#additionalissuediscussed").val().toString(),
				"escalationrequired":$("#escalationRequired").val(),
				"sponsoredbrandactive":$("#sponsoredbrandactive").val(),
				"inactivebrand":$("#inactivebrand").val(),
        "associatename":window.sessionStorage.getItem("associatename")
			};
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(data),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Data uploaded successfully"); 
					location.reload();					
				},
				error: function (error) {
					alert(JSON.stringify(error));
					location.reload();
				}
			});
		}
    });
	
	$(function(){
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		if(month < 10)
			month = '0' + month.toString();
		if(day < 10)
			day = '0' + day.toString();
		maxDate = year + '-' + month + '-' + day;		
		$('#filterFromDate').attr('max', maxDate);
	});
	
	$("#filterFromDate").on("input",function (event) {
		var dateString = document.getElementById('filterFromDate').value;
        $('#filterToDate').attr('min', dateString);
		$('#filterToDate').attr('max', maxDate);
	});
	
/*$.ajax({
	url: "https://amsjarvis.cognizant.com/retrieve_associate_name",
	type: "POST",
	data: {},
	headers: {
			 "Accept": "application/json",
				   "Content-Type": "application/json"
	},
	success: function (associatename) {        
	var loginassociatename=associatename;
	$.ajax({
			url: "static/csv/pexteam.csv",
			//async: false,
			success: function (csvd) {
				associatesNameData = data = csvd.split('\n');
			},
			//dataType: "text",
			complete: function () {
				//var associatesNameData;
				var list = associatesNameData;
				for(var i = 0; i <= list.length-2; i++) {
					console.log(loginassociatename);
					console.log(list[i]);
					var listassociate=list[i];
					if(listassociate.trim()==loginassociatename.trim()){
						$('#get').show();
						
					}
					break;
				}
			}
		});
	},
});
$("#filtercategory").on("change",function (event) {
	if($('#filtercategory').val() === "createdby"){
		$('#get').show();
	}else{
		$.ajax({
				url: "https://amsjarvis.cognizant.com/retrieve_associate_name",
				type: "POST",
				data: {},
				headers: {
						 "Accept": "application/json",
							   "Content-Type": "application/json"
				},
				success: function (associatename) {        
				loginassociatename=associatename;
				$.ajax({
						url: "static/csv/pexteam.csv",
						//async: false,
						success: function (csvd) {
							associatesNameData = data = csvd.split('\n');
						},
						//dataType: "text",
						complete: function () {
							//var associatesNameData;
							var list = associatesNameData;
							for(var i = 0; i < list.length-1; i++) {
								//console.log(loginassociatename);
								//console.log(list[i]);
								var listassociate=list[i];
								if(listassociate.trim()!=loginassociatename.trim()){
									$('#get').hide();
								}
								
							}
						}
					});
				},
		});
		
	}	
});*/
	
	
	$("#get").click(function(){

		var siteurl = "https://amsjarvis.cognizant.com/retrieve_dst_data"
		var filterData;
		
		var filterFromDateStr = $("#filterFromDate").val();
		var filterFromDate = new Date(filterFromDateStr);
		filterFromDate = filterFromDate.toString('MM-dd-yyyy 00:00:00');
		
		var  filterToDateStr = $("#filterToDate").val();
		var filterToDate = new Date(filterToDateStr);
		filterToDate = filterToDate.toString('MM-dd-yyyy 24:00:00');
		
		if($('#filtercategory').val() === "date"){
			filterData = {
				"filterCategory": $('#filtercategory').val(),
				"filterFromDate": filterFromDate,
				"filterToDate": filterToDate
			}
		}else if($('#filtercategory').val() === "teamname"){
			filterData = {
				"filterCategory": $('#filtercategory').val(),
				"filterValue": $("#filterTeamName").val()
			}
		}else if($('#filtercategory').val() === "createdby"){
			filterData = {
				"filterCategory": $('#filtercategory').val(),
				"filterValue": $("#filterAgentName").val()
			}
		}else if($('#filtercategory').val() === "issuecategory"){
			filterData = {
				"filterCategory": $('#filtercategory').val(),
				"filterValue": $("#filterIssueCategory").val()
			}
		}else if($('#filtercategory').val() === "brandid"){
			filterData = {
				"filterCategory": $('#filtercategory').val(),
				"filterValue": $("#filterBrandId").val()
			}
		}else if($('#filtercategory').val() === ""){
			filterData = {
				"filterCategory": "",
				"filterValue": ""
			}
		}
		
		$.ajax({
			url: siteurl,
			type: "POST",
			data: JSON.stringify(filterData),
							dataType: 'json',
			headers: {
				"Accept": "application/json",
									"Content-Type": "application/json"
			},
			success: function (data) {
				JSONToCSVConvertor(data, true);
			},
			error: function (error) {
				alert(JSON.stringify(error));
			}
		});
	});
});


$(function(){
    $('#issuecategory').on('change', function(){
        var val = $(this).val();
        var sub = $('#issuesubcategory');
			$('option', sub).filter(function(){
				if (
					 $(this).attr('data-group') === val 
				  || $(this).attr('data-group') === 'SHOW'
				) {
				  if ($(this).parent('span').length) {
					$(this).unwrap();
				  }
				} else {
				  if (!$(this).parent('span').length) {
					$(this).wrap( "<span>" ).parent().hide();
				  }
				}
			});
		
		
    });
    $('#issuecategory').trigger('change');
});


$(function(){
    $('#filtercategory').on('change', function(){
        var val = $(this).val();
        
		if(val === "teamname" || val === ""){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterAgentName').hide();
			$('#filterBrandId').hide();
			$('#filterIssueCategory').hide();
			$("#filtercategory").css({"margin-left":"37%"});
			$('#filterTeamName').show();
			var sub = $('#filterTeamName');
			$('option', sub).filter(function(){
				if (
					 $(this).attr('data-group') === val 
				  || $(this).attr('data-group') === 'SHOW'
				) {
				  if ($(this).parent('span').length) {
					$(this).unwrap();
				  }
				} else {
				  if (!$(this).parent('span').length) {
					$(this).wrap( "<span>" ).parent().hide();
				  }
				}
			});
		}
		else if(val === "date"){
			$('#filterTeamName').hide();
			$("#filtercategory").css({"margin-left":"21%"});
			$('#filterAgentName').hide();
			$('#filterBrandId').hide();
			$('#filterIssueCategory').hide();
			$('#filterFromDate').show();
			$('#filterToDate').show();
		}
		else if(val === "createdby"){
			$('#filterTeamName').hide();
			$("#filtercategory").css({"margin-left":"37%"});
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterBrandId').hide();
			$('#filterIssueCategory').hide();
			$('#filterAgentName').show();
			var associatesNameData = window.sessionStorage.getItem("associatename");
			var sel = document.getElementById('filterAgentName');
			if ( $("#filterAgentName option[value='"+associatesNameData+"']").length == 0 ){
				var opt = document.createElement('option');
				opt.innerHTML = associatesNameData;
				opt.value=associatesNameData
				sel.appendChild(opt);
			}
				
		}
		
		else if(val === "issuecategory"){
			$('#filterTeamName').hide();
			$("#filtercategory").css({"margin-left":"37%"});
			$('#filterAgentName').hide();
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterBrandId').hide();
			$('#filterIssueCategory').show();
			
			var sub = $('#filterIssueCategory');
			$('option', sub).filter(function(){
				if (
					 $(this).attr('data-group') === val 
				  || $(this).attr('data-group') === 'SHOW'
				) {
				  if ($(this).parent('span').length) {
					$(this).unwrap();
				  }
				} else {
				  if (!$(this).parent('span').length) {
					$(this).wrap( "<span>" ).parent().hide();
				  }
				}
			});
		}
		else if(val === "brandid"){
			$('#filterTeamName').hide();
			$("#filtercategory").css({"margin-left":"37%"});
			$('#filterAgentName').hide();
			$('#filterIssueCategory').hide();
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterBrandId').show();
		}
    });
    $('#filtercategory').trigger('change');
});


function JSONToCSVConvertor(data, ShowLabel){

         var jsonDstData = JSON.stringify(data);
         var jsonObj = JSON.parse(jsonDstData);
	       var JSONData = JSON.stringify(jsonObj.dst);
         var parseData = JSON.parse(JSONData);
         
         /* create workbook & set props*/
         const wb = { SheetNames: [], Sheets: {} };
         wb.Props = {
                  Title: "DST Data",
                  Author: "Unknown"
         };

         /*create sheet data & add to workbook*/
         var ws = XLSX.utils.json_to_sheet(parseData);
         var ws_name = "DST Data";
         XLSX.utils.book_append_sheet(wb, ws, ws_name);
         XLSX.writeFile(wb, "Daily_Status_Tracker.xlsx");
}



$(document).change(function () {
    if($('#brandid').val() && $('#brandname').val() && $('#issuecategory').val() && $('#issuesubcategory').val() && 
       $('#casenotes').val() && $('#escalationRequired').val()){
	   var lastCaseNotesDetails = "Brand ID: " + $('#brandid').val() + "<br />" +
	   "Brand Name: " + $('#brandname').val() + "<br />" +
	   "Number Of Existing Campaign: " + $('#existingcampaign').val() + "<br />" +
	   "Number Of Campaign Newly Added: " + $('#campaignnewlyadded').val() + "<br />" +
	   "Issue Category: " + $('#issuecategory').val() + "<br />" +
	   "Issue Sub Category: " + $('#issuesubcategory').val() + "<br />" +
	   "Case Notes: " + $('#casenotes').val(); 
	   $(".modal-body #lastCaseNotesDetails").html(lastCaseNotesDetails);
	   $('#lastCaseNotesModal').modal('show');		
	}
});