$(document).ready(function(){
	
	$('#form-container').hide();
	$('#sellerRemovedDate').hide();

	
	$('#addNewSeller').click(function(){
		$("#horizontalform").trigger("reset");
		$("#merchantid").prop("readonly", false);
		$("#sellername").prop("readonly", false);
		$("#allocationDateToCTS").prop("disabled", false);
		$('#form-container').show();
		$("#submit_seller").show();
	});
 
 
 	var searchseller = document.getElementById("searchMerchantId");
	searchseller.addEventListener("keyup", function(event) {
  		if (event.keyCode === 13) {
   			event.preventDefault();
   			document.getElementById("modifySeller").click();
  		}
	});
 
 	$(function(){
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		if(month < 10)
			month = '0' + month.toString();
		if(day < 10)
			day = '0' + day.toString();
		maxDate = year + '-' + month + '-' + day;		
		$('#allocationDateToCTS').attr('max', maxDate);
		$('#removedDate').attr('max', maxDate);
	});
	$("#merchantid").on("change input",function (event) {
	var merchantid = {"merchantid":$('#merchantid').val()} 
      $.ajax({
				url: "https://amsjarvis.cognizant.com/check_merchant_id",
				type: "POST",
				data: JSON.stringify(merchantid),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
				  if(data !== ""){
                  alert(data);
                  location.reload();
             }   
				},
				error: function (error) {
				location.reload();
				}
		  });   
	});
	
	$("#sellerStatus").on("change",function (event) {
		if($('#sellerStatus').val() === "Removed"){
			$('#sellerRemovedDate').show();
		}else{
			$('#sellerRemovedDate').hide();
			$('#removedDate').val("");
		}	
        });

	
	$("#submitseller").click(function(){
		
		event.preventDefault();
		
		var siteurl = "https://amsjarvis.cognizant.com/insertinto_seller_mdm"
		
		if($('#merchantid').val() === ""){
			alert("Merchant ID must be filled out");
			return false;
		}
		else if($('#sellername').val() === ""){
			alert("Seller Name must be filled out");
			return false;
		}
		else if($('#brandname').val() === ""){
			alert("Brand Name must be filled out");
			return false;
		}
		else if($('#teamname').val() === ""){
				alert("Please select teamname");
				return false;
		}
		else if($('#casenotes1').val() === ""){
				alert("Case notes must be filled out");
				return false;
		}
	    else if($('#contacted').val() === ""){
				alert("Please select contacted");
				return false;
		}
	    else if($('#accessgranted').val() === ""){
				alert("Please select accessgranted");
				return false;
		}
		else if($('#allocationDateToCTS').val() === ""){
				alert("Please select Allocation Date To CTS");
				return false;
		}
	    else if($('#sellerpocPrimary').val() === ""){
				alert("POC - Primary must be filled out.");
				return false;
		}
		else if($('#sellerphonePrimary').val() === ""){
				alert("Phone - Primary must be filled out");
				return false;
		}
		else if($('#selleremailPrimary').val() === ""){
				alert("Email - Primary must be filled out");
				return false;
		}
		else if($('#sellerStatus').val() === ""){
				alert("SellerStatus must be filled out");
				return false;
		}
		else if($('#sellerStatus').val() === "Removed" && $('#removedDate').val() === ""){
				alert("Please select brand removed date");
				return false;
		}
	    else if($('#brandstore').val() === ""){
				alert("Brand Store must be filled out");
				return false;
		}
	    else if($('#ctsAMName').val() === ""){
				alert("CTS AM Name must be filled out");
				return false;
		}
	    else if($('#pitchedcredits').val() === ""){
				alert("Pitched Credits must be filled out");
				return false;
		}						
		else {
			var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
			currentDateTime = new Date(currentDateTime); 
			var sellermdmdata = {
				"merchantid":$('#merchantid').val(),
				"sellername":$('#sellername').val(), 
				"teamname":$('#teamname').val(),
				"monthlybudget":$('#monthlybudget').val(),
				"casenotes1":$('#casenotes1').val(),
				"contacted":$('#contacted').val(),
				"accessgranted":$('#accessgranted').val(),
				"actioned":$('#actioned').val(),
				"allocationDateToCTS":$('#allocationDateToCTS').val(),
				"sellerpocPrimary":$('#sellerpocPrimary').val(),
				"sellerpocSecondary":$('#sellerpocSecondary').val(),
				"sellerphonePrimary":$('#sellerphonePrimary').val(),
				"sellerphoneSecondary":$('#sellerphoneSecondary').val(),
				"selleremailPrimary":$('#selleremailPrimary').val(),
				"selleremailSecondary":$('#selleremailSecondary').val(),
				"sellerStatus":$('#sellerStatus').val(),
				"removedDate":$('#removedDate').val(),
				"brandstore":$('#brandstore').val(),
				"ctsAMName":$('#ctsAMName').val(),
				"numberofsubbrands":$('#numberofsubbrands').val(),
				"pitchedcredits":$('#pitchedcredits').val(),
				"date":currentDateTime.toString('MM-dd-yyyy'),
			}
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(sellermdmdata),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Data uploaded successfully"); 
					location.reload();					
				},
				error: function (error) {
					alert(JSON.stringify(error));
					location.reload();
				}
			});
		}
 	});
	
	$("#modifySeller").click(function(){
		
		$("#submitseller").show();
	
		if($('#searchMerchantId').val() === ""){
			$('#form-container').hide();
				alert("Please enter Brand ID!!");
				return false;
        	}else{
				var siteurl = "https://amsjarvis.cognizant.com/retrieve_seller_data"
				var merchantdata = {"merchantid":$('#searchMerchantId').val()}

				$.ajax({
					url: siteurl,
					type: "POST",
					data: JSON.stringify(merchantdata),
								dataType: 'json',
					headers: {
						"Accept": "application/json",
						"Content-Type": "application/json"
						},
						success: function (data) {
							displayJsonData(data, true);
						},
						error: function (error) {
							alert(JSON.stringify(error));
						}
				});
			}
    	});
	
	$("#sellerDetails").click(function(){
		
		$("#submit_seller").hide();
		
		if($('#searchMerchantId').val() === ""){
			$('#form-container').hide();
			alert("Please enter Merchant ID!!");
			return false;
        }else{
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_seller_details"
			var merchantdata = {"merchantid":$('#searchMerchantId').val()}

			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(merchantdata),
							dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
					},
					success: function (data) {
						displayJsonData(data, true);
					},
					error: function (error) {
						alert(JSON.stringify(error));
					}
			});
		}
    });
	
	
	$("#exportData").click(function(){

		var siteurl = "https://amsjarvis.cognizant.com/retrieve_seller_report"
		var filterData = {};
		
		var filterFromDateStr = $("#filterFromDate").val();
		var filterFromDate = new Date(filterFromDateStr);
		filterFromDate = filterFromDate.toString('yyyy-MM-dd');
		
		var  filterToDateStr = $("#filterToDate").val();
		var filterToDate = new Date(filterToDateStr);
		filterToDate = filterToDate.toString('yyyy-MM-dd');
		
		if($('#retrieveSellerCategory').val() === "allocationDateToCTS"){
			filterData = {
				"filterCategory": $('#retrieveSellerCategory').val(),
				"filterFromDate": filterFromDate,
				"filterToDate": filterToDate
			}
		}else if($('#retrieveSellerCategory').val() === "teamname"){
			filterData = {
				"filterCategory": $('#retrieveSellerCategory').val(),
				"filterValue": $("#filterTeamName").val()
			}
		}else if($('#retrieveSellerCategory').val() === "sellerStatus"){
			filterData = {
				"filterCategory": $('#retrieveSellerCategory').val(),
				"filterValue": $("#filterSellerStatus").val()
			}
		}else if($('#retrieveSellerCategory').val() === ""){
			filterData = {
				"filterCategory": "",
				"filterValue": ""
			}
		}
		
			
		$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(filterData),
                                dataType: 'json',
				headers: {
					"Accept": "application/json",
                    			"Content-Type": "application/json"
				},
				success: function (data) {	
					JSONToCSVConvertor(data, true);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
		});
    });
	
});


function displayJsonData(data){
	
    
	var jsonsellerData = JSON.stringify(data);
	var sellerObj = JSON.parse(jsonsellerData);
	
	$("#merchantid").val(sellerObj.merchantid);
	$("#merchantid").prop("readonly", true);
	$("#sellername").val(sellerObj.sellername); 
	$("#sellername").prop("readonly", true);
	$("#teamname").val(sellerObj.teamname);
	$("#monthlybudget").val(sellerObj.monthlybudget);
	$("#casenotes1").val(sellerObj.casenotes1);
	$("#contacted").val(sellerObj.contacted);
	$("#accessgranted").val(sellerObj.accessgranted);
	$("#actioned").val(sellerObj.actioned);
	$("#allocationDateToCTS").val(sellerObj.allocationDateToCTS);
	$("#allocationDateToCTS").prop("readonly", true);
	$("#sellerpocPrimary").val(sellerObj.sellerpocPrimary);
  	$("#sellerpocSecondary").val(sellerObj.sellerpocSecondary);
  	$("#sellerphonePrimary").val(sellerObj.sellerphonePrimary);
    $("#sellerphoneSecondary").val(sellerObj.sellerphoneSecondary);
	$("#selleremailPrimary").val(sellerObj.selleremailPrimary);
	$("#selleremailSecondary").val(sellerObj.selleremailSecondary);
	$("#sellerStatus").val(sellerObj.sellerStatus);
	if(sellerObj.sellerStatus == "Removed"){
		$('#sellerRemovedDate').show();
		$("#removedDate").val(sellerObj.removedDate);
	}
	$("#brandstore").val(sellerObj.brandstore);
	$("#ctsAMName").val(sellerObj.ctsAMName);
	$("#numberofsubbrands").val(sellerObj.numberofsubbrands);
	$("#pitchedcredits").val(sellerObj.pitchedcredits);
	$("#brandmodificationdate").val(sellerObj.brandmodificationdate);
	$('#form-container').show();
	window.sessionStorage.setItem("teamname", sellerObj.teamname)
	
}



$(function(){
    $('#retrieveSellerCategory').on('change', function(){
        var val = $(this).val();
        
		if(val === "teamname" || val === ""){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterSellerStatus').hide();
			$("#retrieveSellerCategory").css({"width":"40%","margin-left":"8%"});
			$('#filterTeamName').show();
			
			var sub = $('#filterTeamName');
			$('option', sub).filter(function(){
				if (
					 $(this).attr('data-group') === val 
				  || $(this).attr('data-group') === 'SHOW'
				) {
				  if ($(this).parent('span').length) {
					$(this).unwrap();
				  }
				} else {
				  if (!$(this).parent('span').length) {
					$(this).wrap( "<span>" ).parent().hide();
				  }
				}
			});
		}
		else if(val === "allocationDateToCTS"){
			$('#filterTeamName').hide();
			$("#retrieveSellerCategory").css({"width":"23%", "margin-left":"0%"});
			$('#filterSellerStatus').hide();
			$('#filterFromDate').show();
			$('#filterToDate').show();
		}
		else if(val === "sellerStatus"){
			$('#filterTeamName').hide();
			$("#retrieveSellerCategory").css({"width":"40%","margin-left":"8%"});
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$('#filterSellerStatus').show();
		}
    });
    //$('#filtercategory').trigger('change');
});


function JSONToCSVConvertor(data, ShowLabel) {
	
	console.log(JSON.stringify(data));
	var jsonSellerData = JSON.stringify(data);
	var jsonObj = JSON.parse(jsonSellerData);
	var JSONData = JSON.stringify(jsonObj.seller);
         var parseData = JSON.parse(JSONData);
         
         /* create workbook & set props*/
         const wb = { SheetNames: [], Sheets: {} };
         wb.Props = {
                  Title: "Seller MDM Data",
                  Author: "Unknown"
         };

         /*create sheet data & add to workbook*/
         var ws = XLSX.utils.json_to_sheet(parseData);
         var ws_name = "Seller MDM Data";
         XLSX.utils.book_append_sheet(wb, ws, ws_name);
         XLSX.writeFile(wb, "Seller_MDM_Report.xlsx");
}
