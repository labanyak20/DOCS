$(document).ready(function(){
	$("#guest-form").hide();
	
	$("#guest-login").click('on',function(){
		$("#cts-form").hide();
		$("#guest-form").show();
	});
});