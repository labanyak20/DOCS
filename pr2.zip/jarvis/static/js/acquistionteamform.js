
$(document).ready(function(){
	
	$('#summary-div').hide();
	
	$.ajax({
		url: "static/csv/acquistionteamform.csv",
		async: false,
		success: function (csvd) {
			associatesNameData = data = csvd.split('\n');
		},
		dataType: "text",
		complete: function () {
			var list = associatesNameData;
			var sel = document.getElementById('developmentteamPOC');
			var opt = document.createElement('option');
			
			opt.innerHTML = "-- Select --";
			sel.appendChild(opt);
			for(var i = 0; i < list.length; i++) {
				opt = document.createElement('option');
				opt.innerHTML = list[i];
				sel.appendChild(opt);
			}
		}
	});
 
 
 	var searchBrand = document.getElementById("modifyBrandId");
	searchBrand.addEventListener("keyup", function(event) {
  		if (event.keyCode === 13) {
   			event.preventDefault();
   			document.getElementById("modifyAcquistionTeamData").click();
  		}
	});
 
 //unable to understand this function
 	$(function(){
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		if(month < 10)
			month = '0' + month.toString();
		if(day < 10)
			day = '0' + day.toString();
		minDate = year + '-' + month + '-' + day;		
		//$('#appointmentcalldate').attr('min', maxDate);
		//$('#pitchingdate').attr('min', maxDate);
		//$('#paymentdate').attr('min', maxDate);
		
	});
	
	$.ajax({
		url: "static/csv/brands.csv",
		async: false,
		success: function (csvd) {
			csvd = csvd.replace(/\n|\r/g, ",");
			csvd = csvd.replace(/,,/g, ",");
			data = csvd.split(',');
		},
		dataType: "text",
		complete: function () {
			
		}
	});

	var brands = [];	
	for (var i = 0; i < data.length; i += 2) {
	  var val = {};
	  val[data[i]] = data[i + 1];
	  brands.push(val);
	}
	
	$("#brandid").on("change input",function (event) {		
		
		var key = $('#brandid').val();
		var value;
		if(typeof brands.find(b => key.indexOf(Object.keys(b)) > -1) !== 'undefined'){
			value = brands.find(b => key.indexOf(Object.keys(b)) > -1)[key];
			$("#brandname:text").val(value);
		}else{
			$("#brandname:text").val('');
		}
   
     var brandId = {"brandid":$('#brandid').val()}
	 console.log(brandId);
      $.ajax({
				url: "https://amsjarvis.cognizant.com/check_acquistion_team_form_for_duplicate",
				type: "POST",
				data: JSON.stringify(brandId),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
             if(data !== ""){
                  alert(data);
                  location.reload();
             }   
				},
				error: function (error) {
				location.reload();
				}
		  }); 
	  });

	  	
   
	$("#submitacquistionteamformdata").click(function(){
		
		event.preventDefault();
    var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
		currentDateTime = new Date(currentDateTime);
		
		var siteurl = "https://amsjarvis.cognizant.com/insertinto_acquistion_team_form_data"
		
		
		if($('#amazonPOC').val() === ""){
			alert("Amazon POC must be filled out");
			return false;
		}
		if($('#brandid').val() === ""){
			alert("Brand ID must be filled out");
			return false;
		}
		else if($('#brandname').val() === ""){
			alert("Brand Name must be filled out");
			return false;
		}
		else if($('#brandname').val() === ""){
			alert("Brand Name must be filled out");
			return false;
		}
	    else if($('#category').val() === ""){
				alert("Category must be filled out");
				return false;
		}
	    else if($('#contactpointname1').val() === ""){
				alert("Contact Point Name 1 must be filled out");
				return false;
		}
	    else if($('#contact1').val() === ""){
				alert("Contact1 must be filled out");
				return false;
		}
	    else if($('#contactemailid1').val() === ""){
				alert("Contact Email Address1 must be filled out");
				return false;
		}
		else if($('#appointmentcalldate').val() === ""){
				alert("Appointment Call Date must be filled out");
				return false;
		}
		else if($('#appointmentcallstatus').val() === ""){
				alert("Appointment Call Status must be filled out");
				return false;
		}
		else if($('#pitchingdate').val() === ""){
				alert("Pitching Date must be filled out");
				return false;
		}
		else if($('#pitchingstatus').val() === ""){
				alert("Pitching Status must be filled out");
				return false;
		}
		else if($('#registrationdate').val() === ""){
				alert("Registration Date must be filled out");
				return false;
		}
		else if($('#registrationstatus').val() === ""){
				alert("Registration Status must be filled out");
				return false;
		}
		else if($('#followupfor').val() === ""){
				alert("Follow up for must be filled out");
				return false;
		}
		else if($('#followupdate').val() === ""){
				alert("Follow up date must be filled out");
				return false;
		}
		else if($('#followuptime').val() === ""){
				alert("Follow up Time must be filled out");
				return false;
		}
		else if($('#casenotes').val() === ""){
				alert("Case notes must be filled out");
				return false;
		}
		else { 
			var acquistionteamformdata = {
				"amazonPOC":$('#amazonPOC').val(), 
				"brandid":$('#brandid').val(),
				"brandname":$('#brandname').val(),
				"category":$('#category').val(),
				"contactpointname1":$('#contactpointname1').val(),
				"contactpointname2":$('#contactpointname2').val(),
				"contactpointname3":$('#contactpointname3').val(),
				"contact1":$('#contact1').val(),
				"contact2":$('#contact2').val(),
				"contact3":$('#contact3').val(),
				"contactemailid1":$('#contactemailid1').val(),
				"contactemailid2":$('#contactemailid2').val(),
				"contactemailid3":$('#contactemailid3').val(),
				"appointmentcalldate":$('#appointmentcalldate').val().toString(),
				"appointmentcallstatus":$('#appointmentcallstatus').val(),
				"pitchingdate":$('#pitchingdate').val().toString(),
				"pitchingstatus":$('#pitchingstatus').val(),
				"registrationdate":$('#registrationdate').val().toString(),
				"registrationstatus":$('#registrationstatus').val(),
				"paymentdate":$('#paymentdate').val().toString(),
				"paymentstatus":$('#paymentstatus').val(),
				"launchdate":$('#launchdate').val().toString(),	
				"launchstatus":$('#launchstatus').val(),	
				"rechargeamount":$('#rechargeamount').val(),	
				"followupfor":$('#followupfor').val(),	
				"followupdate":$('#followupdate').val().toString(),	
				"followuptime":$('#followuptime').val().toString(),	
				"developmentteamPOC":$('#developmentteamPOC').val(),	
				"handoverdate":$('#handoverdate').val().toString(),	
				"casenotes":$('#casenotes').val(),	
				"date": currentDateTime.toString("yyyy-MM-dd")
			}
      
      console.log(acquistionteamformdata);
			
			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(acquistionteamformdata),
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {
					alert("Data uploaded successfully"); 					
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
			});
		}
 	});
	
	$("#modifyAcquistionTeamData").click(function(){
		if($('#modifyBrandId').val() === ""){
			$('#form-container').hide();
			alert("Please enter Brand ID!!");
			return false;
        }else{
			var siteurl = "https://amsjarvis.cognizant.com/retrieve_acquistion_team_data"
			var brandData = {"brandid":$('#modifyBrandId').val()}

			$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(brandData),
				dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
					},
					success: function (data) {       
						displayJsonData(data);
					},
					error: function (error) {
						alert(JSON.stringify(error));
					}
			});
		}
    	});
	
	
	$("#exportData").click(function(){

		var siteurl = "https://amsjarvis.cognizant.com/retrieve_acquistion_team_report"
		var filterData = {};
		
		var filterFromDateStr = $("#filterFromDate").val();
		var filterFromDate = new Date(filterFromDateStr);
		filterFromDate = filterFromDate.toString('yyyy-MM-dd');
		
		var  filterToDateStr = $("#filterToDate").val();
		var filterToDate = new Date(filterToDateStr);
		filterToDate = filterToDate.toString('yyyy-MM-dd');
		
		if($('#retrieveCategory').val() === "pitch_date"){
			filterData = {
				"filterCategory": $('#retrieveCategory').val(),
				"filterFromDate": filterFromDate,
				"filterToDate": filterToDate
			}
		}else if($('#retrieveCategory').val() === "agent_name"){
			filterData = {
				"filterCategory": $('#retrieveCategory').val(),
				"filterValue": $("#filterAgentName").val()
			}
		}else if($('#retrieveCategory').val() === ""){
			filterData = {
				"filterCategory": "",
				"filterValue": ""
			}
		}
		
			
		$.ajax({
				url: siteurl,
				type: "POST",
				data: JSON.stringify(filterData),
				dataType: 'json',
				headers: {
					"Accept": "application/json",
					"Content-Type": "application/json"
				},
				success: function (data) {	
					JSONToCSVConvertor(data);
					console.log(data);
				},
				error: function (error) {
					alert(JSON.stringify(error));
				}
		});
    });
	
});


function displayJsonData(data){
	
  console.log(JSON.stringify(data));
	var jsonacquistionteamData = JSON.stringify(data);
	var acquistionteamObj = JSON.parse(jsonacquistionteamData); 
	
	if(acquistionteamObj.amazonPOC != ""){ 
		$('#amazonPOC').val(acquistionteamObj.amazonPOC);
		$("#amazonPOC").prop("disabled", true);
	}
	if(acquistionteamObj.brandid != ""){ 
		$('#brandid').val(acquistionteamObj.brandid);
		$("#brandid").prop("disabled", true);
	}
	if(acquistionteamObj.brandname != ""){  
		$('#brandname').val(acquistionteamObj.brandname);
		$("#brandname").prop("disabled", true);
	}
	if(acquistionteamObj.category != ""){ 
		$('#category').val(acquistionteamObj.category);
		$("#category").prop("disabled", true);
	}
	
	if(acquistionteamObj.contactpointname1 != ""){ 
		$('#contactpointname1').val(acquistionteamObj.contactpointname1);
		$("#contactpointname1").prop("disabled", true);
	}
	if(acquistionteamObj.contactpointname2 != ""){ 
		$('#contactpointname2').val(acquistionteamObj.contactpointname2);
		$("#contactpointname2").prop("disabled", true);
	}
	if(acquistionteamObj.contactpointname3 != ""){ 
		$('#contactpointname3').val(acquistionteamObj.contactpointname3);
		$("#contactpointname3").prop("disabled", true);
	}
	if(acquistionteamObj.contact1 != ""){ 
		$('#contact1').val(acquistionteamObj.contact1);
		$("#contact1").prop("disabled", true);
	}
	if(acquistionteamObj.contact2 != ""){ 
		$('#contact2').val(acquistionteamObj.contact2);
		$("#contact2").prop("disabled", true);
	}
	if(acquistionteamObj.contact3 != ""){ 
		$('#contact3').val(acquistionteamObj.contact3);
		$("#contact3").prop("disabled", true);
	}
	if(acquistionteamObj.contactemailid1 != ""){ 
		$('#contactemailid1').val(acquistionteamObj.contactemailid1);
		$("#contactemailid1").prop("disabled", true);
	}
	if(acquistionteamObj.contactemailid2 != ""){ 
		$('#contactemailid2').val(acquistionteamObj.contactemailid2);
		$("#contactemailid2").prop("disabled", true);
	}
	if(acquistionteamObj.contactemailid3 != ""){ 
		$('#contactemailid3').val(acquistionteamObj.contactemailid3);
		$("#contactemailid3").prop("disabled", true);
	}
	if(acquistionteamObj.appointmentcalldate != ""){ 
		$('#appointmentcalldate').val(acquistionteamObj.appointmentcalldate);
		$("#appointmentcalldate").prop("disabled", true);
	}
	if(acquistionteamObj.appointmentcallstatus != ""){ 
		$('#appointmentcallstatus').val(acquistionteamObj.appointmentcallstatus);
		$("#appointmentcallstatus").prop("disabled", true);
	}
	if(acquistionteamObj.pitchingdate != ""){ 
		$('#pitchingdate').val(acquistionteamObj.pitchingdate);
		$("#pitchingdate").prop("disabled", true);
	}
	if(acquistionteamObj.pitchingstatus != ""){ 
		$('#pitchingstatus').val(acquistionteamObj.pitchingstatus);
		$("#pitchingstatus").prop("disabled", true);
	}
	if(acquistionteamObj.registrationdate != ""){ 
		$('#registrationdate').val(acquistionteamObj.registrationdate);
		$("#registrationdate").prop("disabled", true);
	}
	if(acquistionteamObj.registrationstatus != ""){ 
		$('#registrationstatus').val(acquistionteamObj.registrationstatus);
		$("#registrationstatus").prop("disabled", true);
	}
	if(acquistionteamObj.paymentdate != ""){ 
		$('#paymentdate').val(acquistionteamObj.paymentdate);
		$("#paymentdate").prop("disabled", true);
	}
	if(acquistionteamObj.pitch_date2_actual_date != ""){ 
		$('#pitchdate2actualdate').val(acquistionteamObj.pitch_date2_actual_date);
		$("#pitchdate2actualdate").prop("disabled", true);
	}
	if(acquistionteamObj.paymentstatus != ""){ 
		$('#paymentstatus').val(acquistionteamObj.paymentstatus);
		$("#paymentstatus").prop("disabled", true);
	}
	if(acquistionteamObj.launchdate != ""){ 
		$('#launchdate').val(acquistionteamObj.launchdate);
		$("#launchdate").prop("disabled", true);
	}	
	if(acquistionteamObj.launchstatus != ""){ 
		$('#launchstatus').val(acquistionteamObj.launchstatus);
		$("#launchstatus").prop("disabled", true);
	}	
	if(acquistionteamObj.rechargeamount != ""){ 
		$('#rechargeamount').val(acquistionteamObj.rechargeamount);
		$("#rechargeamount").prop("disabled", true);
	}	
	if(acquistionteamObj.followupfor != ""){ 
		$('#followupfor').val(acquistionteamObj.followupfor);
		$("#followupfor").prop("disabled", true);
	}	
	if(acquistionteamObj.followupdate != ""){ 
		$('#followupdate').val(acquistionteamObj.followupdate);
		$("#followupdate").prop("disabled", true);
	}	
	if(acquistionteamObj.followuptime != ""){ 
		$('#followuptime').val(acquistionteamObj.followuptime);
		$("#followuptime").prop("disabled", true);
	}	
	if(acquistionteamObj.developmentteamPOC != ""){ 
		$('#developmentteamPOC').val(acquistionteamObj.developmentteamPOC);
		$("#developmentteamPOC").prop("disabled", true);
	}	
	if(acquistionteamObj.handoverdate != ""){ 
		$('#handoverdate').val(acquistionteamObj.handoverdate);
		$("#handoverdate").prop("disabled", true);
	}	
	if(acquistionteamObj.casenotes != ""){ 
		$('#casenotes').val(acquistionteamObj.casenotes);
		$("#casenotes").prop("disabled", true);
	}	
	}



$(function(){
    $('#retrieveCategory').on('change', function(){
        var val = $(this).val();
        
		if(val === ""){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$("#retrieveCategory").css({"width":"25%","margin-left":"30%"});
			$('#filterAgentName').hide();
			$('#emptySelect').show();
		}
		else if(val === "agent_name"){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$("#retrieveCategory").css({"width":"25%","margin-left":"30%"});
			$('#filterAgentName').show();
			$('#emptySelect').hide();
			
			$.ajax({
				url: "static/csv/acquistionteamform.csv",
				async: false,
				success: function (csvd) {
					associatesNameData = data = csvd.split('\n');
				},
				dataType: "text",
				complete: function () {
					var list = associatesNameData;
					var sel = document.getElementById('filterAgentName');
					var opt = document.createElement('option');
					opt.innerHTML = "-- Select --";
					sel.appendChild(opt);
					for(var i = 0; i < list.length; i++) {
						opt = document.createElement('option');
						opt.innerHTML = list[i];
						sel.appendChild(opt);
					}
				}
			});
		}
		else if(val === "pitch_date"){
			$('#filterFromDate').hide();
			$('#filterToDate').hide();
			$("#retrieveCategory").css({"width":"25%","margin-left":"5%"});
			$('#filterAgentName').hide();
			$('#emptySelect').hide();
			$('#filterFromDate').show();
			$('#filterToDate').show();
		}
    });
});


function JSONToCSVConvertor(data) {
	
	var jsonatfData = JSON.stringify(data);
	var jsonObj = JSON.parse(jsonatfData);
	var JSONData = JSON.stringify(jsonObj.atf);
	console.log(jsonObj.atf);
	var parseData = JSON.parse(JSONData);

	/* create workbook & set props*/
	const wb = { SheetNames: [], Sheets: {} };
	wb.Props = {
		  Title: "Acquisation Team Form Data",
		  Author: "Unknown"
	};

	/*create sheet data & add to workbook*/
	var ws = XLSX.utils.json_to_sheet(parseData);
	var ws_name = "Acquisation Team Form Data";
	XLSX.utils.book_append_sheet(wb, ws, ws_name);
	XLSX.writeFile(wb, "Acquisation_Team_Form.xlsx");
}
