
$(document).ready(function () {

    var sheet1;
    var sheet2;
    var sheet3;

    var sheet1_data = [];
    var sheet2_data = [];
    var sheet3_data = [];
    var wb = XLSX.utils.book_new();
	
    var total_files_count = 0;
    var files_processed_count = 0;

    var XLSX_WorkBook = [];
	
	  var oobTable;
    
    $('#loading_div').css('display','none');
    $('#warning-message').hide();
    
    $(function(){
		var dtToday = new Date();
		var month = dtToday.getMonth() + 1;
		var day = dtToday.getDate();
		var year = dtToday.getFullYear();
		if(month < 10)
			month = '0' + month.toString();
		if(day < 10)
			day = '0' + day.toString();
		maxDate = year + '-' + month + '-' + day;		
		$('#filter-date').attr('max', maxDate);
	  });

    $('#upload_files').change(function (event) {
		
        $("#oob-table").hide();
        $("#table-filter-export-data").hide();
        $('#loading_div').css('display','block');

        $('#status_warn_messages').html("");
        
        total_files_count = 0;
        files_processed_count = 0;

        event.preventDefault();
        var blob = "";
        var files = $('#upload_files').get(0).files;
        if (!files[0])
            return;

        total_files_count = files.length;
        $.each(files, function (file_index, file) {

            var reader = new FileReader();
            reader.onload = function () {
                var data = reader.result;
                if (file.name.includes(".xlsx")) {

                    Promise.resolve(XLSX_Read_Function(data, file_index))
                        .then(() => {
                            Decide_Action_Sequence();
                                                    
                        });
                }
            }
            reader.readAsBinaryString(file);
        });


       
    });

    function Decide_Action_Sequence() {
        files_processed_count++;
        if (files_processed_count == total_files_count)
            Action_Sequence(); 
    }

    function XLSX_Read_Function(data, file_index) {
        
        XLSX_WorkBook[file_index] = XLSX.read(data, {
            type: 'binary'
        });

    }

    function Action_Sequence() {
       
        for (let i = 0, len = XLSX_WorkBook.length; i < len; i++) {

            XLSX_WorkBook[i].SheetNames.indexOf("Balance") > -1 ?  sheet1 = XLSX_WorkBook[i].Sheets["Balance"] : null;
            XLSX_WorkBook[i].SheetNames.indexOf("Spoc") > -1 ? sheet3 = XLSX_WorkBook[i].Sheets["Spoc"] : null;
            XLSX_WorkBook[i].SheetNames.indexOf("Last 30 Days") > -1 ? sheet2 = XLSX_WorkBook[i].Sheets["Last 30 Days"] : null;
        }
        typeof (sheet1) == "undefined" ? Set_Warning_Status_Messages("Did not find sheet 'Balance' in uploaded file/files!!&emsp;"): Process_Sheet1();
		typeof (sheet2) == "undefined" ? Set_Warning_Status_Messages("Did not find sheet 'Last 30 Days' in uploaded file/files!!&emsp;"): Process_Sheet2();
        typeof (sheet3) == "undefined" ? Set_Warning_Status_Messages("Did not find sheet 'Spoc' in uploaded file/files!!&emsp;"): Process_Sheet3();
		
		if (typeof (sheet1) != "undefined" && typeof (sheet2) != "undefined" && typeof (sheet3) != "undefined") {

            //AMS_POC(sheet1_data, sheet3_data);
            Fourteen_Days_Spend_And_Count_Of_Unique_Days_Brand_Perform(sheet2_data, sheet1_data);
            Daily_Spend_7_and_14_Days_Expenses_From_History(sheet1_data);
            Current_OOB(sheet1_data);
            OOB_in_7_days(sheet1_data);
            OOB_in_14_days(sheet1_data);
            //Agent_Table(sheet1_data);
            //AMS_Poc_Table(sheet1_data);
      
			//console.log("Sheet 1 Data : " + JSON.stringify(sheet1_data));
      
			var oobArr = [];
			var currentDateTime = new Date().toLocaleString("en-US", {timeZone: "Asia/Kolkata"});
			currentDateTime = new Date(currentDateTime); 
			var currentDate = currentDateTime.toString('yyyy-MM-dd');
			
			for(var i = 1; i < sheet1_data.length; i++){
				var oobData = {};
				oobData["date"] = currentDate
				oobData["brand_id"] = sheet1_data[i][0];
				oobData["brand_name"] = sheet1_data[i][1];
				oobData["account_manager_cts"] = sheet1_data[i][2];
				oobData["balance"] = sheet1_data[i][3];
				oobData["fourteen_days_spend"] = sheet1_data[i][5];
				oobData["unique_days_perform"] = sheet1_data[i][6];
				oobData["daily_spend_history"] = sheet1_data[i][7];
				oobData["seven_days_exp_from_history"] = sheet1_data[i][8];
				oobData["fourteen_days_exp_from_history"] = sheet1_data[i][9];
				oobData["curent_oob_status"] = sheet1_data[i][10];
				oobData["oob_in_seven_days"] = sheet1_data[i][11];
				oobData["oob_in_fourteen_days"] = sheet1_data[i][12];
				oobArr.push(oobData);
			}
       
			$.ajax({
			    url: "https://amsjarvis.cognizant.com/insert_into_oobtracker",
                type: "POST",
			         data: JSON.stringify(oobArr),
			         headers: {
			         	"Accept": "application/json",
				        "Content-Type": "application/json"
			          },
			          success: function (data) {
                         alert("Data uplaoded successfully");								
                },
			          error: function (error) {
				               alert(error);
                }
			});
			
			$('#loading_div').css('display','none');
		
			$.ajax({
                url: "https://amsjarvis.cognizant.com/retrieve_from_oobtracker",
			          type: "POST",
                data: {},
		            headers: {
			          	"Accept": "application/json",
			           	"Content-Type": "application/json"
						
		            },
			          success: function (data) {
				                 CreateTable(data);								
                },
			          error: function (error) {
				               alert(error);
                }
			});
			
        } else {
            Set_Warning_Status_Messages("Not able to process further. Please check the file uploaded !!&emsp;");
        }
        $('#loading_div').css('display',"none");
	}
	
    function Set_Warning_Status_Messages(message) {
		$('#warning-message').show();
		$('#status_warn_messages').css('display','-webkit-box');
        $('#status_warn_messages').append(message + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>');
		$('#sheet_names_p').css("display", "none");
		$('#loading_div').css('display','none');
    }

   

    function Process_Sheet1() {

        var sheet_data = [];
        var needed_cols = ["Entity ID", "Account Name", "Account Manager - CTS", "Balance", "AMS_POC"];
        sheet1_data = Process_Sheet(sheet1, needed_cols)
    }
	
	
	function Process_Sheet2() {
        var needed_cols = ["calendar_day", "entity_id", "name", "type", "ad_revenue", "total_click", "total_imp", "click_units", "click_gms"];
        sheet2_data = Process_Sheet(sheet2, needed_cols)
        //         var worksheet = XLSX.utils.aoa_to_sheet(sheet_data);
        //         document.getElementById("table_print").innerHTML = XLSX.utils.sheet_to_html(worksheet);

    }

    function Process_Sheet3() {
        var needed_cols = ["Entity ID", "Account Name", "Account Manager - CTS", "AMS_POC"]
        sheet3_data = Process_Sheet(sheet3, needed_cols)
        //         var worksheet = XLSX.utils.aoa_to_sheet(sheet_data);
        //         document.getElementById("table_print").innerHTML = XLSX.utils.sheet_to_html(worksheet);

    }
	
    function Process_Sheet(sheet, needed_cols) {
        var range = XLSX.utils.decode_range(sheet["!ref"]);
        var heading_row = Get_Headings(range, sheet);
        var needed_cols_indexes = [];
        var sheet_data = [];

        for (i of needed_cols) {
            var k = heading_row.indexOf(i);
            needed_cols_indexes.push(k);
        }
        for (var i = range.s.r; i <= range.e.r; i++) {
            var a = [];
            for (j of needed_cols_indexes) {

                var x = sheet[XLSX.utils.encode_cell({
                    r: i,
                    c: j
                })];

                if (typeof (x) != "undefined")
                    a.push(x.w || x.v);
            }
            if (a.length == needed_cols.length)
                sheet_data.push(a);
			    
        }
		//console.log(sheet_data);
        return sheet_data;

    }
	
	function AMS_Poc_Table(a) {
        var AMS_Poc_Table = [];

        AMS_Poc_Table[0] = ["AMS POC", "Total brands", "Current OOB", "% of current OOB", "OOB in 7 Days", "% OOB in 7 Days", "OOB in 14 Days", "% OOB in 14 Days"];

        var x = {};
        for (i = 1, len1 = a.length; i < len1; i++) {
            y = a[i];
            var z = x[y[5]] || {};
            z = {
                "total_brands": ((z["total_brands"] || 0) + 1),
                "ams_poc": z["ams_poc"] || y[4],
                "current_OOB": (Number(z["current_OOB"]) || 0) + (y[10] == "Yes" ? 1 : 0),
                "OOB_in_7_days": (Number(z["OOB_in_7_days"]) || 0) + (y[11] == "Yes" ? 1 : 0),
                "OOB_in_14_days": (Number(z["OOB_in_14_days"]) || 0) + (y[12] == "Yes" ? 1 : 0)
            };

            x[y[5]] = z;

        }

        for (i of Object.keys(x)) {
            var k = 0;
            var temp = [];
            temp[k++] = x[i]["ams_poc"];
            temp[k++] = x[i]["total_brands"];
            temp[k++] = x[i]["current_OOB"];
            temp[k++] = (x[i]["current_OOB"] / x[i]["total_brands"] || 0) * 100 + "%";
            temp[k++] = x[i]["OOB_in_7_days"];
            temp[k++] = (x[i]["OOB_in_7_days"] / x[i]["total_brands"] || 0) * 100 + "%";
            temp[k++] = x[i]["OOB_in_14_days"];
            temp[k++] = (x[i]["OOB_in_14_days"] / x[i]["total_brands"] || 0) * 100 + "%";
            AMS_Poc_Table.push(temp);
        }
    }


    function Agent_Table(a) {
        var agent_table = [];

        agent_table[0] = ["Agent name", "AMS POC", "Total brands", "Current OOB", "% of current OOB", "OOB in 7 Days", "% OOB in 7 Days", "OOB in 14 Days", "% OOB in 14 Days"];

        agent_name = new Set();
        var x = {};
        for (i = 1, len1 = a.length; i < len1; i++) {
            y = a[i];
            var z = x[y[2]] || {};
            z = {
                "total_brands": ((z["total_brands"] || 0) + 1),
                "agent_name": z["agent_name"] || y[2],
                "ams_poc": z["ams_poc"] || y[4],
                "current_OOB": (Number(z["current_OOB"]) || 0) + (y[10] == "Yes" ? 1 : 0),
                "OOB_in_7_days": (Number(z["OOB_in_7_days"]) || 0) + (y[11] == "Yes" ? 1 : 0),
                "OOB_in_14_days": (Number(z["OOB_in_14_days"]) || 0) + (y[12] == "Yes" ? 1 : 0)
            };

            x[y[2]] = z;

        }

        for (i of Object.keys(x)) {
            var k = 0;
            var temp = [];
            temp[k++] = x[i]["agent_name"];
            temp[k++] = x[i]["ams_poc"];
            temp[k++] = x[i]["total_brands"];
            temp[k++] = x[i]["current_OOB"];
            temp[k++] = (x[i]["current_OOB"] / x[i]["total_brands"] || 0) * 100 + "%";
            temp[k++] = x[i]["OOB_in_7_days"];
            temp[k++] = (x[i]["OOB_in_7_days"] / x[i]["total_brands"] || 0) * 100 + "%";
            temp[k++] = x[i]["OOB_in_14_days"];
            temp[k++] = (x[i]["OOB_in_14_days"] / x[i]["total_brands"] || 0) * 100 + "%";
            agent_table.push(temp);
        }
    }

    function OOB_in_14_days(a) {
        a[0].push("OOB_in_14_days");
        for (i = 1, len1 = a.length; i < len1; i++) {
            y = a[i];
            y.push(y[10] == "Yes" ? "Na" : y[11] == "Yes" ? "Na" : y[9] >= y[3] ? "Yes" : "No");
        }
    }

    function OOB_in_7_days(a) {
        a[0].push("OOB_in_7_days");
        for (i = 1, len1 = a.length; i < len1; i++) {
            y = a[i];
            y.push(y[10] == "Yes" ? "Na" : y[8] >= y[3] ? "Yes" : "No");
        }
    }

    function Current_OOB(a) {
        var balance_index = a[0].indexOf("Balance");
        a[0].push("Curent_OOB_Status");
        for (i = 1, len1 = a.length; i < len1; i++) {
            y = a[i];
            y.push(Number(y[balance_index]) < 1500 ? "Yes" : "No");
        }
    }

    function Daily_Spend_7_and_14_Days_Expenses_From_History(a) {
        a[0].push("daily_spend_History", "7_days_Exp_from_History", "14_days_Exp_from_History");
		
        for (i = 1, len1 = a.length; i < len1; i++) {
            y = a[i];
            var z = (y[5] / y[6]) || 0;
			//console.log("Z .. " + z + ".." + z*7 + ".." + z*14);
            a[i].push(z, z * 7, z * 14);
        }
    }

    function Fourteen_Days_Spend_And_Count_Of_Unique_Days_Brand_Perform(a, b) {
        var x = {};

        for (i = 1, len1 = a.length; i < len1; i++) {
            y = a[i];

            var z = x[y[1]] || {};

            z = {
                "14_days_spend": ((z["14_days_spend"] || 0) + Number(y[4])),
                "unique_days": ((z["unique_days"] || new Set()).add(y[0]))
            };

            x[y[1]] = z;

        }
        b[0].push("14_days_spend");
        b[0].push("unique_days_perform");
        for (i = 1, len1 = b.length; i < len1; i++) {
            y = b[i];
            var entity_id = y[0];
            z = x[entity_id] || {};
            y.push(z["14_days_spend"] || 0);
            y.push(typeof (z["unique_days"]) == "undefined" ? 0 : z["unique_days"].size);
        }

    }


    function AMS_POC(a, b) {
        // console.log(sheet1_data);
        for (i = 0, len1 = a.length; i < len1; i++) {
            var x = a[i].slice(0, 3).join().toLowerCase();
            for (j = 0, len2 = b.length; j < len2; j++) {
                var y = b[j].slice(0, 3).join().toLowerCase();
                if (x == y) {
                    a[i].push(b[j][3]);

                }

            }

        }
        //return a;
    }

    function Get_Headings(range, sheet) {
        var heading_row = [];
        for (var i = range.s.c; i <= range.e.c; i++) {
            heading_row.push(sheet[XLSX.utils.encode_cell({
                r: 0,
                c: i
            })].v)
        }
        return heading_row;
    }
      
	$.ajax({
		url: "https://amsjarvis.cognizant.com/retrieve_from_oobtracker",
		type: "POST",
		data: {},
		headers: {
		    "Accept": "application/json",
			"Content-Type": "application/json"
		},
		success: function (data) {
		    CreateTable(data);								
		},
		error: function (error) {
			alert(error);
		}
	});
	
	function CreateTable(data){
		
		$("#table-filter-export-data").show();
		$("#oob-table").show();
		var oobData = JSON.parse(data);
		
		//Create Date Editor
		var dateEditor = function(cell, onRendered, success, cancel){
			//cell - the cell component for the editable cell
			//onRendered - function to call when the editor has been rendered
			//success - function to call to pass the successfuly updated value to Tabulator
			//cancel - function to call to abort the edit and return to a normal cell

			//create and style input
			var cellValue = moment(cell.getValue(), "DD/MM/YYYY").format("YYYY-MM-DD"),
			input = document.createElement("input");

			input.setAttribute("type", "date");

			input.style.padding = "4px";
			input.style.width = "100%";
			input.style.boxSizing = "border-box";

			input.value = cellValue;

			onRendered(function(){
				input.focus();
				input.style.height = "100%";
			});

			function onChange(){
				if(input.value != cellValue){
					success(moment(input.value, "YYYY-MM-DD").format("DD/MM/YYYY"));
				}else{
					cancel();
				}
			}

			//submit new value on blur or change
			input.addEventListener("blur", onChange);

			//submit new value on enter
			input.addEventListener("keydown", function(e){
				if(e.keyCode == 13){
					onChange();
				}

				if(e.keyCode == 27){
					cancel();
				}
			});

			return input;
		};
		
		
		var fouteenDaysOobCheck = function(cell){
			var data = cell.getRow().getData();
			return (data.oob_in_fourteen_days == "Yes")
		}
		var sevenDaysOobCheck = function(cell){
			var data = cell.getRow().getData();
			return (data.oob_in_seven_days == "Yes")
		}
		var currentOobCheck = function(cell){
			var data = cell.getRow().getData();
			return (data.curent_oob_status == "Yes")
		}
		var oobPlusOneWeekCheck = function(cell){
			var data = cell.getRow().getData();
			const date1 = new Date(data.first_time_current_oob_date);
			const date2 = new Date();
			const diffTime = Math.abs(date2.getTime() - date1.getTime());
			const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));	
			return (diffDays >= 7 && diffDays <= 13)
		}
		var oobPlusTwoWeekCheck = function(cell){
			var data = cell.getRow().getData();
			const date1 = new Date(data.first_time_current_oob_date);
			const date2 = new Date();
			const diffTime = Math.abs(date2.getTime() - date1.getTime());
			const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));	
			return (diffDays >= 14 && diffDays <= 27)
		}
		var oobPlusFourWeekCheck = function(cell){
			var data = cell.getRow().getData();
			const date1 = new Date(data.first_time_current_oob_date);
			const date2 = new Date();
			const diffTime = Math.abs(date2.getTime() - date1.getTime());
			const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));	
			return (diffDays >= 28 && diffDays <= 48)
		}
		var oobPlusSevenWeekCheck = function(cell){
			var data = cell.getRow().getData();
			const date1 = new Date(data.first_time_current_oob_date);
			const date2 = new Date();
			const diffTime = Math.abs(date2.getTime() - date1.getTime());
			const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));	
			return (diffDays >= 49 )
		}
		
		var colorOobField = function (cell, formatterParams) {
            var data = cell.getData();
            var field = formatterParams.param;
            var value = data[field];
			if (value == "Yes"){
				cell.getElement().style.border = "1px solid red";
            }
			return cell.getValue();
        };
		
		var colorPlusOneWeekField = function (cell, formatterParams) {
            var data = cell.getData();
            var field = formatterParams.param;
            const date1 = new Date(data[field]);
			const date2 = new Date();
			const diffTime = Math.abs(date2.getTime() - date1.getTime());
			const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
			if (diffDays >= 7 && diffDays <= 13){
				cell.getElement().style.border = "1px solid red";
            }
			return cell.getValue();
        };
		var colorPlusTwoWeekField = function (cell, formatterParams) {
            var data = cell.getData();
            var field = formatterParams.param;
            const date1 = new Date(data[field]);
			const date2 = new Date();
			const diffTime = Math.abs(date2.getTime() - date1.getTime());
			const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
			if (diffDays >= 14 && diffDays <= 27){
				cell.getElement().style.border = "1px solid red";
            }
			return cell.getValue();
        };
		var colorPlusFourWeekField = function (cell, formatterParams) {
            var data = cell.getData();
            var field = formatterParams.param;
            const date1 = new Date(data[field]);
			const date2 = new Date();
			const diffTime = Math.abs(date2.getTime() - date1.getTime());
			const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
			if (diffDays >= 28 && diffDays <= 48){
				cell.getElement().style.border = "1px solid red";
            }
			return cell.getValue();
        };
		var colorPlusSevenWeekField = function (cell, formatterParams) {
            var data = cell.getData();
            var field = formatterParams.param;
            const date1 = new Date(data[field]);
			      const date2 = new Date();
			      const diffTime = Math.abs(date2.getTime() - date1.getTime());
			      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
			      if (diffDays >= 49){
				       cell.getElement().style.border = "1px solid red";
            }
			      return cell.getValue();
        };
        
     var reasonMutator = function(value, data, type, params, column){
         
         if (data.curent_oob_status == "Yes"){
            value = "Currently OOB";
         }
         if (data.oob_in_seven_days == "Yes"){
            value = "Seven days notice of OOB";
         }
         if (data.oob_in_fourteen_days == "Yes"){
            value = "Fourteen day notice of OOB";
         }
         const date1 = new Date(data.first_time_current_oob_date);
         const date2 = new Date();
         const diffTime = Math.abs(date2.getTime() - date1.getTime());
			   const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
         if (diffDays >= 7 && diffDays <= 13){
				      value = "7 days of being inactive";
         }
         else if(diffDays >= 14 && diffDays <= 29){
              value = "14 days of being inactive";
         }
         else if(diffDays >= 30 && diffDays <= 48){
              value = "30 days of inactivity";
         }
         else if(diffDays >= 49){
              value = "No response from Brand POC after 49 days of inactivity";
         }
         return value
     }   
		
		oobTable = new Tabulator("#oob-table", {
			pagination:"local",
			paginationSize:20,
			layout:"fitData",	
			data:oobData,
			columns:[
				{title:"Date", field:"date", headerSort:false, frozen:true},
				{title:"Entity Id", field:"brand_id", headerSort:false, headerFilter: "input", headerFilterPlaceholder: 'Enter Entity ID', frozen:true},
				{title:"Brand Name", field:"brand_name", headerSort:false, frozen:true},
				{title:"Account Manager", field:"account_manager_cts", headerSort:false, headerFilter: "input", headerFilterPlaceholder: 'Enter Name'},
				{title:"Balance", field:"balance", headerSort:false},
				{title:"OOB Cycle Start Date", field:"oob_cycle_start_date", headerSort:false},
				{title:"Reason for Phone Call/E-mail", field:"reason", mutator:reasonMutator, headerSort:false},
				
				{title:"Automated nudges for 14 day notice of OOB", field:"automated_nudges_for_14_day_notice_of_oob", headerSort:false, editor:"select", editorParams:{values:["",  "Yes", "No"]}, editable:fouteenDaysOobCheck, formatter: colorOobField, formatterParams:{param: 'oob_in_fourteen_days'}, validator:["maxLength:3", "string"]},
				
				{title:"Phone calling for 7 day notice of OOB brands", field:"phone_calling_for_7_day_notice_of_oob_brands", headerSort:false, editor:"select", editorParams:{values:["", "Yes", "No"]}, editable:sevenDaysOobCheck, formatter: colorOobField, formatterParams:{param: 'oob_in_seven_days'}, validator:["maxLength:3", "string"]},
				
				{title:"Phone calling for 3 day notice of OOB brands", field:"phone_calling_for_3_day_notice_of_oob_brands", headerSort:false, editor:"select", editorParams:{values:["", "Yes", "No"]}, editable:sevenDaysOobCheck, formatter: colorOobField, formatterParams:{param: 'oob_in_seven_days'}, validator:["maxLength:3", "string"]},
				
				{title:"Phone calling for currently OOB", field:"phone_calling_for_currently_oob", headerSort:false, editor:"select", editorParams:{values:["", "Yes", "No"]}, editable:currentOobCheck, formatter: colorOobField, formatterParams:{param: 'curent_oob_status'}, validator:["maxLength:3", "string"]},
				
				{title:"Follow up call with brand after 7 days of being inactive", field:"follow_up_call_with_brand_after_7_days_of_inactive", headerSort:false, editor:"select", editorParams:{values:["", "Yes", "No"]}, editable:oobPlusOneWeekCheck, formatter: colorPlusOneWeekField, formatterParams:{param: 'first_time_current_oob_date'}, validator:["maxLength:3", "string"]},
				
				{title:"Follow up call with brand after being 14 days of being inactive", field:"follow_up_call_with_brand_after_14_days_of_inactive", headerSort:false, editor:"select", editorParams:{values:["", "Yes", "No"]}, editable:oobPlusTwoWeekCheck, formatter: colorPlusTwoWeekField, formatterParams:{param: 'first_time_current_oob_date'}, validator:["maxLength:3", "string"]},
				
				{title:"Send the inactive blurb + call after one day to the advertiser post 30 days of inactivity", field:"send_the_inactive_blurb_call_post_30_days_inactivity", headerSort:false, editor:"select", editorParams:{values:["", "Yes", "No"]}, editable:oobPlusFourWeekCheck, formatter: colorPlusFourWeekField, formatterParams:{param: 'first_time_current_oob_date'}, validator:["maxLength:3", "string"]},
				
				{title:"Add brand to the removal list if there has been no response", field:"add_brand_to_removal_list_if_no_response", headerSort:false, editor:"select", editorParams:{values:["", "Yes", "No"]}, editable:oobPlusSevenWeekCheck, formatter: colorPlusSevenWeekField, formatterParams:{param: 'first_time_current_oob_date'}, validator:["maxLength:3", "string"]},
				
				{title:"Issue Category", field:"issue_category", headerSort:false, editor:"select", editorParams:{values:["","Cloudtail/Appario Issues", "Managed by AMS POC", "Merged with Parent account", "No Response", "Not Inclined to AMS", "Payment & Invoices", "Product Unavailability", "Seller Central", "Performance Issue", "Promised Recharge", "Recharged", "Recharging Today", "Brands to be removed"]}, validator:"string"},
				
				{title:"Comments", field:"comments", width:500, formatter:"textarea", editor:true, headerSort:false, validator:"string"},
				{title:"Followup date", field:"follow_up_date", headerSort:false, editor:dateEditor, validator:"maxLength:10"},
			],
		});
	}
	var count = 0;
	
	$("#submit-table-data").on("click",function () {	

	
       setTimeout(function(){
             var oobEditedData  = oobTable.getData("json", "data.json");        
			 
             $.ajax({
             url: "https://amsjarvis.cognizant.com/update_oobtracker",
			       type: "POST",
			       data: JSON.stringify(oobEditedData),
			       headers: {
                      "Accept": "application/json",
                      "Content-Type": "application/json"
			       },
					success: function (data) {
				        alert("Table data uploaded successfully!!");								
			       },
			       error: function (error) {
				         alert(error);
			       }
	          });
        },0);                                       
	});
	
	$("#submit-date").on("click",function (event) {

    event.preventDefault();                          
		var filterDate  = $('#filter-date').val();
		filterDate = filterDate.toString('yyyy-MM-dd');
		var filterDateJson = {"filterDate" : filterDate}
      
		$.ajax({
				url: "https://amsjarvis.cognizant.com/retrieve_oobtracker_history",
				type: "POST",
				data: JSON.stringify(filterDateJson),
				headers: {
				  "Accept": "application/json",
				  "Content-Type": "application/json"
				  
				},
				success: function (data) {
					CreateTable(data);								
			   },
			   error: function (error) {
					alert(error);
			   }
		  });                                      
	});
	
	$("#export-table-data").click(function(){
		oobTable.download("xlsx", "oob tracker.xlsx", {sheetName:"OOB Data"});
	});	
		
});
