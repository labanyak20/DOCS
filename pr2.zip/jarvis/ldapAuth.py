import ldap

def check_credentials(username, password):
   """Verifies credentials for username and password.
   Returns None on success or a string describing the error on failure
   # Adapt to your needs
   """
   LDAP_SERVER = 'ldap://10.237.5.79:389'
   # fully qualified AD user name
   LDAP_USERNAME = '%s@cognizant.com' % username
   # your password
   LDAP_PASSWORD = password
   base_dn = 'DC=cts,DC=com'
   ldap_filter = 'userPrincipalName=%s@cognizant.com' % username
   attrs = ['memberOf']
   try:
       # build a client
       ldap_client = ldap.initialize(LDAP_SERVER)
       # perform a synchronous bind
       ldap_client.set_option(ldap.OPT_REFERRALS,0)
       ldap_client.simple_bind_s(LDAP_USERNAME, LDAP_PASSWORD)
   except ldap.INVALID_CREDENTIALS:
       ldap_client.unbind()
       return 'Wrong username or password.  Please try again!!'
   except ldap.SERVER_DOWN:
       return 'AD server not available.  Please try again!!'
   return "Success"  