from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
from collections import OrderedDict
import json
import datetime
from flask import Blueprint
from helper import *

dqf_api = Blueprint('dqf_api', __name__)

with open('config.json','r') as f:
  data = json.load(f)
  
@dqf_api.route("/insert_into_developement_quality_form",methods=['POST'])
def insertInToDvelopmentQualityForm():
    try:
        developmentQualityFormJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])

        date = str(developmentQualityFormJson.get('date_dqf'))
        agent_name = str(developmentQualityFormJson.get('agent_name_dqf'))
        brand_id = str(developmentQualityFormJson.get('brand_id_dqf'))
        brand_name = str(developmentQualityFormJson.get('brand_name_dqf'))
        is_brand_active = str(developmentQualityFormJson.get('is_brand_active_dqf'))
        k15_spent_in_m0m2_period = str(developmentQualityFormJson.get('15k_spent_in_m0m2_period'))
        creation_of_sp_manual = str(developmentQualityFormJson.get('creation_of_sp_manual'))
        keywords_20 = str(developmentQualityFormJson.get('20_keywords'))
        lms_quiz =  str(developmentQualityFormJson.get('lms_quiz'))
        touched_account_after_14_days =  str(developmentQualityFormJson.get('touched_account_after_14_days'))
        no_active_sponsor_camp_1inrspend_perweeklast4week = str(developmentQualityFormJson.get('no_active_sponsor_camp_1inrspend_perweeklast4week'))
        forgot_to_share_wbr_mbr_periodic_basis = str(developmentQualityFormJson.get('forgot_to_share_wbr_mbr_periodic_basis'))
        forgot_share_product_updates_brand_poc = str(developmentQualityFormJson.get('forgot_share_product_updates_brand_poc'))
        nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail = str(developmentQualityFormJson.get('nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail'))
        used_informal_casual_language_inmail = str(developmentQualityFormJson.get('used_informal_casual_language_inmail'))
        nt_use_client_stndrd_templt_applicable = str(developmentQualityFormJson.get('nt_use_client_stndrd_templt_applicable'))
        forgot_to_add_attmts_responding_onmail = str(developmentQualityFormJson.get('forgot_to_add_attmts_responding_onmail'))
        share_proforma_invoice_on_brand_request = str(developmentQualityFormJson.get('share_proforma_invoice_on_brand_request'))
        nt_followed_oob_sop_procedure = str(developmentQualityFormJson.get('nt_followed_oob_sop_procedure'))
        nt_fctr_in_advertiser_restns_applicable_policy = str(developmentQualityFormJson.get('nt_fctr_in_advertiser_restns_applicable_policy'))
        nt_addrs_rqsts_explicit_implicit_qns_rqsts = str(developmentQualityFormJson.get('nt_addrs_rqsts_explicit_implicit_qns_rqsts'))
        used_informal_language_inmail_phone = str(developmentQualityFormJson.get('used_informal_language_inmail_phone'))
        incorct_mislead_informn_lead_confusion = str(developmentQualityFormJson.get('incorct_mislead_informn_lead_confusion'))
        nonreliable_datasource_giving_recommendation_benchmark = str(developmentQualityFormJson.get('nonreliable_datasource_giving_recommendation_benchmark'))
        share_newexisting_campaign_report_with_brand_poc = str(developmentQualityFormJson.get('share_newexisting_campaign_report_with_brand_poc'))
        forgot_toupdate_comments_dsttool = str(developmentQualityFormJson.get('forgot_toupdate_comments_dsttool'))
        incorrect_incomplete_update_amazon_mdm = str(developmentQualityFormJson.get('incorrect_incomplete_update_amazon_mdm'))
        forgot_to_update_the_oob_tracker = str(developmentQualityFormJson.get('forgot_to_update_the_oob_tracker'))
        incorporate_changes_in_ams_portal_instead_drona = str(developmentQualityFormJson.get('incorporate_changes_in_ams_portal_instead_drona'))
        agent_incorrectly_incomplete_update_amazon_MDM = str(developmentQualityFormJson.get('agent_incorrectly_incomplete_update_amazon_MDM'))
        print agent_incorrectly_incomplete_update_amazon_MDM
        agent_didnot_followed_oob_SOP_procedure = str(developmentQualityFormJson.get('agent_didnot_followed_oob_SOP_procedure'))
        agent_did_followup_for_high_ACOS_brands = str(developmentQualityFormJson.get('agent_did_followup_for_high_ACOS_brands'))
        
        
		
        sql = """insert into developmentqualityform (date,agent_name,brand_id,brand_name,is_brand_active,k15_spent_in_m0m2_period,creation_of_sp_manual,keywords_20,lms_quiz,touched_account_after_14_days,no_active_sponsor_camp_1inrspend_perweeklast4week,forgot_to_share_wbr_mbr_periodic_basis,forgot_share_product_updates_brand_poc,nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail,used_informal_casual_language_inmail,nt_use_client_stndrd_templt_applicable,forgot_to_add_attmts_responding_onmail,share_proforma_invoice_on_brand_request,nt_followed_oob_sop_procedure,nt_fctr_in_advertiser_restns_applicable_policy,nt_addrs_rqsts_explicit_implicit_qns_rqsts,used_informal_language_inmail_phone,incorct_mislead_informn_lead_confusion,nonreliable_datasource_giving_recommendation_benchmark,share_newexisting_campaign_report_with_brand_poc,forgot_toupdate_comments_dsttool,incorrect_incomplete_update_amazon_mdm,forgot_to_update_the_oob_tracker,incorporate_changes_in_ams_portal_instead_drona,agent_did_followup_for_high_ACOS_brands) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
       
        val = (date,agent_name,brand_id,brand_name,is_brand_active,k15_spent_in_m0m2_period,creation_of_sp_manual,keywords_20,lms_quiz,touched_account_after_14_days,no_active_sponsor_camp_1inrspend_perweeklast4week,forgot_to_share_wbr_mbr_periodic_basis,forgot_share_product_updates_brand_poc,nt_addrs_rqsts_explicit_implicit_qns_rqsts_mail,used_informal_casual_language_inmail,nt_use_client_stndrd_templt_applicable,forgot_to_add_attmts_responding_onmail,share_proforma_invoice_on_brand_request,nt_followed_oob_sop_procedure,nt_fctr_in_advertiser_restns_applicable_policy,nt_addrs_rqsts_explicit_implicit_qns_rqsts,used_informal_language_inmail_phone,incorct_mislead_informn_lead_confusion,nonreliable_datasource_giving_recommendation_benchmark,share_newexisting_campaign_report_with_brand_poc,forgot_toupdate_comments_dsttool,incorrect_incomplete_update_amazon_mdm,forgot_to_update_the_oob_tracker,incorporate_changes_in_ams_portal_instead_drona,agent_did_followup_for_high_ACOS_brands)
       
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
        mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@dqf_api.route("/retrieve_development_quality_form_data",methods=['POST'])
def retrievedevelopmentQualityFormData():
    try:
       developmentQualityFormJson = request.get_json() 	
       developmentQualityForm = OrderedDict()
       developmentQualityFormArr = []
       developmentQualityFormData = OrderedDict()
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       

       sql_select_query = "select * from developmentqualityform"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records: 
           if row[0] is not None:
               developmentQualityFormData.update({'Date':row[0].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Date':''})
           if row[1] is not None:
               developmentQualityFormData.update({'Agent Name':row[1].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent Name':''})
           if row[2] is not None:
               developmentQualityFormData.update({'Brand ID':row[2].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Brand ID':''})
           if row[3] is not None:
               developmentQualityFormData.update({'Brand Name':row[3].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Brand Name':''})
           if row[4] is not None:
               developmentQualityFormData.update({'Is Brand Active':row[4].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Is Brand Active':''})
           if row[5] is not None:
               developmentQualityFormData.update({'15k spent in their overall M0M2 period':row[5].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'15k spent in their overall M0M2 period':''})
           if row[6] is not None:
               developmentQualityFormData.update({'Creation of SP Manual':row[6].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Creation of SP Manual':''})
           if row[7] is not None:
               developmentQualityFormData.update({'20+ Keywords':row[7].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'20+ Keywords':''})
           if row[8] is not None:
               developmentQualityFormData.update({'LMS Quiz':row[8].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'LMS Quiz':''})
           if row[9] is not None:
               developmentQualityFormData.update({'Agent touched the account after 14 days':row[9].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent touched the account after 14 days':''})
           if row[10] is not None:
               developmentQualityFormData.update({'Brand has no active Sponsored Brand Campaign (minimum 1 INR spend per week, in last 4 weeks)':row[10].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Brand has no active Sponsored Brand Campaign (minimum 1 INR spend per week, in last 4 weeks)':''})
           if row[11] is not None:
               developmentQualityFormData.update({'Agent forgot to share WBR or MBR on periodic basis':row[11].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent forgot to share WBR or MBR on periodic basis':''})
           if row[12] is not None:
               developmentQualityFormData.update({'Agent forgot to share product updates with Brand POC':row[12].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent forgot to share product updates with Brand POC':''})
           if row[13] is not None:
               developmentQualityFormData.update({'Agent did not address the requestors explicit and implicit questions or requests':row[13].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent did not address the requestors explicit and implicit questions or requests':''})
           if row[14] is not None:
               developmentQualityFormData.update({'Agent used informal or casual language in the email':row[14].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent used informal or casual language in the email':''})
           if row[15] is not None:
               developmentQualityFormData.update({'Agent did not use the client or standard template (wherever applicable)':row[15].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent did not use the client or standard template (wherever applicable)':''})
           if row[16] is not None:
               developmentQualityFormData.update({'Agent forgot to add attachments while responding on email':row[16].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent forgot to add attachments while responding on email':''})
           if row[17] is not None:
               developmentQualityFormData.update({'Agent to share the Proforma invoice (on brand request)':row[17].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent to share the Proforma invoice (on brand request)':''})
           if row[18] is not None:
               developmentQualityFormData.update({'Agent didnt followed the Out of balance SOP or procedure':row[18].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent didnt followed the Out of balance SOP or procedure':''})
           if row[19] is not None:
               developmentQualityFormData.update({'Agent did not factor in the advertiser restrictions wherever applicable (Moderation Policy)':row[19].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent did not factor in the advertiser restrictions wherever applicable (Moderation Policy)':''})
           if row[20] is not None:
               developmentQualityFormData.update({'Agent did not address the requestors explicit and implicit questions or requests':row[20].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent did not address the requestors explicit and implicit questions or requests':''})
           if row[21] is not None:
               developmentQualityFormData.update({'Agent used informal or casual language in the email or Phone call':row[21].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent used informal or casual language in the email or Phone call':''})
           if row[22] is not None:
               developmentQualityFormData.update({'Agent provided incorrect or misleading information leading to confusion':row[22].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent provided incorrect or misleading information leading to confusion':''})
           if row[23] is not None:
               developmentQualityFormData.update({'Agent used non reliable data source while giving recommendations or benchmarks':row[23].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent used non reliable data source while giving recommendations or benchmarks':''})
           if row[24] is not None:
               developmentQualityFormData.update({'Agent to share new or existing campaign report with Brand POC (If requested)':row[24].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent to share new or existing campaign report with Brand POC (If requested)':''})
           if row[25] is not None:
               developmentQualityFormData.update({'Agent forgot to Update the comments in DST Tool':row[25].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent forgot to Update the comments in DST Tool':''})
           if row[26] is not None:
               developmentQualityFormData.update({'Agent incorrectly or Incomplete update the Amazon Master data management tool':row[26].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent incorrectly or Incomplete update the Amazon Master data management tool':''})
           if row[27] is not None:
               developmentQualityFormData.update({'Agent forgot to update the Out of Balance tracker':row[27].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent forgot to update the Out of Balance tracker':''})
           if row[28] is not None:
               developmentQualityFormData.update({'Agent incorporate the changes in campaign via AMS portal instead of Drona Tool':row[28].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent incorporate the changes in campaign via AMS portal instead of Drona Tool':''})
           if row[29] is not None:
               developmentQualityFormData.update({'Agent did the followup for High ACOS Brands (M2)':row[29].encode('utf-8').strip()})
           else:
               developmentQualityFormData.update({'Agent did the followup for High ACOS Brands (M2)':''})
           developmentQualityFormArr.append(developmentQualityFormData.copy())
       developmentQualityForm.update({"data":developmentQualityFormArr})
       cursor.close()
       #return jsonify(developmentQualityForm)
       return json.dumps(developmentQualityForm)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		
