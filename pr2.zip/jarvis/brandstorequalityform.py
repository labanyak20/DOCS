from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
from collections import OrderedDict
import json
import datetime
from flask import Blueprint
from helper import *

bqf_api = Blueprint('bqf_api', __name__)

with open('config.json','r') as f:
  data = json.load(f)
  
@bqf_api.route("/insert_into_brandstore_quality_form",methods=['POST'])
def insertInToGrowthQualityForm():
    try:
        brandstoreQualityFormJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])

        entry_date = str(brandstoreQualityFormJson.get('entry_date'))
        entity_id = str(brandstoreQualityFormJson.get('entity_id'))
        brand_name = str(brandstoreQualityFormJson.get('brand_name_brandstore'))
        print brand_name
        store_submission_date = str(brandstoreQualityFormJson.get('store_submission_date'))
        atleast_2_pages_under_home_page = str(brandstoreQualityFormJson.get('atleast_2_pages_under_home_page'))
        atleast_1_product_grid_on_each_page = str(brandstoreQualityFormJson.get('atleast_1_product_grid_on_each_page'))
        use_3_different_tile_types_on_home_page = str(brandstoreQualityFormJson.get('use_3_different_tile_types_on_home_page'))
        top_2_widgets_to_be_clickable =  str(brandstoreQualityFormJson.get('top_2_widgets_to_be_clickable'))
        cta_on_image_tiles_if_actionable =  str(brandstoreQualityFormJson.get('cta_on_image_tiles_if_actionable'))
        use_of_mobile_optimization_feature_for_image_tiles = str(brandstoreQualityFormJson.get('use_of_mobile_optimization_feature_for_image_tiles'))
        rejection_count = str(brandstoreQualityFormJson.get('rejection_count'))
        		
        sql = """insert into brandstorequalityform (entry_date,entity_id,brand_name,store_submission_date,atleast_2_pages_under_home_page,atleast_1_product_grid_on_each_page,use_3_different_tile_types_on_home_page,top_2_widgets_to_be_clickable,cta_on_image_tiles_if_actionable,use_of_mobile_optimization_feature_for_image_tiles,rejection_count) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
       
        val = (entry_date,entity_id,brand_name,store_submission_date,atleast_2_pages_under_home_page,atleast_1_product_grid_on_each_page,use_3_different_tile_types_on_home_page,top_2_widgets_to_be_clickable,cta_on_image_tiles_if_actionable,use_of_mobile_optimization_feature_for_image_tiles,rejection_count)
       
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
        mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@bqf_api.route("/retrieve_brandstore_quality_form_data",methods=['POST'])
def retrieveBrandStoreQualityFormData():
    try:
       brandstoreQualityFormJson = request.get_json() 	
       brandstoreQualityForm = OrderedDict()
       brandstoreQualityFormArr = []
       brandstoreQualityFormData = OrderedDict()
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_qualityform'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       

       sql_select_query = "select * from brandstorequalityform"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records: 
           brandstoreQualityFormData.update({'Entry Date':row[0].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Entity ID':row[1].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Brand Name':row[2].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Store Submission Date':row[3].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Atleast 2 pages under home page':row[4].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Atleast 1 product grid on each page':row[5].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Use 3 different tile types on home page':row[6].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Top 2 widgets to be clickable':row[7].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'CTA on image tiles (if actionable)':row[8].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Use of mobile optimization feature for image tiles':row[9].encode('utf-8').strip()})
           brandstoreQualityFormData.update({'Rejection count':row[10].encode('utf-8').strip()})
           brandstoreQualityFormArr.append(brandstoreQualityFormData.copy())
       brandstoreQualityForm.update({"data":brandstoreQualityFormArr})
       cursor.close()
       #return jsonify(brandstoreQualityForm)
       return json.dumps(brandstoreQualityForm)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		
