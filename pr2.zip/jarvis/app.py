from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
from collections import OrderedDict
import json
import datetime
from brandstorequalityform import bqf_api
from developmentqualityform import dqf_api
from selleradvertising import sqf_api
from massengagement import mqf_api
from acquistionteamform import atf_api
from admin_mgmt import admin_mgmt_api
from sellermdm import smdm_api
from helper import *
from ldapAuth import *
from send_mail import *
from random import randint

app = Flask(__name__)
app.debug=True
app.secret_key = os.urandom(12)
app.config.update(
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
)

error = None;

with open('config.json','r') as f:
  data = json.load(f)

app.register_blueprint(bqf_api)
app.register_blueprint(dqf_api)
app.register_blueprint(sqf_api)
app.register_blueprint(mqf_api)
app.register_blueprint(atf_api)
app.register_blueprint(admin_mgmt_api)
app.register_blueprint(smdm_api)

@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate, pre-check=0, post-check=0, max-age=0, s-maxage=0"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    
    r.headers['X-XSS-Protection'] = '1; mode=block'
    r.headers['X-Frame-Options'] = 'SAMEORIGIN'
    r.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    r.headers['X-Content-Type-Options'] = 'nosniff'
    r.headers['Content-Security-Policy'] = "default-src 'self' style-src 'self' 'unsafe-inline';"
    r.set_cookie('session', 'flask', secure=True, httponly=True, samesite='Lax')
    r.headers['server'] = "Not Available"
    return r


#max timeout function
@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=30)

@app.route('/login')
def login():
    if not session.get('logged_in'):
        return render_template('login.html' , error=error)
    else:
        return redirect(url_for('otp'))
 
@app.route('/validate', methods=['POST'])
def validate():
    associateId = request.form['username'];
    password = request.form['password']
    associateRole = retrieveAssociateDetails(associateId)
    session['associateId'] = associateId
    
    if associateRole is not None:
        auth = check_credentials(associateId, password)
        if auth == "Success":
            session['logged_in'] = True
            otp = insert_OTP();
            emailId = retrieveEmailID(associateId)       
            send_mail(emailId, otp)
            return redirect(url_for('otp'))
        else:
            global error
            error = auth
            logout()
            return redirect(url_for('login'))			
    else:
        return redirect(url_for('login'))
    return login()
	
@app.route('/guest_validate', methods=['POST'])
def guest_validate():
    associateId = request.form['username'];
    associateRole = retrieveAssociateDetails(associateId)
    session['associateId'] = associateId
    
    if associateRole is not None:
        session['logged_in'] = True
        otp = insert_OTP();
        emailId = retrieveEmailID(associateId)       
        send_mail(emailId, otp)
        return redirect(url_for('otp'))			
    else:
        global error
        error = "Not a valid username. Please contact administrator."
        logout()		
        return redirect(url_for('login'))
    return login()	

@app.route('/otp')
def otp():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return render_template('otp.html')
    else:
        return redirect(url_for('index'))	
        
@app.route('/validateotp', methods=['POST'])
def validate_otp():
    otp = request.form['OTP']
    associateId = session.get('associateId')
    otp_db = retrieveOTP(associateId)
    if otp_db is not None and otp == otp_db:
        session['otp'] = True
        delete_OTP(associateId)
        return redirect(url_for('index'))
    else:
        global error
        error = "Invalid OTP. Please try again!"
        return redirect(url_for('otp'))
    return otp()

@app.route("/logout")
def logout():
    session['associateId'] = None
    session['logged_in'] = False
    session['otp'] = False
    session['access_from_brand_poc'] = False
    return redirect(url_for('login'))
	
@app.route('/index')
def index():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp'))    	
    else:
        associateId = session.get('associateId')
        insert_logintime(associateId)
        return render_template('index.html') 	
	
@app.route("/dailystatustracker")
def dailystatustracker():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else: 
        return render_template('dailystatustracker.html')

@app.route("/keywordanalyzer")
def keywordanalyzer():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('keywordanalyzer.html')

@app.route("/keywordtrend")
def keywordtrend():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('keywordtrend.html')

@app.route("/brandmasterdata")
def brandmasterdata():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    else:
        return render_template('brandmasterdata.html')		
		
@app.route("/growthqualityform")
def growthQualityForm():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('qualityForm.html')				

@app.route("/oobreport")
def oobreport():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('oob.html')


@app.route("/brandstorereport")
def brandstorereport():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('brandstoretracker.html')

@app.route("/sponsoredbrandskeywordanalyzer")
def sponsoredbrandskeywordanalyzer():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('sponsoredbrandskeywordanalyzer.html')

@app.route("/sponsoredbrandskeywordtrend")
def sponsoredbrandskeywordtrend():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('sponsoredbrandskeywordtrend.html')

@app.route("/acquistionteamform")
def acquisitionform():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('acquistionteamform.html')
                
@app.route("/adminmgmt")
def adminmgmt():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('adminmgmt.html')

@app.route("/sellermdm")
def sellermdm():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    elif not session.get('otp'):
        return redirect(url_for('otp')) 
    else:
        return render_template('sellermasterdata.html')
     
def retrieveAssociateDetails(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       sql_select_Query = "select * from associates"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       associateRole = None;
       for row in records:
           if associateId == str(row[0]):
               associateRole = str(row[2])   
       cursor.close()
       return associateRole
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		

def retrieveAssociateName(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       sql_select_Query = "select * from associates"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       associateName = None;
       for row in records:
           if associateId == str(row[0]):
               associateName = str(row[1])  
       cursor.close()
       return associateName
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@app.route("/retrieve_associate_team_name", methods=['POST'])
def retrieveAssociateTeamName():
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       
       associateId = session.get('associateId')
       associateId = '"{}"'.format(associateId)						 
       sql_select_query = "select teamname from associates where associateid = "+associateId
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       teamname = None
       for row in records:
            teamname = str(row[0]) 
       return teamname
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")	
         
@app.route("/retrieve_associate_name", methods=['POST'])
def retrieve_associate_name():
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       
       associateId = session.get('associateId')
       associateId = '"{}"'.format(associateId)						 
       sql_select_query = "select associatename from associates where associateid = "+associateId
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       associatename = None
       for row in records:
           if row[0] is not None:      
               associatename = str(row[0])
           else:
               session['associateId'] = None
               session['logged_in'] = False
               session['access_from_brand_poc'] = False  
       return associatename
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")            			

def retrieveEmailID(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_database'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       
       sql_select_Query = "select * from associates"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       emailId = None;
       for row in records:
           if associateId == str(row[0]):
               emailId = str(row[4])  
       cursor.close()
       return emailId
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")	

def insert_OTP():
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_database'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       
       
       associateId = session.get('associateId')		
       otp_rnd=randint(100000,999999)
       sql = "update associates set otp = %s where associateid = %s" 
       val = (otp_rnd, associateId)	 
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       mySQLconnection.commit()
       cursor.close()
       return otp_rnd
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")	

def retrieveOTP(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_database'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       
       sql_select_Query = "select * from associates"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       OTP = None;
       for row in records:
           if associateId == str(row[0]):
               OTP = str(row[5])  
       cursor.close()
       return OTP
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")
            
def delete_OTP(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_database'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       
       sql = "update associates SET otp = %s where associateid = %s" 
       val = ('NULL', associateId)	 
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       mySQLconnection.commit()
       cursor.close()
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")	            

def insert_logintime(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       sql_select_Query = "select * from associates where associateid = " + associateId
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       associateName = None;
       associateMailId = None;
       for row in records:
           if associateId == str(row[0]):
               associateName = str(row[1])
               associateMailId = str(row[4])
       cursor.close()
       mySQLconnection.close()
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       lastlogindate=None
       associateid = associateId
       associatename = associateName
       email_id = associateMailId
       lastlogintime=retrieveLastloginTime(associateId)
       if lastlogintime is not None :
           datetime_obj=changeDateTimeFormat(lastlogintime)
           lastlogindate=datetime_obj.strftime('%Y-%m-%d')
       else : 
           lastlogindate=None
       today_date = datetime.datetime.now().strftime('%Y-%m-%d')
       print(lastlogindate)
       print(today_date)
       if lastlogindate<>today_date:
            logintime=datetime.datetime.now().strftime('%Y-%m-%d-%H:%M')
            sql = """insert into agent_attendance(associateid,associatename,email_id,logintime)VALUES (%s, %s, %s, %s);"""
            val = (associateid,associatename,email_id,logintime)
            cursor = mySQLconnection.cursor()
            cursor.execute(sql,val)
            mySQLconnection.commit()
            cursor.close()
       mySQLconnection.close()
       return 'success'
       
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

def retrieveLastloginTime(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       
       sql_select_Query = "select * from agent_attendance where associateid= "+associateId
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       lastlogintime = None;
       print(cursor.rowcount)
       if (cursor.rowcount) >0:
               record1 = records[(cursor.rowcount)-1]
               if record1[3] is not None and record1[3]<>"":
                   lastlogintime = record1[3]
                   
               else : 
                   lastlogintime = None;
                   
       cursor.close()
       return lastlogintime
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")
            
def changeDateTimeFormat(dateStr):
    date_str = dateStr
    format_str = '%Y-%m-%d-%H:%M'
    datetime_obj = datetime.datetime.strptime(date_str, format_str)
    return datetime_obj

			
@app.route("/insert_into_dst", methods=['POST'])
def insertIntoDailyStatusTracker():
    try:
       dstjson = request.get_json()
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='dstdb',
                             user='root',
                             password='mysqlCT5!')
       formid = str(dstjson.get('formid'))
       now = str(dstjson.get('date'))
       brandid = str(dstjson.get('brandid'))
       brandname = str(dstjson.get('brandname'))
       parentbrandname = str(dstjson.get('parentbrandname'))
       existingcampaign = str(dstjson.get('numberofexistingcampaign'))
       campaignnewlyadded = str(dstjson.get('numberofcampaignnewlyadded'))
       issuecategory = str(dstjson.get('issuecategory'))
       issuesubcategory = str(dstjson.get('issuesubcategory'))
       additionalissuediscussed = str(dstjson.get('additionalissuediscussed'))
       casenotes = str(dstjson.get('casenotes'))
       communicationtype = str(dstjson.get('communicationtype'))
       followupdate = str(dstjson.get('followupdate'))
       escalationrequired = str(dstjson.get('escalationrequired'))
       callstarttime = str(dstjson.get('callstarttime'))
       callstoptime = str(dstjson.get('callstoptime'))
       teamname = str(dstjson.get('teamname'))
       sponsoredbrandactive = str(dstjson.get('sponsoredbrandactive'))
       inactivebrand = str(dstjson.get('inactivebrand'))
       sboptimization = str(dstjson.get('sboptimization'))
       sboptimizationcategory = str(dstjson.get('sboptimizationcategory'))
       communicationestablished = str(dstjson.get('communicationestablished'))
       createdby = str(dstjson.get('associatename'))
	   
       sql = """insert into dailystatustracker(formid,date,brandname,brandid,numberofexistingcampaign,numberofcampaignnewlyadded,issuecategory,issuesubcategory,casenotes,communicationtype,followupdate,additionalissuediscussed,callstarttime,callstoptime,createdby,escalationrequired,teamname,sponsoredbrandactive,inactivebrand,parentbrandname,sboptimization,sboptimizationcategory,communicationestablished)VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s,%s,%s);"""
      
       val = (formid,now,brandname,brandid,existingcampaign,campaignnewlyadded,issuecategory,issuesubcategory,casenotes,communicationtype,followupdate,additionalissuediscussed,callstarttime,callstoptime,createdby,escalationrequired,teamname,sponsoredbrandactive,inactivebrand,parentbrandname,sboptimization,sboptimizationcategory,communicationestablished)
       
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       mySQLconnection.commit()
       cursor.close()
       return 'success'

    except Exception as e :
        print ("Error while connecting to MySQL", e)
        app.logger.error(e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@app.route("/retrieve_dst_data",methods=['POST'])
def retrieveDstData():
    try:
       filterJson = request.get_json()	
       dst = {}
       dstArr = []
       dstData = {}
       filterCategory = str(filterJson.get('filterCategory'))
       value = str(filterJson.get('filterValue'))
       filterValue = '"{}"'.format(value)  
       filterFromDate = str(filterJson.get('filterFromDate'))
       filterFromDate = '"{}"'.format(filterFromDate) 
       filterToDate = str(filterJson.get('filterToDate'))
       filterToDate = '"{}"'.format(filterToDate)
        
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='dstdb',
                             user='root',
                             password='mysqlCT5!')
       if filterCategory and not filterCategory == "date":
           sql_select_query = "select * from dailystatustracker where "+filterCategory+" = "+filterValue
       elif filterCategory and filterCategory == "date":
           sql_select_query = "select * from dailystatustracker where date >= "+ filterFromDate + "and date <= "+filterToDate
       else:
           sql_select_query = "select * from dailystatustracker" 
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       for row in records: 
           if row[0] is not None:  
               dstData.update({'FormId':row[0].encode('utf-8').strip()})
           else:
               dstData.update({'FormId':''})
           if row[1] is not None:
               dstData.update({'Date':row[1].encode('utf-8').strip()})
           else:
               dstData.update({'Date':''})
           if row[2] is not None:
               dstData.update({'BrandName':row[2].encode('utf-8').strip()})
           else:
               dstData.update({'BrandName':''})
           if row[3] is not None:
               dstData.update({'BrandId':row[3].encode('utf-8').strip()})
           else:
               dstData.update({'BrandId':''})
           if row[4] is not None:
               dstData.update({'NumberOfExistingCampaign':row[4].encode('utf-8').strip()})
           else:
               dstData.update({'NumberOfExistingCampaign':''})
           if row[5] is not None:
               dstData.update({'NumberOfCampaignNewlyAdded':row[5].encode('utf-8').strip()})
           else:
               dstData.update({'NumberOfCampaignNewlyAdded':''})
           if row[6] is not None:
               dstData.update({'IssueCategory':row[6].encode('utf-8').strip()})
           else:
               dstData.update({'IssueCategory':''})
           if row[7] is not None:
               dstData.update({'IssueSubCategory':row[7].encode('utf-8').strip()})
           else:
               dstData.update({'IssueSubCategory':''})
           if row[8] is not None:
               dstData.update({'CaseNotes':row[8].encode('utf-8').strip()})
           else:
               dstData.update({'CaseNotes':''})
           if row[9] is not None:
               dstData.update({'CommunicationType':row[9].encode('utf-8').strip()})
           else:
               dstData.update({'CommunicationType':''})
           if row[10] is not None:
               dstData.update({'FollowUpDate':row[10].encode('utf-8').strip()})
           else:
               dstData.update({'FollowUpDate':''})
           if row[11] is not None:
               dstData.update({'AdditionalIssueDiscussed':row[11].encode('utf-8').strip()})
           else:
               dstData.update({'AdditionalIssueDiscussed':''})
           if row[12] is not None:
               dstData.update({'CallStartTime':row[12].encode('utf-8').strip()})
           else:
               dstData.update({'CallStartTime':''})		
           if row[13] is not None:
               dstData.update({'CallStopTime':row[13].encode('utf-8').strip()})
           else:
               dstData.update({'CallStopTime':''})
           if row[14] is not None:
               dstData.update({'CreatedBy':row[14].encode('utf-8').strip()})
           else:
               dstData.update({'CreatedBy':''})
           if row[15] is not None:
               dstData.update({'EscalationRequired':row[15].encode('utf-8').strip()})
           else:
               dstData.update({'EscalationRequired':''})
           if row[16] is not None:
               dstData.update({'TeamName':str(row[16])})
           else:
               dstData.update({'TeamName':''})
           if row[17] is not None:
               dstData.update({'SponsoredBrandActive':str(row[17])})
           else:
               dstData.update({'SponsoredBrandActive':''})
           if row[18] is not None:
               dstData.update({'InactiveBrand':str(row[18])})
           else:
               dstData.update({'InactiveBrand':''})
           if row[19] is not None:
               dstData.update({'ParentBrandName':str(row[19])})
           else:
               dstData.update({'ParentBrandName':''})
           if row[20] is not None:
               dstData.update({'SBoptimization':row[20].encode('utf-8').strip()})
           else:
               dstData.update({'SBoptimization':''})    
           if row[21] is not None:
               dstData.update({'SBoptimizationcategory':row[21].encode('utf-8').strip()})
           else:
               dstData.update({'SBoptimizationcategory':''})
           if row[22] is not None:
               dstData.update({'CommunicationEstablished':row[22].encode('utf-8').strip()})
           else:
               dstData.update({'CommunicationEstablished':''})
           dstArr.append(dstData.copy())
       dst.update({"dst":dstArr})
       cursor.close()
       return jsonify(dst)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@app.route("/insertinto_brand_mdm",methods=['POST'])
def updateBrandMDM():
    try:
       brandMdmJson = request.get_json()
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='brandmdmdb',
                             user='root',
                             password='mysqlCT5!')
							 
       brand_type = str(brandMdmJson.get('brand_type'))
       brand_id = str(brandMdmJson.get('brand_id'))
       brand_name = str(brandMdmJson.get('brand_name'))
       number_of_sub_brands = str(brandMdmJson.get('number_of_sub_brands'))
       print number_of_sub_brands
       sub_brand_name = str(brandMdmJson.get('sub_brand_name'))
       #print sub_brand_name
       category = str(brandMdmJson.get('category'))
       sub_category = str(brandMdmJson.get('sub_category'))
       source_channel = str(brandMdmJson.get('source_channel'))
       team_name = str(brandMdmJson.get('team_name'))
       service_type = str(brandMdmJson.get('service_type'))
       monthly_budget = str(brandMdmJson.get('monthly_budget'))
       launch_date = str(brandMdmJson.get('launch_date'))
       allocation_date_to_cts = str(brandMdmJson.get('allocation_date_to_cts'))
       access_from_brand_poc = str(brandMdmJson.get('access_from_brand_poc'))
       changes_incorporation_in_brand = str(brandMdmJson.get('changes_incorporation_in_brand'))
       reallocation_date = str(brandMdmJson.get('reallocation_date'))
       brand_status = str(brandMdmJson.get('brand_status'))
       removed_date = str(brandMdmJson.get('removed_date'))
       access_given = str(brandMdmJson.get('access_given'))
       invites_received = str(brandMdmJson.get('invites_received'))
       action = str(brandMdmJson.get('action'))
       brand_poc_name1 = str(brandMdmJson.get('brand_poc_name1'))
       brand_poc_phone1 = str(brandMdmJson.get('brand_poc_phone1'))
       brand_poc_email1 = str(brandMdmJson.get('brand_poc_email1'))
       brand_poc_name2 = str(brandMdmJson.get('brand_poc_name2'))
       brand_poc_phone2 = str(brandMdmJson.get('brand_poc_phone2'))
       brand_poc_email2 = str(brandMdmJson.get('brand_poc_email2'))
       brand_poc_name3 = str(brandMdmJson.get('brand_poc_name3'))
       brand_poc_phone3 = str(brandMdmJson.get('brand_poc_phone3'))
       brand_poc_email3 = str(brandMdmJson.get('brand_poc_email3'))
       amazon_contact_point_name = str(brandMdmJson.get('amazon_contact_point_name'))
       amazon_contact_point_email_address = str(brandMdmJson.get('amazon_contact_point_email_address'))
       cognizant_contact_point = str(brandMdmJson.get('cognizant_contact_point'))
       status = "current"
       associateName = retrieveAssociateName(session.get('associateId'))
       brand_store = str(brandMdmJson.get('brand_store'))
       brand_modification_date = str(brandMdmJson.get('brand_modification_date'))
       
       sql = "select brand_entry_date from brandmdm where brand_id = %s and status = %s"
       val = (brand_id, "current")	 
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       records_brandentrydate = cursor.fetchone()
       print records_brandentrydate
       if records_brandentrydate is not None and records_brandentrydate<>"" and records_brandentrydate<>'NULL':
           brand_entry_date = str(records_brandentrydate[0])
       else:
           brand_entry_date = str(brandMdmJson.get('brand_modification_date'))
       cursor.close()

	   
       sql = "update brandmdm SET status = %s where brand_id = %s and status = %s" 
       val = ("history", brand_id, "current")	 
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       
       sql = """insert into brandmdm (brand_id,brand_name,category,sub_category,team_name,service_type,allocation_date_to_cts,access_from_brand_poc,changes_incorporation_in_brand,brand_status,brand_poc_name1,brand_poc_phone1,brand_poc_email1,brand_poc_name2,brand_poc_phone2,brand_poc_email2,brand_poc_name3,brand_poc_phone3,brand_poc_email3,amazon_contact_point_name,amazon_contact_point_email_address,cognizant_contact_point,created_by,status,launch_date,removed_date,source_channel,monthly_budget,access_given,invites_received,action,brand_store,reallocation_date,brand_type,number_of_sub_brands,sub_brand_name,brand_entry_date,brand_modification_date) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        
       val = (brand_id, brand_name, category, sub_category, team_name, service_type, allocation_date_to_cts, access_from_brand_poc, changes_incorporation_in_brand, brand_status, brand_poc_name1 , brand_poc_phone1, brand_poc_email1, brand_poc_name2, brand_poc_phone2, brand_poc_email2, brand_poc_name3, brand_poc_phone3, brand_poc_email3, amazon_contact_point_name, amazon_contact_point_email_address, cognizant_contact_point,associateName,status,launch_date,removed_date,source_channel,monthly_budget,access_given,invites_received,action,brand_store,reallocation_date,brand_type,number_of_sub_brands,sub_brand_name,brand_entry_date,brand_modification_date)	
       	   
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       mySQLconnection.commit()
       cursor.close()
       
       if brand_status == 'Removed':
           msg = UpdateBrandStatusofOOBTracker(brand_id)
       
       return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
        app.logger.error(e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")
	

@app.route("/check_brand_id",methods=['POST'])
def checkBrandData():
    try:
       brandJson = request.get_json()	
       brandData = {}
       brandId = str(brandJson.get('brand_id').encode('utf-8').strip())
       status = "current"
       duplicate = "" 
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='brandmdmdb',
                             user='root',
                             password='mysqlCT5!')

       sql = "select * from brandmdm where brand_id = %s and status = %s"
       val = (brandId, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql, val)
       records = cursor.fetchall()
       if(len(records) > 0):
           duplicate = "Brand already exists. Please modify the same!!"
       cursor.close()    
       return duplicate
           
    except Exception as e :
        print ("Error while checking brand details",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")                

@app.route("/retrieve_brand_data",methods=['POST'])
def retrieveBrandData():
    try:
       brandJson = request.get_json()	
       brandData = {}
       brandId = str(brandJson.get('brand_id'))
       status = "current"
       brandType = ""       
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='brandmdmdb',
                             user='root',
                             password='mysqlCT5!')

       sql = "select * from brandmdm where brand_id = %s and status = %s"
       val = (brandId, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql, val)
       records = cursor.fetchall()
       for row in records:
           
           if row[0] is not None:	   
               brandData.update({'brand_id':row[0].encode('utf-8').strip()})
           else:
               brandData.update({'brand_id':''})		   
           if row[1] is not None:	      
               brandData.update({'brand_name':row[1].encode('utf-8').strip()})
           else:
               brandData.update({'brand_name':''})			   
           if row[2] is not None:
               brandData.update({'category':row[2].encode('utf-8').strip()})
           else:
               brandData.update({'category':''})
           if row[3] is not None:
               brandData.update({'sub_category':row[3].encode('utf-8').strip()})
           else:
               brandData.update({'sub_category':''})
           if row[4] is not None:
               brandData.update({'team_name':row[4].encode('utf-8').strip()})
           else:
               brandData.update({'team_name':''})
           if row[5] is not None:
               brandData.update({'service_type':row[5].encode('utf-8').strip()})
           else:
               brandData.update({'service_type':''}) 	   
           if row[6] is not None:
               brandData.update({'allocation_date_to_cts':row[6].encode('utf-8').strip()})
           else:
               brandData.update({'allocation_date_to_cts':''})			   
           if row[7] is not None:
               brandData.update({'access_from_brand_poc':row[7].encode('utf-8').strip()})
           else:
               brandData.update({'access_from_brand_poc':''})			    
           if row[8] is not None:
               brandData.update({'changes_incorporation_in_brand':row[8].encode('utf-8').strip()})
           else:
               brandData.update({'changes_incorporation_in_brand':''})
           if row[9] is not None:
               brandData.update({'brand_status':row[9].encode('utf-8').strip()})
           else:
               brandData.update({'brand_status':''})	   
           if row[10] is not None:
               brandData.update({'brand_poc_name1':row[10].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name1':''})
           if row[11] is not None:
               brandData.update({'brand_poc_phone1':row[11].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone1':''})
           if row[12] is not None:
               brandData.update({'brand_poc_email1':row[12].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_email1':''})
           if row[13] is not None:
               brandData.update({'brand_poc_name2':row[13].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name2':''})
           if row[14] is not None:
               brandData.update({'brand_poc_phone2':row[14].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone2':''})
           if row[15] is not None:
               brandData.update({'brand_poc_email2':row[15].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_email2':''})
           if row[16] is not None:
               brandData.update({'brand_poc_name3':row[16].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name3':''})
           if row[17] is not None:
               brandData.update({'brand_poc_phone3':row[17].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone3':''})
           if row[18] is not None:
               brandData.update({'brand_poc_email3':row[18].encode('utf-8').strip()}) 
           else:
               brandData.update({'brand_poc_email3':''})
           if row[19] is not None:
               brandData.update({'amazon_contact_point_name':row[19].encode('utf-8').strip()})
           else:
               brandData.update({'amazon_contact_point_name':''})
           if row[20] is not None:
               brandData.update({'amazon_contact_point_email_address':row[20].encode('utf-8').strip()})
           else:
               brandData.update({'amazon_contact_point_email_address':''})
           if row[21] is not None:
               brandData.update({'cognizant_contact_point':row[21].encode('utf-8').strip()})
           else:
               brandData.update({'cognizant_contact_point':''})
           if row[22] is not None:
               brandData.update({'created_by':row[22].encode('utf-8').strip()})
           else:
               brandData.update({'created_by':''})
           if row[24] is not None:
               brandData.update({'launch_date':row[24].encode('utf-8').strip()})
           else:
               brandData.update({'launch_date':''})
           if row[25] is not None:
               brandData.update({'removed_date':row[25].encode('utf-8').strip()})
           else:
               brandData.update({'removed_date':''})
           if row[26] is not None:
               brandData.update({'source_channel':row[26].encode('utf-8').strip()})
           else:
               brandData.update({'source_channel':''})
           if row[27] is not None:
               brandData.update({'monthly_budget':row[27].encode('utf-8').strip()})
           else:
               brandData.update({'monthly_budget':''})
           if row[28] is not None:
               brandData.update({'access_given':row[28].encode('utf-8').strip()})
           else:
               brandData.update({'access_given':''})
           if row[29] is not None:
               brandData.update({'invites_received':row[29].encode('utf-8').strip()})
           else:
               brandData.update({'invites_received':''})
           if row[30] is not None:
               brandData.update({'action':row[30].encode('utf-8').strip()})
           else:
               brandData.update({'action':''})
           if row[31] is not None:
               brandData.update({'brand_store':row[31].encode('utf-8').strip()})
           else:
               brandData.update({'brand_store':''})
           if row[32] is not None:
               brandData.update({'reallocation_date':row[32].encode('utf-8').strip()})
           else:
               brandData.update({'reallocation_date':''})
           if row[33] is not None:
               brandData.update({'brand_type':row[33].encode('utf-8').strip()})
               brandType =  row[33].encode('utf-8').strip()              
           else:
               brandData.update({'brand_type':''})
           if row[34] is not None:
               brandData.update({'number_of_sub_brands':row[34].encode('utf-8').strip()})    
           else:
               brandData.update({'number_of_sub_brands':''})
           if row[35] is not None:
               brandData.update({'sub_brand_name':row[35].encode('utf-8').strip()})    
           else:
               brandData.update({'sub_brand_name':''})
                            
       cursor.close()
       return jsonify(brandData)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")
			
@app.route("/retrieve_brand_report",methods=['POST'])
def retrieveBrandReport():
    try:
       filterJson = request.get_json() 	
       brand = {}
       brandArr = []
       brandData = {}
       filterCategory = str(filterJson.get('filterCategory'))
       value = str(filterJson.get('filterValue'))
       filterValue = '"{}"'.format(value)  
       filterFromDate = str(filterJson.get('filterFromDate'))
       filterFromDate = '"{}"'.format(filterFromDate) 
       filterToDate = str(filterJson.get('filterToDate'))
       filterToDate = '"{}"'.format(filterToDate)
       status = "current"
       status = '"{}"'.format(status)
       
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='brandmdmdb',
                             user='root',
                             password='mysqlCT5!')
       
       if filterCategory and not filterCategory == "allocation_date_to_cts" and not filterCategory == "brand_status":
           sql_select_query = "select * from brandmdm where "+filterCategory+ " = " +filterValue + "and status = "+status+" and brand_status = 'With CTS'"
       elif filterCategory and filterCategory == "allocation_date_to_cts":
           sql_select_query = "select * from brandmdm where allocation_date_to_cts >= "+ filterFromDate + "and allocation_date_to_cts <= "+filterToDate+ "and status = "+status+" and brand_status = 'With CTS'"
       elif filterCategory and filterCategory == "brand_status":
           sql_select_query = "select * from brandmdm where "+filterCategory+ " = " +filterValue + "and status = "+status
       elif filterCategory and filterCategory == "team_name":
           sql_select_query = "select * from brandmdm where "+filterCategory+ " = " +filterValue + "and status = "+status		   
       else:
           sql_select_query = "select * from brandmdm where status = " + status + " and brand_status = 'With CTS'"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records: 
           if row[0] is not None:	   
               brandData.update({'brand_id':row[0].encode('utf-8').strip()})
           else:
               brandData.update({'brand_id':''})		   
           if row[1] is not None:	      
               brandData.update({'brand_name':row[1].encode('utf-8').strip()})
           else:
               brandData.update({'brand_name':''})			   
           if row[2] is not None:
               brandData.update({'category':row[2].encode('utf-8').strip()})
           else:
               brandData.update({'category':''})
           if row[3] is not None:
               brandData.update({'sub_category':row[3].encode('utf-8').strip()})
           else:
               brandData.update({'sub_category':''})
           if row[4] is not None:
               brandData.update({'team_name':row[4].encode('utf-8').strip()})
           else:
               brandData.update({'team_name':''})
           if row[5] is not None:
               brandData.update({'service_type':row[5].encode('utf-8').strip()})
           else:
               brandData.update({'service_type':''}) 	   
           if row[6] is not None:
               brandData.update({'allocation_date_to_cts':row[6].encode('utf-8').strip()})
           else:
               brandData.update({'allocation_date_to_cts':''})			   
           if row[7] is not None:
               brandData.update({'access_from_brand_poc':row[7].encode('utf-8').strip()})
           else:
               brandData.update({'access_from_brand_poc':''})			    
           if row[8] is not None:
               brandData.update({'changes_incorporation_in_brand':row[8].encode('utf-8').strip()})
           else:
               brandData.update({'changes_incorporation_in_brand':''})
           if row[9] is not None:
               brandData.update({'brand_status':row[9].encode('utf-8').strip()})
           else:
               brandData.update({'brand_status':''})	   
           if row[10] is not None:
               brandData.update({'brand_poc_name1':row[10].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name1':''})
           if row[11] is not None:
               brandData.update({'brand_poc_phone1':row[11].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone1':''})
           if row[12] is not None:
               brandData.update({'brand_poc_email1':row[12].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_email1':''})
           if row[13] is not None:
               brandData.update({'brand_poc_name2':row[13].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name2':''})
           if row[14] is not None:
               brandData.update({'brand_poc_phone2':row[14].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone2':''})
           if row[15] is not None:
               brandData.update({'brand_poc_email2':row[15].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_email2':''})
           if row[16] is not None:
               brandData.update({'brand_poc_name3':row[16].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name3':''})
           if row[17] is not None:
               brandData.update({'brand_poc_phone3':row[17].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone3':''})
           if row[18] is not None:
               brandData.update({'brand_poc_email3':row[18].encode('utf-8').strip()}) 
           else:
               brandData.update({'brand_poc_email3':''})
           if row[19] is not None:
               brandData.update({'amazon_contact_point_name':row[19].encode('utf-8').strip()})
           else:
               brandData.update({'amazon_contact_point_name':''})
           if row[20] is not None:
               brandData.update({'amazon_contact_point_email_address':row[20].encode('utf-8').strip()})
           else:
               brandData.update({'amazon_contact_point_email_address':''})
           if row[21] is not None:
               brandData.update({'cognizant_contact_point':row[21].encode('utf-8').strip()})
           else:
               brandData.update({'cognizant_contact_point':''})
           if row[22] is not None:
               brandData.update({'created_by':row[22].encode('utf-8').strip()})
           else:
               brandData.update({'created_by':''})
           if row[24] is not None:
               brandData.update({'launch_date':row[24].encode('utf-8').strip()})
           else:
               brandData.update({'launch_date':''})
           if row[25] is not None:
               brandData.update({'removed_date':row[25].encode('utf-8').strip()})
           else:
               brandData.update({'removed_date':''})
           if row[26] is not None:
               brandData.update({'source_channel':row[26].encode('utf-8').strip()})
           else:
               brandData.update({'source_channel':''})
           if row[27] is not None:
               brandData.update({'monthly_budget':row[27].encode('utf-8').strip()})
           else:
               brandData.update({'monthly_budget':''})
           if row[28] is not None:
               brandData.update({'access_given':row[28].encode('utf-8').strip()})
           else:
               brandData.update({'access_given':''})
           if row[29] is not None:
               brandData.update({'invites_received':row[29].encode('utf-8').strip()})
           else:
               brandData.update({'invites_received':''})
           if row[30] is not None:
               brandData.update({'action':row[30].encode('utf-8').strip()})
           else:
               brandData.update({'action':''})
           if row[31] is not None:
               brandData.update({'brand_store':row[31].encode('utf-8').strip()})
           else:
               brandData.update({'brand_store':''})
           if row[32] is not None:
               brandData.update({'reallocation_date':row[32].encode('utf-8').strip()})
           else:
               brandData.update({'reallocation_date':''})
           if row[33] is not None:
               brandData.update({'brand_type':row[33].encode('utf-8').strip()})
           else:
               brandData.update({'brand_type':''})
           if row[34] is not None:
               brandData.update({'number_of_sub_brands':row[34].encode('utf-8').strip()})    
           else:
               brandData.update({'number_of_sub_brands':''})
           if row[35] is not None:
              subBrandNames=row[35].encode('utf-8').strip()
              sub_brand_names_list = subBrandNames.split(',')
              i=1
              for subbrand in sub_brand_names_list:
                  brandData.update({'sub_brand_name'+str(i):subbrand})
                  i=i+1
                #brandData.update({'sub_brand_name':row[35].encode('utf-8').strip()})    
           else:
               brandData.update({'sub_brand_name':''})
           if row[36] is not None:
               brandData.update({'brand_entry_date':row[36].encode('utf-8').strip()})    
           else:
               brandData.update({'brand_entry_date':''})
           if row[37] is not None:
               brandData.update({'brand_modification_date':row[37].encode('utf-8').strip()})    
           else:
               brandData.update({'brand_modification_date':''})
           brandArr.append(brandData.copy())
       brand.update({"brand":brandArr})
       cursor.close()
       return jsonify(brand)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")			


@app.route("/retrieve_brand_details",methods=['POST'])
def retrieveBrandDetails():
    try:
       brandJson = request.get_json()          
       brandData = {}
       brandId = str(brandJson.get('brand_id'))
       brandId = '"{}"'.format(brandId)
       status = "current"
       caseNote1=""
       date1=""
       createdby1=""
       communicationType1=""
       caseNote2=""
       date2=""
       createdby2=""
       communicationType2=""
       caseNote3=""
       date3=""
       createdby3=""
       communicationType3=""
       caseNote4=""
       date4=""
       createdby4=""
       communicationType4=""
        	   
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='dstdb',
                             user='root',
                             password='mysqlCT5!')

       sql_dst = "select * from dailystatustracker where brandId = " + brandId
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_dst) 
       records_dst = cursor.fetchall()
       
       if (cursor.rowcount)-1 >0:
               record1 = records_dst[(cursor.rowcount)-1]
               if record1[8] is not None and record1[8]<>"":
                   caseNote1 = record1[8]    
              
               if record1[1] is not None:
                   date1 = record1[1]
               
               if record1[14] is not None:
                   createdby1 = record1[14]
               
               if record1[9] is not None:
                   communicationType1 = record1[9]
       if (cursor.rowcount)-2 >0:
               record2 = records_dst[(cursor.rowcount)-2]
               if record2[8] is not None and record2[8]<>"":
                   caseNote2 = record2[8]    
              
               if record2[1] is not None:
                   date2 = record2[1]
               
               if record2[14] is not None:
                   createdby2 = record2[14]
               
               if record2[9] is not None:
                   communicationType2 = record2[9]        
       if (cursor.rowcount)-3 >0:
               record3 = records_dst[(cursor.rowcount)-3]
               if record3[8] is not None and record3[8]<>"":
                   caseNote3= record3[8]    
              
               if record3[1] is not None:
                   date3 = record3[1]
               
               if record3[14] is not None:
                   createdby3 = record3[14]
               
               if record3[9] is not None:
                   communicationType3 = record3[9]
       if (cursor.rowcount)-4 >0:
               record4 = records_dst[(cursor.rowcount)-4]
               if record4[8] is not None and record4[8]<>"":
                   caseNote4= record4[8]    
              
               if record4[1] is not None:
                   date4 = record4[1]
               
               if record4[14] is not None:
                   createdby4 = record4[14]
               
               if record4[9] is not None:
                   communicationType4 = record4[9]
          				   
       cursor.close()
       mySQLconnection.close()
          
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='brandmdmdb',
                             user='root',
                             password='mysqlCT5!')
		   
       sql = "select * from brandmdm where brand_id = " + brandId + " and status = 'current'"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:            
               brandData.update({'brand_id':row[0].encode('utf-8').strip()})
           else:
               brandData.update({'brand_id':''})                               
           if row[1] is not None:               
               brandData.update({'brand_name':row[1].encode('utf-8').strip()})
           else:
               brandData.update({'brand_name':''})                                        
           if row[2] is not None:
               brandData.update({'category':row[2].encode('utf-8').strip()})
           else:
               brandData.update({'category':''})
           if row[3] is not None:
               brandData.update({'sub_category':row[3].encode('utf-8').strip()})
           else:
               brandData.update({'sub_category':''})
           if row[4] is not None:
               brandData.update({'team_name':row[4].encode('utf-8').strip()})
           else:
               brandData.update({'team_name':''})
           if row[5] is not None:
               brandData.update({'service_type':row[5].encode('utf-8').strip()})
           else:
               brandData.update({'service_type':''})        
           if row[6] is not None:
               brandData.update({'allocation_date_to_cts':row[6].encode('utf-8').strip()})
           else:
               brandData.update({'allocation_date_to_cts':''})                                   
           if row[7] is not None:
               brandData.update({'access_from_brand_poc':row[7].encode('utf-8').strip()})
           else:
               brandData.update({'access_from_brand_poc':''})                                                 
           if row[8] is not None:
               brandData.update({'changes_incorporation_in_brand':row[8].encode('utf-8').strip()})
           else:
               brandData.update({'changes_incorporation_in_brand':''})
           if row[9] is not None:
               brandData.update({'brand_status':row[9].encode('utf-8').strip()})
           else:
               brandData.update({'brand_status':''})       
           if row[10] is not None:
               brandData.update({'brand_poc_name1':row[10].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name1':''})
           if row[11] is not None:
               brandData.update({'brand_poc_phone1':row[11].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone1':''})
           if row[12] is not None:
               brandData.update({'brand_poc_email1':row[12].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_email1':''})
           if row[13] is not None:
               brandData.update({'brand_poc_name2':row[13].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name2':''})
           if row[14] is not None:
               brandData.update({'brand_poc_phone2':row[14].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone2':''})
           if row[15] is not None:
               brandData.update({'brand_poc_email2':row[15].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_email2':''})
           if row[16] is not None:
               brandData.update({'brand_poc_name3':row[16].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_name3':''})
           if row[17] is not None:
               brandData.update({'brand_poc_phone3':row[17].encode('utf-8').strip()})
           else:
               brandData.update({'brand_poc_phone3':''})
           if row[18] is not None:
               brandData.update({'brand_poc_email3':row[18].encode('utf-8').strip()}) 
           else:
               brandData.update({'brand_poc_email3':''})
           if row[19] is not None:
               brandData.update({'amazon_contact_point_name':row[19].encode('utf-8').strip()})
           else:
               brandData.update({'amazon_contact_point_name':''})
           if row[20] is not None:
               brandData.update({'amazon_contact_point_email_address':row[20].encode('utf-8').strip()})
           else:
               brandData.update({'amazon_contact_point_email_address':''})
           if row[21] is not None:
               brandData.update({'cognizant_contact_point':row[21].encode('utf-8').strip()})
           else:
               brandData.update({'cognizant_contact_point':''})
           if row[22] is not None:
               brandData.update({'created_by':row[22].encode('utf-8').strip()})
           else:
               brandData.update({'created_by':''})
           if row[24] is not None:
               brandData.update({'launch_date':row[24].encode('utf-8').strip()})
           else:
               brandData.update({'launch_date':''})
           if row[25] is not None:
               brandData.update({'removed_date':row[25].encode('utf-8').strip()})
           else:
               brandData.update({'removed_date':''})
           if row[26] is not None:
               brandData.update({'source_channel':row[26].encode('utf-8').strip()})
           else:
               brandData.update({'source_channel':''})
           if row[27] is not None:
               brandData.update({'monthly_budget':row[27].encode('utf-8').strip()})
           else:
               brandData.update({'monthly_budget':''})
           if row[28] is not None:
               brandData.update({'access_given':row[28].encode('utf-8').strip()})
           else:
               brandData.update({'access_given':''})
           if row[29] is not None:
               brandData.update({'invites_received':row[29].encode('utf-8').strip()})
           else:
               brandData.update({'invites_received':''})
           if row[30] is not None:
               brandData.update({'action':row[30].encode('utf-8').strip()})
           else:
               brandData.update({'action':''})
           if row[31] is not None:
               brandData.update({'brand_store':row[31].encode('utf-8').strip()})
           else:
               brandData.update({'brand_store':''})
           if row[32] is not None:
               brandData.update({'parent_brand_name':row[32].encode('utf-8').strip()})
           else:
               brandData.update({'parent_brand_name':''})			   
           if row[33] is not None:
               brandData.update({'number_of_sub_brands':row[33].encode('utf-8').strip()})
           else:
               brandData.update({'number_of_sub_brands':''})
           if row[34] is not None:
               brandData.update({'sub_brand_name':row[34].encode('utf-8').strip()})
           else:
               brandData.update({'sub_brand_name':''})
           if row[35] is not None:
               brandData.update({'reallocation_date':row[35].encode('utf-8').strip()})
           else:
               brandData.update({'reallocation_date':''})
           if row[36] is not None:
               brandData.update({'brand_type':row[36].encode('utf-8').strip()})
           else:
               brandData.update({'brand_type':''})    
           if caseNote1 is not None:
               brandData.update({'case_note1': caseNote1})
           else:
               brandData.update({'case_note1':''})
           if caseNote2 is not None:
               brandData.update({'case_note2': caseNote2})
           else:
               brandData.update({'case_note2':''})
           if caseNote3 is not None:
               brandData.update({'case_note3': caseNote3})
           else:
               brandData.update({'case_note3':''})
           if caseNote4 is not None:
               brandData.update({'case_note4': caseNote4})
           else:
               brandData.update({'case_note4':''})
           if date1 is not None:
               brandData.update({'date1': date1})
           else:
               brandData.update({'date1':''})
           if date2 is not None:
               brandData.update({'date2': date2})
           else:
               brandData.update({'date2':''})
           if date3 is not None:
               brandData.update({'date3': date3})
           else:
               brandData.update({'case_note3':''})
           if date4 is not None:
               brandData.update({'date4': date4})
           else:
               brandData.update({'date4':''})
           if createdby1 is not None:
               brandData.update({'createdby1': createdby1})
           else:
               brandData.update({'createdby1':''})
           if createdby2 is not None:
               brandData.update({'createdby2': createdby2})
           else:
               brandData.update({'createdby2':''})
           if createdby3 is not None:
               brandData.update({'createdby3': createdby3})
           else:
               brandData.update({'createdby3':''})
           if createdby4 is not None:
               brandData.update({'createdby4': createdby4})
           else:
               brandData.update({'createdby4':''})
           if communicationType1 is not None:
               brandData.update({'communicationType1': communicationType1})
           else:
               brandData.update({'communicationType1':''})
           if communicationType2 is not None:
               brandData.update({'communicationType2': communicationType2})
           else:
               brandData.update({'communicationType2':''})
           if communicationType3 is not None:
               brandData.update({'communicationType3': communicationType3})
           else:
               brandData.update({'communicationType3':''})
           if communicationType4 is not None:
               brandData.update({'communicationType4': communicationType4})
           else:
               brandData.update({'communicationType4':''}) 
  			   
       cursor.close()
       return jsonify(brandData)

    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")


@app.route("/insert_into_growth_quality_form",methods=['POST'])
def insertInToGrowthQualityForm():
    try:
        growthQualityFormJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                            database='qualityformdb',
                            user='root',
                            password='mysqlCT5!')

        date = str(growthQualityFormJson.get('date'))
        agent_name = str(growthQualityFormJson.get('agent_name'))
        brand_id = str(growthQualityFormJson.get('brand_id'))
        brand_name = str(growthQualityFormJson.get('brand_name'))
        is_brand_active = str(growthQualityFormJson.get('is_brand_active'))
        no_follow_up_from_agent_on_high_acos = str(growthQualityFormJson.get('no_follow_up_from_agent_on_high_acos'))
        brand_budget_is_under_utilized = str(growthQualityFormJson.get('brand_budget_is_under_utilized'))
        agent_touched_the_account_after_fourteen_days = str(growthQualityFormJson.get('agent_touched_the_account_after_fourteen_days'))
        campaign_managers_does_monthly_budget_alignment =  str(growthQualityFormJson.get('campaign_managers_does_monthly_budget_alignment'))
        account_manager_discuss_important_product_features =  str(growthQualityFormJson.get('account_manager_discuss_important_product_features'))
        agent_to_ensure_pacing_of_budget = str(growthQualityFormJson.get('agent_to_ensure_pacing_of_budget'))
        brand_has_no_active_sponsored_brand_campaign = str(growthQualityFormJson.get('brand_has_no_active_sponsored_brand_campaign'))
        agent_forgot_to_share_wbr_or_mbr = str(growthQualityFormJson.get('agent_forgot_to_share_wbr_or_mbr'))
        agent_forgot_to_share_product_updates_with_brand_poc = str(growthQualityFormJson.get('agent_forgot_to_share_product_updates_with_brand_poc'))
        agent_didnot_address_the_requestors_questions = str(growthQualityFormJson.get('agent_didnot_address_the_requestors_questions'))
        agent_used_informal_language_in_the_email = str(growthQualityFormJson.get('agent_used_informal_language_in_the_email'))
        agent_didnot_use_the_client_template = str(growthQualityFormJson.get('agent_didnot_use_the_client_template'))
        agent_forgot_to_add_attachments_while_responding_on_email = str(growthQualityFormJson.get('agent_forgot_to_add_attachments_while_responding_on_email'))
        agent_to_share_the_proforma_invoice = str(growthQualityFormJson.get('agent_to_share_the_proforma_invoice'))
        agent_didnot_followed_the_out_of_balance_sop = str(growthQualityFormJson.get('agent_didnot_followed_the_out_of_balance_sop'))
        agent_didnot_factor_in_the_advertiser_restrictions = str(growthQualityFormJson.get('agent_didnot_factor_in_the_advertiser_restrictions'))
        agent_used_informal_language_in_email_or_phone = str(growthQualityFormJson.get('agent_used_informal_language_in_email_or_phone'))
        agent_provided_incorrect_information = str(growthQualityFormJson.get('agent_provided_incorrect_information'))
        agent_used_non_reliable_data_source_while_giving_recommendations = str(growthQualityFormJson.get('agent_used_non_reliable_data_source_while_giving_recommendations'))
        agent_to_ensure_all_the_emails_to_be_responded = str(growthQualityFormJson.get('agent_to_ensure_all_the_emails_to_be_responded'))
        agent_followed_the_brand_request = str(growthQualityFormJson.get('agent_followed_the_brand_request'))
        agent_to_share_new_or_existing_campaign_report = str(growthQualityFormJson.get('agent_to_share_new_or_existing_campaign_report'))
        agent_forgot_to_update_comments_in_dst = str(growthQualityFormJson.get('agent_forgot_to_update_comments_in_dst'))
        agent_incorrectly_updated_amazon_mdm_tool = str(growthQualityFormJson.get('agent_incorrectly_updated_amazon_mdm_tool'))
        agent_forgot_to_update_oob_tracker = str(growthQualityFormJson.get('agent_forgot_to_update_oob_tracker'))
        agent_changes_campaign_via_ams_portal_instead_of_drona = str(growthQualityFormJson.get('agent_changes_campaign_via_ams_portal_instead_of_drona'))
		
        sql = """insert into growthqualityform (date,agent_name,brand_id,brand_name,is_brand_active,no_follow_up_from_agent_on_high_acos,brand_budget_is_under_utilized,agent_touched_the_account_after_fourteen_days,campaign_managers_does_monthly_budget_alignment,account_manager_discuss_important_product_features,agent_to_ensure_pacing_of_budget,brand_has_no_active_sponsored_brand_campaign,agent_forgot_to_share_wbr_or_mbr,agent_forgot_to_share_product_updates_with_brand_poc,agent_didnot_address_the_requestors_questions,agent_used_informal_language_in_the_email,agent_didnot_use_the_client_template,agent_forgot_to_add_attachments_while_responding_on_email,agent_to_share_the_proforma_invoice,agent_didnot_followed_the_out_of_balance_sop,agent_didnot_factor_in_the_advertiser_restrictions,agent_used_informal_language_in_email_or_phone,agent_provided_incorrect_information,agent_used_non_reliable_data_source_while_giving_recommendations,agent_to_ensure_all_the_emails_to_be_responded,agent_followed_the_brand_request,agent_to_share_new_or_existing_campaign_report,agent_forgot_to_update_comments_in_dst,agent_incorrectly_updated_amazon_mdm_tool,agent_forgot_to_update_oob_tracker,agent_changes_campaign_via_ams_portal_instead_of_drona) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
       
        val = (date,agent_name,brand_id,brand_name,is_brand_active,no_follow_up_from_agent_on_high_acos,brand_budget_is_under_utilized,agent_touched_the_account_after_fourteen_days,campaign_managers_does_monthly_budget_alignment,account_manager_discuss_important_product_features,agent_to_ensure_pacing_of_budget,brand_has_no_active_sponsored_brand_campaign,agent_forgot_to_share_wbr_or_mbr,agent_forgot_to_share_product_updates_with_brand_poc,agent_didnot_address_the_requestors_questions,agent_used_informal_language_in_the_email,agent_didnot_use_the_client_template,agent_forgot_to_add_attachments_while_responding_on_email,agent_to_share_the_proforma_invoice,agent_didnot_followed_the_out_of_balance_sop,agent_didnot_factor_in_the_advertiser_restrictions,agent_used_informal_language_in_email_or_phone,agent_provided_incorrect_information,agent_used_non_reliable_data_source_while_giving_recommendations,agent_to_ensure_all_the_emails_to_be_responded,agent_followed_the_brand_request,agent_to_share_new_or_existing_campaign_report,agent_forgot_to_update_comments_in_dst,agent_incorrectly_updated_amazon_mdm_tool,agent_forgot_to_update_oob_tracker,agent_changes_campaign_via_ams_portal_instead_of_drona)
       
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
        mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@app.route("/retrieve_growth_quality_form_data",methods=['POST'])
def retrieveGrowthQualityFormData():
    try:
       growthQualityFormJson = request.get_json() 	
       growthQualityForm = OrderedDict()
       growthQualityFormArr = []
       growthQualityFormData = OrderedDict()
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database='qualityformdb',
                            user='root',
                            password='mysqlCT5!')
       

       sql_select_query = "select * from growthqualityform"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:
               growthQualityFormData.update({'Date':row[0].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Date':''})
           if row[1] is not None:
               growthQualityFormData.update({'Agent Name':row[1].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent Name':''})
           if row[2] is not None:
               growthQualityFormData.update({'Brand Id':row[2].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Brand Id':''})
           if row[3] is not None:
               growthQualityFormData.update({'Brand Name':row[3].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Brand Name':''})
           if row[4] is not None:
               growthQualityFormData.update({'Is Brand Active':row[4].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Is Brand Active':''})
           if row[5] is not None:
               growthQualityFormData.update({'Brand ACoS is greater than 3 months average ACoS, and No follow up from Agent on High ACoS':row[5].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Brand ACoS is greater than 3 months average ACoS, and No follow up from Agent on High ACoS':''})
           if row[6] is not None:
               growthQualityFormData.update({'Brand budget is under or over utilized and agent did not make any follow up or modification in the brand campaigns':row[6].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Brand budget is under or over utilized and agent did not make any follow up or modification in the brand campaigns':''})
           if row[7] is not None:
               growthQualityFormData.update({'Agent touched the account after 14 days':row[7].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent touched the account after 14 days':''})
           if row[8] is not None:
               growthQualityFormData.update({'Campaign Managers does monthly budget alignment with Brand POC':row[8].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Campaign Managers does monthly budget alignment with Brand POC':''})
           if row[9] is not None:
               growthQualityFormData.update({'Brand has no active Sponsored Brand Campaign (minimum 1 INR spend per week, in last 4 weeks) ':row[11].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Brand has no active Sponsored Brand Campaign (minimum 1 INR spend per week, in last 4 weeks) ':''})
           if row[10] is not None:
               growthQualityFormData.update({'Agent forgot to share WBR or MBR on periodic basis':row[12].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent forgot to share WBR or MBR on periodic basis':''})
           if row[11] is not None:
               growthQualityFormData.update({'Account manager has to discuss all the important product features with Brands':row[9].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Account manager has to discuss all the important product features with Brands':''})
           if row[12] is not None:
               growthQualityFormData.update({'Agent to ensure the pacing of the budget during the month is as per brand alignment':row[10].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent to ensure the pacing of the budget during the month is as per brand alignment':''})
           if row[13] is not None:
               growthQualityFormData.update({'Agent forgot to share product updates with Brand POC':row[13].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent forgot to share product updates with Brand POC':''})
           if row[14] is not None:
               growthQualityFormData.update({'Agent did not address the requestor explicit and implicit questions or requests':row[14].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent did not address the requestor explicit and implicit questions or requests':''})
           if row[15] is not None:
               growthQualityFormData.update({'Agent used informal or casual language in the email':row[15].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent used informal or casual language in the email':''})
           if row[16] is not None:
               growthQualityFormData.update({'Agent did not use the client or standard template (wherever applicable)':row[16].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent did not use the client or standard template (wherever applicable)':''})
           if row[17] is not None:
               growthQualityFormData.update({'Agent forgot to add attachments while responding on email':row[17].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent forgot to add attachments while responding on email':''})
           if row[18] is not None:
               growthQualityFormData.update({'Agent to share the Proforma invoice':row[18].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent to share the Proforma invoice':''})
           if row[19] is not None:
               growthQualityFormData.update({'Agent did not followed the Out of balance SOP or procedure':row[19].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent did not followed the Out of balance SOP or procedure':''})
           if row[20] is not None:
               growthQualityFormData.update({'Agent did not factor in the advertiser restrictions wherever applicable':row[20].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent did not factor in the advertiser restrictions wherever applicable':''})
           if row[21] is not None:
               growthQualityFormData.update({'Agent used informal or casual language in the email or Phone call':row[21].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent used informal or casual language in the email or Phone call':''})
           if row[22] is not None:
               growthQualityFormData.update({'Agent provided incorrect or misleading information leading to confusion':row[22].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent provided incorrect or misleading information leading to confusion':''})
           if row[23] is not None:
               growthQualityFormData.update({'Agent used non reliable data source while giving recommendations or benchmarks':row[23].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent used non reliable data source while giving recommendations or benchmarks':''})
           if row[24] is not None:
               growthQualityFormData.update({'Agent to ensure all the emails to be responded in 1 business day if a brand is requesting a call back agent to ensure call the brand POC in 1 business day':row[24].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent to ensure all the emails to be responded in 1 business day if a brand is requesting a call back agent to ensure call the brand POC in 1 business day':''})
           if row[25] is not None:
               growthQualityFormData.update({'Agent followed the Optimization or brand request with in 1 business day':row[25].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent followed the Optimization or brand request with in 1 business day':''})
           if row[26] is not None:
               growthQualityFormData.update({'Agent to share new or existing campaign report with Brand POC':row[26].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent to share new or existing campaign report with Brand POC':''})
           if row[27] is not None:
               growthQualityFormData.update({'Agent forgot to Update the comments in DST Tool':row[27].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent forgot to Update the comments in DST Tool':''})
           if row[28] is not None:
               growthQualityFormData.update({'Agent incorrectly or Incomplete update the Amazon Master data management tool':row[28].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent incorrectly or Incomplete update the Amazon Master data management tool':''})
           if row[29] is not None:
               growthQualityFormData.update({'Agent forgot to update the Out of Balance tracker':row[29].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent forgot to update the Out of Balance tracker':''})
           if row[30] is not None:
               growthQualityFormData.update({'Agent incorporate the changes in campaign via AMS portal instead of Drona Tool':row[30].encode('utf-8').strip()})
           else:
               growthQualityFormData.update({'Agent incorporate the changes in campaign via AMS portal instead of Drona Tool':''})
           growthQualityFormArr.append(growthQualityFormData.copy())
       growthQualityForm.update({"data":growthQualityFormArr})
	   
       cursor.close()
       #return jsonify(growthQualityForm)
       return json.dumps(growthQualityForm)
       
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		           	
			
@app.route("/insert_into_oobtracker", methods=['POST'])
def insertIntoOobTracker():
    try:
        oobJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                             database='oobdb',
                             user='root',
                             password='mysqlCT5!')
        
        for obj in oobJson:
            date = str(obj.get('date').encode('utf-8').strip())
            brand_id = str(obj.get('brand_id').encode('utf-8').strip())
            brand_name = str(obj.get('brand_name').encode('utf-8').strip())
            balance = str(obj.get('balance').encode('utf-8').strip())
            account_manager_cts = str(obj.get('account_manager_cts').encode('utf-8').strip())
            fourteen_days_spend = str(obj.get('fourteen_days_spend'))
            unique_days_perform = str(obj.get('unique_days_perform'))
            daily_spend_history = str(obj.get('daily_spend_history'))
            seven_days_exp_from_history = str(obj.get('seven_days_exp_from_history'))
            fourteen_days_exp_from_history = str(obj.get('fourteen_days_exp_from_history'))
            curent_oob_status = str(obj.get('curent_oob_status'))
            oob_in_seven_days = str(obj.get('oob_in_seven_days'))
            oob_in_fourteen_days = str(obj.get('oob_in_fourteen_days'))			
            automated_nudges_for_14_day_notice_of_oob = ""
            phone_calling_for_7_day_notice_of_oob_brands = ""
            phone_calling_for_3_day_notice_of_oob_brands = ""
            phone_calling_for_currently_oob = ""
            follow_up_call_with_brand_after_7_days_of_inactive = ""
            follow_up_call_with_brand_after_14_days_of_inactive = ""
            send_the_inactive_blurb_call_post_30_days_inactivity = ""
            add_brand_to_removal_list_if_no_response = ""
            issue_category = ""
            comments = ""
            follow_up_date = ""
            first_time_current_oob_date = ""
            oob_cycle_start_date = ""			
            status = "current"
			
            sql = """select automated_nudges_for_14_day_notice_of_oob, phone_calling_for_7_day_notice_of_oob_brands, phone_calling_for_3_day_notice_of_oob_brands, phone_calling_for_currently_oob, follow_up_call_with_brand_after_7_days_of_inactive, follow_up_call_with_brand_after_14_days_of_inactive, send_the_inactive_blurb_call_post_30_days_inactivity, add_brand_to_removal_list_if_no_response, issue_category, comments, follow_up_date, first_time_current_oob_date, oob_cycle_start_date from oobtracker where brand_id = %s and status = %s"""
            val = (brand_id, "current")
            cursor = mySQLconnection .cursor()
            cursor.execute(sql, val)
            records = cursor.fetchall()
			
            for row in records: 
                automated_nudges_for_14_day_notice_of_oob = str(row[0].encode('utf-8').strip())
                phone_calling_for_7_day_notice_of_oob_brands = str(row[1].encode('utf-8').strip())
                phone_calling_for_3_day_notice_of_oob_brands = str(row[2].encode('utf-8').strip())
                phone_calling_for_currently_oob = str(row[3].encode('utf-8').strip())
                follow_up_call_with_brand_after_7_days_of_inactive = str(row[4].encode('utf-8').strip())
                follow_up_call_with_brand_after_14_days_of_inactive = str(row[5].encode('utf-8').strip())
                send_the_inactive_blurb_call_post_30_days_inactivity = str(row[6].encode('utf-8').strip())
                add_brand_to_removal_list_if_no_response = str(row[7].encode('utf-8').strip())
                issue_category = str(row[8].encode('utf-8').strip())
                comments = str(row[9].encode('utf-8').strip())
                follow_up_date = str(row[10].encode('utf-8').strip())
                first_time_current_oob_date = str(row[11].encode('utf-8').strip())
                oob_cycle_start_date = str(row[12])
				
            sql = "update oobtracker SET status = %s where brand_id = %s and status = %s" 
            val = ("history", brand_id, "current")	 
            cursor = mySQLconnection.cursor()
            cursor.execute(sql,val)
              
            if curent_oob_status == "Yes" and first_time_current_oob_date == "":
                first_time_current_oob_date = date
            elif curent_oob_status == "No":
                first_time_current_oob_date = ""
            
            if curent_oob_status == "Yes" or oob_in_seven_days == "Yes" or oob_in_fourteen_days == "Yes" and oob_cycle_start_date == "":
                oob_cycle_start_date = date
            elif curent_oob_status == "Yes" or oob_in_seven_days == "Yes" or oob_in_fourteen_days == "Yes" and oob_cycle_start_date != "":
                oob_cycle_start_date = oob_cycle_start_date
            else:	
                oob_cycle_start_date = ""	
				
            	
            sql = """insert into oobtracker(date, brand_id, brand_name, balance, fourteen_days_spend, unique_days_perform, daily_spend_history, seven_days_exp_from_history, fourteen_days_exp_from_history, curent_oob_status, oob_in_seven_days, oob_in_fourteen_days, automated_nudges_for_14_day_notice_of_oob, phone_calling_for_7_day_notice_of_oob_brands, phone_calling_for_3_day_notice_of_oob_brands, phone_calling_for_currently_oob, follow_up_call_with_brand_after_7_days_of_inactive, follow_up_call_with_brand_after_14_days_of_inactive, send_the_inactive_blurb_call_post_30_days_inactivity, add_brand_to_removal_list_if_no_response, issue_category, comments, follow_up_date, first_time_current_oob_date, status, account_manager_cts, oob_cycle_start_date) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"""
      
            val = (date, brand_id, brand_name, balance, fourteen_days_spend, unique_days_perform, daily_spend_history, seven_days_exp_from_history, fourteen_days_exp_from_history, curent_oob_status, oob_in_seven_days, oob_in_fourteen_days, automated_nudges_for_14_day_notice_of_oob, phone_calling_for_7_day_notice_of_oob_brands, phone_calling_for_3_day_notice_of_oob_brands, phone_calling_for_currently_oob, follow_up_call_with_brand_after_7_days_of_inactive, follow_up_call_with_brand_after_14_days_of_inactive, send_the_inactive_blurb_call_post_30_days_inactivity, add_brand_to_removal_list_if_no_response, issue_category, comments, follow_up_date, first_time_current_oob_date, status, account_manager_cts, oob_cycle_start_date)
       
            cursor = mySQLconnection.cursor()
            cursor.execute(sql,val)
            mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")


@app.route("/update_oobtracker", methods=['POST'])
def updateOobTracker():
    try:
        oobJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                             database='oobdb',
                             user='root',
                             password='mysqlCT5!')
        
        for obj in oobJson:
            date = str(obj.get('date').encode('utf-8').strip())
            brand_id = str(obj.get('brand_id').encode('utf-8').strip())
            brand_name = str(obj.get('brand_name').encode('utf-8').strip())
            balance = str(obj.get('balance').encode('utf-8').strip())
            account_manager_cts = str(obj.get('account_manager_cts').encode('utf-8').strip())
            automated_nudges_for_14_day_notice_of_oob =str(obj.get('automated_nudges_for_14_day_notice_of_oob').encode('utf-8').strip())
            phone_calling_for_7_day_notice_of_oob_brands = str(obj.get('phone_calling_for_7_day_notice_of_oob_brands').encode('utf-8').strip())
            phone_calling_for_3_day_notice_of_oob_brands = str(obj.get('phone_calling_for_3_day_notice_of_oob_brands').encode('utf-8').strip())
            phone_calling_for_currently_oob = str(obj.get('phone_calling_for_currently_oob').encode('utf-8').strip())
            follow_up_call_with_brand_after_7_days_of_inactive = str(obj.get('follow_up_call_with_brand_after_7_days_of_inactive').encode('utf-8').strip())
            follow_up_call_with_brand_after_14_days_of_inactive = str(obj.get('follow_up_call_with_brand_after_14_days_of_inactive').encode('utf-8').strip())
            send_the_inactive_blurb_call_post_30_days_inactivity = str(obj.get('send_the_inactive_blurb_call_post_30_days_inactivity').encode('utf-8').strip())
            add_brand_to_removal_list_if_no_response = str(obj.get('add_brand_to_removal_list_if_no_response').encode('utf-8').strip())
            issue_category = str(obj.get('issue_category').encode('utf-8').strip())
            comments = str(obj.get('comments').encode('utf-8').strip())
            follow_up_date = str(obj.get('follow_up_date').encode('utf-8').strip())
        		
            if issue_category == "Recharged":
                sql = "update oobtracker SET status = %s, issue_category = %s where brand_id = %s and status = %s" 
                val = ("history", issue_category, brand_id, "current")			
                cursor = mySQLconnection.cursor()
                cursor.execute(sql,val)
                mySQLconnection.commit()
                cursor.close()		
            else:
                sql = """update oobtracker SET date = %s, brand_id = %s, brand_name = %s, balance = %s, automated_nudges_for_14_day_notice_of_oob = %s, phone_calling_for_7_day_notice_of_oob_brands = %s, phone_calling_for_3_day_notice_of_oob_brands = %s, phone_calling_for_currently_oob = %s, follow_up_call_with_brand_after_7_days_of_inactive = %s, follow_up_call_with_brand_after_14_days_of_inactive = %s, send_the_inactive_blurb_call_post_30_days_inactivity = %s, add_brand_to_removal_list_if_no_response = %s, issue_category = %s, comments = %s, follow_up_date = %s, account_manager_cts = %s where brand_id = %s and date = %s""" 
                val = (date, brand_id, brand_name, balance, automated_nudges_for_14_day_notice_of_oob, phone_calling_for_7_day_notice_of_oob_brands, phone_calling_for_3_day_notice_of_oob_brands, phone_calling_for_currently_oob, follow_up_call_with_brand_after_7_days_of_inactive, follow_up_call_with_brand_after_14_days_of_inactive, send_the_inactive_blurb_call_post_30_days_inactivity, add_brand_to_removal_list_if_no_response, issue_category, comments, follow_up_date, account_manager_cts, brand_id, date)
                cursor = mySQLconnection.cursor()
                cursor.execute(sql,val)
                mySQLconnection.commit()
                cursor.close()		 			
                
        return 'success'

    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

			
@app.route("/retrieve_from_oobtracker", methods=['POST'])
def retrieveFromOobTracker():
    try:
        oobTracker = OrderedDict()
        oobTrackerArr = []
        oobTrackerData = OrderedDict() 
        mySQLconnection = mysql.connector.connect(host='localhost',
                             database='oobdb',
                             user='root',
                             password='mysqlCT5!')
       
        sql = """select * from oobtracker where curent_oob_status = 'Yes' or oob_in_seven_days = 'Yes' or oob_in_fourteen_days = 'Yes' having status = 'current'"""
        cursor = mySQLconnection .cursor()
        cursor.execute(sql)
        records = cursor.fetchall()
        for row in records:
            if row[0] is not None:
                oobTrackerData.update({'date':row[0].encode('utf-8').strip()})
            if row[1] is not None:	      
                oobTrackerData.update({'brand_id':row[1].encode('utf-8').strip()})
            if row[2] is not None:
                oobTrackerData.update({'brand_name':row[2].encode('utf-8').strip()})
            if row[3] is not None:
                oobTrackerData.update({'balance':row[3].encode('utf-8').strip()})
            if row[4] is not None:
                oobTrackerData.update({'automated_nudges_for_14_day_notice_of_oob':row[4].encode('utf-8').strip()})
            if row[5] is not None:
                oobTrackerData.update({'phone_calling_for_7_day_notice_of_oob_brands':row[5].encode('utf-8').strip()})
            if row[6] is not None:
                oobTrackerData.update({'phone_calling_for_3_day_notice_of_oob_brands':row[6].encode('utf-8').strip()})
            if row[7] is not None:
                oobTrackerData.update({'phone_calling_for_currently_oob':row[7].encode('utf-8').strip()})
            if row[8] is not None:
                oobTrackerData.update({'follow_up_call_with_brand_after_7_days_of_inactive':row[8].encode('utf-8').strip()})
            if row[9] is not None:
                oobTrackerData.update({'follow_up_call_with_brand_after_14_days_of_inactive':row[9].encode('utf-8').strip()})
            if row[10] is not None:
                oobTrackerData.update({'send_the_inactive_blurb_call_post_30_days_inactivity':row[10].encode('utf-8').strip()})
            if row[11] is not None:
                oobTrackerData.update({'add_brand_to_removal_list_if_no_response':row[11].encode('utf-8').strip()})
            if row[12] is not None:
                oobTrackerData.update({'issue_category':row[12].encode('utf-8').strip()})
            if row[13] is not None:
                oobTrackerData.update({'comments':row[13].encode('utf-8').strip()})
            if row[14] is not None:
                oobTrackerData.update({'follow_up_date':row[14].encode('utf-8').strip()})
            if row[16] is not None:
                oobTrackerData.update({'fourteen_days_spend':row[16].encode('utf-8').strip()})
            if row[17] is not None:
                oobTrackerData.update({'unique_days_perform':row[17].encode('utf-8').strip()})	
            if row[18] is not None:
                oobTrackerData.update({'daily_spend_history':row[18].encode('utf-8').strip()})
            if row[19] is not None:
                oobTrackerData.update({'seven_days_exp_from_history':row[19].encode('utf-8').strip()})
            if row[20] is not None:
                oobTrackerData.update({'fourteen_days_exp_from_history':row[20].encode('utf-8').strip()})
            if row[21] is not None:
                oobTrackerData.update({'curent_oob_status':row[21].encode('utf-8').strip()})
            if row[22] is not None:
                oobTrackerData.update({'oob_in_seven_days':row[22].encode('utf-8').strip()})
            if row[23] is not None:
                oobTrackerData.update({'oob_in_fourteen_days':row[23].encode('utf-8').strip()})	
            if row[24] is not None:
                oobTrackerData.update({'first_time_current_oob_date':row[24].encode('utf-8').strip()})
            if row[25] is not None:
                oobTrackerData.update({'account_manager_cts':row[25].encode('utf-8').strip()})
            if row[26] is not None:
                oobTrackerData.update({'oob_cycle_start_date':row[26].encode('utf-8').strip()})				
            oobTrackerArr.append(oobTrackerData.copy())
        cursor.close()
        return json.dumps(oobTrackerArr)

    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")	

@app.route("/retrieve_oobtracker_history", methods=['POST'])
def retrieveOobTrackerHistory():
    try:
        oobDateJson = request.get_json()
        date = str(oobDateJson.get('filterDate'))
        date = '"{}"'.format(date)
        oobTracker = OrderedDict()
        oobTrackerArr = []
        oobTrackerData = OrderedDict() 
        mySQLconnection = mysql.connector.connect(host='localhost',
                             database='oobdb',
                             user='root',
                             password='mysqlCT5!')
       
        sql = "select * from oobtracker where curent_oob_status = 'Yes' or oob_in_seven_days = 'Yes' or oob_in_fourteen_days = 'Yes' having date = " + date
        cursor = mySQLconnection .cursor()
        cursor.execute(sql)
        records = cursor.fetchall() 		
        for row in records:
            if row[0] is not None:
                oobTrackerData.update({'date':row[0].encode('utf-8').strip()})
            if row[1] is not None:	      
                oobTrackerData.update({'brand_id':row[1].encode('utf-8').strip()})
            if row[2] is not None:
                oobTrackerData.update({'brand_name':row[2].encode('utf-8').strip()})
            if row[3] is not None:
                oobTrackerData.update({'balance':row[3].encode('utf-8').strip()})
            if row[4] is not None:
                oobTrackerData.update({'automated_nudges_for_14_day_notice_of_oob':row[4].encode('utf-8').strip()})
            if row[5] is not None:
                oobTrackerData.update({'phone_calling_for_7_day_notice_of_oob_brands':row[5].encode('utf-8').strip()})
            if row[6] is not None:
                oobTrackerData.update({'phone_calling_for_3_day_notice_of_oob_brands':row[6].encode('utf-8').strip()})
            if row[7] is not None:
                oobTrackerData.update({'phone_calling_for_currently_oob':row[7].encode('utf-8').strip()})
            if row[8] is not None:
                oobTrackerData.update({'follow_up_call_with_brand_after_7_days_of_inactive':row[8].encode('utf-8').strip()})
            if row[9] is not None:
                oobTrackerData.update({'follow_up_call_with_brand_after_14_days_of_inactive':row[9].encode('utf-8').strip()})
            if row[10] is not None:
                oobTrackerData.update({'send_the_inactive_blurb_call_post_30_days_inactivity':row[10].encode('utf-8').strip()})
            if row[11] is not None:
                oobTrackerData.update({'add_brand_to_removal_list_if_no_response':row[11].encode('utf-8').strip()})
            if row[12] is not None:
                oobTrackerData.update({'issue_category':row[12].encode('utf-8').strip()})
            if row[13] is not None:
                oobTrackerData.update({'comments':row[13].encode('utf-8').strip()})
            if row[14] is not None:
                oobTrackerData.update({'follow_up_date':row[14].encode('utf-8').strip()})
            if row[16] is not None:
                oobTrackerData.update({'fourteen_days_spend':row[16].encode('utf-8').strip()})
            if row[17] is not None:
                oobTrackerData.update({'unique_days_perform':row[17].encode('utf-8').strip()})	
            if row[18] is not None:
                oobTrackerData.update({'daily_spend_history':row[18].encode('utf-8').strip()})
            if row[19] is not None:
                oobTrackerData.update({'seven_days_exp_from_history':row[19].encode('utf-8').strip()})
            if row[20] is not None:
                oobTrackerData.update({'fourteen_days_exp_from_history':row[20].encode('utf-8').strip()})
            if row[21] is not None:
                oobTrackerData.update({'curent_oob_status':row[21].encode('utf-8').strip()})
            if row[22] is not None:
                oobTrackerData.update({'oob_in_seven_days':row[22].encode('utf-8').strip()})
            if row[23] is not None:
                oobTrackerData.update({'oob_in_fourteen_days':row[23].encode('utf-8').strip()})	
            if row[24] is not None:
                oobTrackerData.update({'first_time_current_oob_date':row[24].encode('utf-8').strip()})
            if row[25] is not None:
                oobTrackerData.update({'account_manager_cts':row[25].encode('utf-8').strip()})
            if row[26] is not None:
                oobTrackerData.update({'oob_cycle_start_date':row[26].encode('utf-8').strip()})				
            oobTrackerArr.append(oobTrackerData.copy())
        cursor.close()
        return json.dumps(oobTrackerArr)

    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")	

#Update OOB Tracker database table when a brand is removed from MDM
def UpdateBrandStatusofOOBTracker(brandId):
    try:
       brandId = '"{}"'.format(brandId)
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='oobdb',
                             user='root',
                             password='mysqlCT5!')

       sql = "update oobtracker set status = 'history' where brand_id = " + brandId
       cursor = mySQLconnection.cursor()
       cursor.execute(sql)
       mySQLconnection.commit()
       cursor.close()
       return 'success'
           
    except Exception as e :
        print ("Error while updating brand status",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")   

@app.route("/insertinto_brand_store_tracker",methods=['POST'])
def insertIntoBrandStoreTracker():
    try:
        brandStoreJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                             database='bstdb',
                             user='root',
                             password='mysqlCT5!')

        brand_id = str(brandStoreJson.get('brand_id')) 
        brand_name = str(brandStoreJson.get('brand_name')) 
        cts_poc = str(brandStoreJson.get('cts_poc')) 
        ams_poc = str(brandStoreJson.get('ams_poc'))
        source_channel = str(brandStoreJson.get('source_channel'))
        brand_contact_name1 = str(brandStoreJson.get('brand_contact_name1'))
        brand_contact_number1 = str(brandStoreJson.get('brand_contact_number1'))
        brand_email_id1 = str(brandStoreJson.get('brand_email_id1'))
        brand_contact_name2 = str(brandStoreJson.get('brand_contact_name2')) 
        brand_contact_number2 = str(brandStoreJson.get('brand_contact_number2')) 
        brand_email_id2 = str(brandStoreJson.get('brand_email_id2')) 
        brand_contact_name3 = str(brandStoreJson.get('brand_contact_name3')) 
        brand_contact_number3 = str(brandStoreJson.get('brand_contact_number3')) 
        brand_email_id3 = str(brandStoreJson.get('brand_email_id3')) 
        pitch_date1_proposed_date = str(brandStoreJson.get('pitch_date1_proposed_date')) 
        pitch_date1_proposed_time = str(brandStoreJson.get('pitch_date1_proposed_time')) 
        pitch_date1_actual_date = str(brandStoreJson.get('pitch_date1_actual_date')) 
        pitch_date1_sub_issue = str(brandStoreJson.get('pitch_date1_sub_issue')) 
        pitch_date2_proposed_date = str(brandStoreJson.get('pitch_date2_proposed_date')) 
        pitch_date2_proposed_time = str(brandStoreJson.get('pitch_date2_proposed_time')) 
        pitch_date2_actual_date = str(brandStoreJson.get('pitch_date2_actual_date')) 
        pitch_date2_sub_issue = str(brandStoreJson.get('pitch_date2_sub_issue')) 
        training_date1_proposed_date = str(brandStoreJson.get('training_date1_proposed_date')) 
        training_date1_proposed_time = str(brandStoreJson.get('training_date1_proposed_time')) 
        training_date1_actual_date = str(brandStoreJson.get('training_date1_actual_date')) 
        training_date1_sub_issue = str(brandStoreJson.get('training_date1_sub_issue')) 
        training_date2_proposed_date = str(brandStoreJson.get('training_date2_proposed_date')) 
        training_date2_proposed_time = str(brandStoreJson.get('training_date2_proposed_time')) 
        training_date2_actual_date = str(brandStoreJson.get('training_date2_actual_date')) 
        training_date2_sub_issue = str(brandStoreJson.get('training_date2_sub_issue')) 
        training_date3_proposed_date = str(brandStoreJson.get('training_date3_proposed_date')) 
        training_date3_proposed_time = str(brandStoreJson.get('training_date3_proposed_time')) 
        training_date3_actual_date = str(brandStoreJson.get('training_date3_actual_date')) 
        training_date3_sub_issue = str(brandStoreJson.get('training_date3_sub_issue')) 
        training_date4_proposed_date = str(brandStoreJson.get('training_date4_proposed_date')) 
        training_date4_proposed_time = str(brandStoreJson.get('training_date4_proposed_time')) 
        training_date4_actual_date = str(brandStoreJson.get('training_date4_actual_date')) 
        training_date4_sub_issue = str(brandStoreJson.get('training_date4_sub_issue')) 
        training_date5_proposed_date = str(brandStoreJson.get('training_date5_proposed_date')) 
        training_date5_proposed_time = str(brandStoreJson.get('training_date5_proposed_time')) 
        training_date5_actual_date = str(brandStoreJson.get('training_date5_actual_date')) 
        training_date5_sub_issue = str(brandStoreJson.get('training_date5_sub_issue')) 
        brand_store_submission_date = str(brandStoreJson.get('brand_store_submission_date')) 
        brand_store_approval_date = str(brandStoreJson.get('brand_store_approval_date')) 
        store_status = str(brandStoreJson.get('store_status'))  
        additional_issue_sub_issue = str(brandStoreJson.get('additional_issue_sub_issue'))
        summary = str(brandStoreJson.get('summary')) 
        status = "current"         
        associate_name = str(brandStoreJson.get('cts_poc'))
        date = str(brandStoreJson.get('date'))
        pitch_date1_remarks = str(brandStoreJson.get('pitch_date1_remarks'))
        pitch_date2_remarks = str(brandStoreJson.get('pitch_date2_remarks'))
        training_date1_remarks = str(brandStoreJson.get('training_date1_remarks'))
        training_date2_remarks = str(brandStoreJson.get('training_date2_remarks'))
        training_date3_remarks = str(brandStoreJson.get('training_date3_remarks'))
        training_date4_remarks = str(brandStoreJson.get('training_date4_remarks'))
        training_date5_remarks = str(brandStoreJson.get('training_date5_remarks'))
        contacted_date = str(brandStoreJson.get('contacted_date'))
        contacted_time = str(brandStoreJson.get('contacted_time'))
        request_type = str(brandStoreJson.get('request_type'))
        query_status = str(brandStoreJson.get('query_status'))
        query_remarks = str(brandStoreJson.get('query_remarks'))
        	   
        sql = "update brandstoretracker SET status = %s where brand_id = %s and status = %s" 
        val = ("history", brand_id, "current")	 
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
       
        sql = """insert into brandstoretracker (brand_id,brand_name,cts_poc,ams_poc,source_channel,brand_contact_name1,brand_contact_number1,brand_email_id1,brand_contact_name2,brand_contact_number2,brand_email_id2,brand_contact_name3,brand_contact_number3,brand_email_id3,pitch_date1_proposed_date,pitch_date1_proposed_time,pitch_date1_actual_date,pitch_date1_sub_issue,pitch_date2_proposed_date,pitch_date2_proposed_time,pitch_date2_actual_date,pitch_date2_sub_issue,training_date1_proposed_date,training_date1_proposed_time,training_date1_actual_date,training_date1_sub_issue,training_date2_proposed_date,training_date2_proposed_time,training_date2_actual_date,training_date2_sub_issue,training_date3_proposed_date,training_date3_proposed_time,training_date3_actual_date,training_date3_sub_issue,training_date4_proposed_date,training_date4_proposed_time,training_date4_actual_date,training_date4_sub_issue,training_date5_proposed_date,training_date5_proposed_time,training_date5_actual_date,training_date5_sub_issue,brand_store_submission_date,brand_store_approval_date,store_status,additional_issue_sub_issue,summary,associate_name,status,date,pitch_date1_remarks,pitch_date2_remarks,training_date1_remarks,training_date2_remarks,training_date3_remarks,training_date4_remarks,training_date5_remarks,contacted_date,contacted_time,request_type,query_status,query_remarks) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        
        val = (brand_id,brand_name,cts_poc,ams_poc,source_channel,brand_contact_name1,brand_contact_number1,brand_email_id1,brand_contact_name2,brand_contact_number2,brand_email_id2,brand_contact_name3,brand_contact_number3,brand_email_id3,pitch_date1_proposed_date,pitch_date1_proposed_time,pitch_date1_actual_date,pitch_date1_sub_issue,pitch_date2_proposed_date,pitch_date2_proposed_time,pitch_date2_actual_date,pitch_date2_sub_issue,training_date1_proposed_date,training_date1_proposed_time,training_date1_actual_date,training_date1_sub_issue,training_date2_proposed_date,training_date2_proposed_time,training_date2_actual_date,training_date2_sub_issue,training_date3_proposed_date,training_date3_proposed_time,training_date3_actual_date,training_date3_sub_issue,training_date4_proposed_date,training_date4_proposed_time,training_date4_actual_date,training_date4_sub_issue,training_date5_proposed_date,training_date5_proposed_time,training_date5_actual_date,training_date5_sub_issue,brand_store_submission_date,brand_store_approval_date,store_status,additional_issue_sub_issue,summary,associate_name,status,date,pitch_date1_remarks,pitch_date2_remarks,training_date1_remarks,training_date2_remarks,training_date3_remarks,training_date4_remarks,training_date5_remarks,contacted_date,contacted_time,request_type,query_status,query_remarks)	
       	   
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
        mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")
            
@app.route("/check_brand_strore_tracker_for_duplicate",methods=['POST'])
def checkBrandStoreDataForDuplicate():
    try:
       brandJson = request.get_json()	
       brandData = {}
       brandId = str(brandJson.get('brand_id').encode('utf-8').strip())
       status = "current"
       duplicate = "" 
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='bstdb',
                             user='root',
                             password='mysqlCT5!')

       sql = "select * from brandstoretracker where brand_id = %s and status = %s"
       val = (brandId, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql, val)
       records = cursor.fetchall()
       if(len(records) > 0):
           duplicate = "Brand already exists. Please modify the same!!"
       cursor.close()    
       return duplicate
           
    except Exception as e :
        print ("Error while checking brand details",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")              

@app.route("/retrieve_brand_store_tracker", methods = ['POST'])
def retrieveBrandStoreTrackerData():
    try:
       filterJson = request.get_json()	
       bstData = {}
       brandId = str(filterJson.get('brand_id'))
       status = "current"
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='bstdb',
                             user='root',
                             password='mysqlCT5!')
       
       sql_select_query = "select * from brandstoretracker where brand_id = %s and status = %s" 
       val = (brandId, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query, val)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:
               bstData.update({'brand_id':row[0].encode('utf-8').strip()})
           if row[1] is not None:  
               bstData.update({'brand_name':row[1].encode('utf-8').strip()})
           if row[2] is not None:
               bstData.update({'cts_poc':row[2].encode('utf-8').strip()})
           if row[3] is not None:
               bstData.update({'ams_poc':row[3].encode('utf-8').strip()})
           if row[4] is not None:
               bstData.update({'source_channel':row[4].encode('utf-8').strip()})
           if row[5] is not None:
               bstData.update({'brand_contact_name1':row[5].encode('utf-8').strip()})
           if row[6] is not None:
               bstData.update({'brand_contact_number1':row[6].encode('utf-8').strip()})
           if row[7] is not None:
               bstData.update({'brand_email_id1':row[7].encode('utf-8').strip()})
           if row[8] is not None:
               bstData.update({'brand_contact_name2':row[8].encode('utf-8').strip()})
           if row[9] is not None:
               bstData.update({'brand_contact_number2':row[9].encode('utf-8').strip()})
           if row[10] is not None:
               bstData.update({'brand_email_id2':row[10].encode('utf-8').strip()})
           if row[11] is not None:
               bstData.update({'brand_contact_name3':row[11].encode('utf-8').strip()})
           if row[12] is not None:
               bstData.update({'brand_contact_number3':row[12].encode('utf-8').strip()})
           if row[13] is not None:
               bstData.update({'brand_email_id3':row[13].encode('utf-8').strip()})
           if row[14] is not None:
               bstData.update({'pitch_date1_proposed_date':row[14].encode('utf-8').strip()})
           if row[15] is not None:
               bstData.update({'pitch_date1_proposed_time':row[15].encode('utf-8').strip()})
           if row[16] is not None:
               bstData.update({'pitch_date1_actual_date':row[16].encode('utf-8').strip()})
           if row[17] is not None:
               bstData.update({'pitch_date1_sub_issue':row[17].encode('utf-8').strip()})
           if row[18] is not None:
               bstData.update({'pitch_date2_proposed_date':row[18].encode('utf-8').strip()})
           if row[19] is not None:
               bstData.update({'pitch_date2_proposed_time':row[19].encode('utf-8').strip()})
           if row[20] is not None:
               bstData.update({'pitch_date2_actual_date':row[20].encode('utf-8').strip()})
           if row[21] is not None:
               bstData.update({'pitch_date2_sub_issue':row[21].encode('utf-8').strip()})
           if row[22] is not None:
               bstData.update({'training_date1_proposed_date':row[22].encode('utf-8').strip()})
           if row[23] is not None:
               bstData.update({'training_date1_proposed_time':row[23].encode('utf-8').strip()})
           if row[24] is not None:
               bstData.update({'training_date1_actual_date':row[24].encode('utf-8').strip()})
           if row[25] is not None:
               bstData.update({'training_date1_sub_issue':row[25].encode('utf-8').strip()})
           if row[26] is not None:
               bstData.update({'training_date2_proposed_date':row[26].encode('utf-8').strip()})
           if row[27] is not None:
               bstData.update({'training_date2_proposed_time':row[27].encode('utf-8').strip()})
           if row[28] is not None:
               bstData.update({'training_date2_actual_date':row[28].encode('utf-8').strip()})
           if row[29] is not None:
               bstData.update({'training_date2_sub_issue':row[29].encode('utf-8').strip()})
           if row[30] is not None:
               bstData.update({'training_date3_proposed_date':row[30].encode('utf-8').strip()})
           if row[31] is not None:
               bstData.update({'training_date3_proposed_time':row[31].encode('utf-8').strip()})
           if row[32] is not None:
               bstData.update({'training_date3_actual_date':row[32].encode('utf-8').strip()})
           if row[33] is not None:
               bstData.update({'training_date3_sub_issue':row[33].encode('utf-8').strip()})
           if row[34] is not None:
               bstData.update({'training_date4_proposed_date':row[34].encode('utf-8').strip()})
           if row[35] is not None:
               bstData.update({'training_date4_proposed_time':row[35].encode('utf-8').strip()})
           if row[36] is not None:
               bstData.update({'training_date4_actual_date':row[36].encode('utf-8').strip()})
           if row[37] is not None:
               bstData.update({'training_date4_sub_issue':row[37].encode('utf-8').strip()})
           if row[38] is not None:
               bstData.update({'training_date5_proposed_date':row[38].encode('utf-8').strip()})
           if row[39] is not None:
               bstData.update({'training_date5_proposed_time':row[39].encode('utf-8').strip()})
           if row[40] is not None:
               bstData.update({'training_date5_actual_date':row[40].encode('utf-8').strip()})
           if row[41] is not None:
               bstData.update({'training_date5_sub_issue':row[41].encode('utf-8').strip()})
           if row[42] is not None:
               bstData.update({'brand_store_submission_date':row[42].encode('utf-8').strip()})
           if row[43] is not None:
               bstData.update({'brand_store_approval_date':row[43].encode('utf-8').strip()})
           if row[44] is not None:
               bstData.update({'store_status':row[44].encode('utf-8').strip()})        
           if row[45] is not None:
               bstData.update({'additional_issue_sub_issue':row[45].encode('utf-8').strip()})
           if row[46] is not None:
               bstData.update({'summary':row[46].encode('utf-8').strip()})                
           if row[47] is not None:
               bstData.update({'associate_name':row[47].encode('utf-8').strip()})
           if row[50] is not None:
               bstData.update({'pitch_date1_remarks':row[50].encode('utf-8').strip()})
           if row[51] is not None:
               bstData.update({'pitch_date2_remarks':row[51].encode('utf-8').strip()})
           if row[52] is not None:
               bstData.update({'training_date1_remarks':row[52].encode('utf-8').strip()})
           if row[53] is not None:
               bstData.update({'training_date2_remarks':row[53].encode('utf-8').strip()})
           if row[54] is not None:
               bstData.update({'training_date3_remarks':row[54].encode('utf-8').strip()})
           if row[55] is not None:
               bstData.update({'training_date4_remarks':row[55].encode('utf-8').strip()})
           if row[56] is not None:
               bstData.update({'training_date5_remarks':row[56].encode('utf-8').strip()})
           if row[57] is not None:
               bstData.update({'contacted_date':row[57].encode('utf-8').strip()})
           if row[58] is not None:
               bstData.update({'contacted_time':row[58].encode('utf-8').strip()})
           if row[59] is not None:
               bstData.update({'request_type':row[59].encode('utf-8').strip()})
           if row[60] is not None:
               bstData.update({'query_status':row[60].encode('utf-8').strip()})
           if row[61] is not None:
               bstData.update({'query_remarks':row[61].encode('utf-8').strip()})		   
                                   
       cursor.close()
       return jsonify(bstData)
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

def changeDateFormat(dateStr):
    date_str = dateStr
    format_str = '%Y-%m-%d'
    datetime_obj = datetime.datetime.strptime(date_str, format_str)
    return datetime_obj
    
@app.route("/retrieve_brand_store_tracker_report", methods = ['POST'])
def retrieve_brand_store_tracker_report():
    try:
       filterJson = request.get_json()	
       bst = {}
       bstArr = []
       bstData = {}
       filterCategory = str(filterJson.get('filterCategory'))
       value = str(filterJson.get('filterValue'))
       filterValue = '"{}"'.format(value)  
       filterFromDate = str(filterJson.get('filterFromDate'))
       filterFromDate = '"{}"'.format(filterFromDate) 
       filterToDate = str(filterJson.get('filterToDate'))
       filterToDate = '"{}"'.format(filterToDate)
       status = "current"
       status = '"{}"'.format(status)
       
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='bstdb',
                             user='root',
                             password='mysqlCT5!')
       
       if filterCategory and filterCategory == "agent_name":
           sql_select_query = "select * from brandstoretracker where associate_name = " +filterValue + "and status = "+status
       elif filterCategory and filterCategory == "pitch_date":
           sql_select_query = "select * from brandstoretracker where date >= "+ filterFromDate + "and date <= "+filterToDate+ "and status = "+status
       else:
           sql_select_query = "select * from brandstoretracker where status = " + status
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:
               bstData.update({'brand_id':row[0].encode('utf-8').strip()})
           else:
               bstData.update({'brand_id':''})
           if row[1] is not None:  
               bstData.update({'brand_name':row[1].encode('utf-8').strip()})
           else:
               bstData.update({'brand_name':''})
           if row[2] is not None:
               bstData.update({'cts_poc':row[2].encode('utf-8').strip()})
           else:
               bstData.update({'cts_poc':''})
           if row[3] is not None:
               bstData.update({'ams_poc':row[3].encode('utf-8').strip()})
           else:
               bstData.update({'ams_poc':''})
           if row[4] is not None:
               bstData.update({'source_channel':row[4].encode('utf-8').strip()})
           else:
               bstData.update({'source_channel':''})
           if row[5] is not None:
               bstData.update({'brand_contact_name1':row[5].encode('utf-8').strip()})
           else:
               bstData.update({'brand_contact_name1':''})
           if row[6] is not None:
               bstData.update({'brand_contact_number1':row[6].encode('utf-8').strip()})
           else:
               bstData.update({'brand_contact_number1':''})
           if row[7] is not None:
               bstData.update({'brand_email_id1':row[7].encode('utf-8').strip()})
           else:
               bstData.update({'brand_email_id1':''})
           if row[8] is not None:
               bstData.update({'brand_contact_name2':row[8].encode('utf-8').strip()})
           else:
               bstData.update({'brand_contact_name2':''})
           if row[9] is not None:
               bstData.update({'brand_contact_number2':row[9].encode('utf-8').strip()})
           else:
               bstData.update({'brand_contact_number2':''})
           if row[10] is not None:
               bstData.update({'brand_email_id2':row[10].encode('utf-8').strip()})
           else:
               bstData.update({'brand_email_id2':''})
           if row[11] is not None:
               bstData.update({'brand_contact_name3':row[11].encode('utf-8').strip()})
           else:
               bstData.update({'brand_contact_name3':''})
           if row[12] is not None:
               bstData.update({'brand_contact_number3':row[12].encode('utf-8').strip()})
           else:
               bstData.update({'brand_contact_number3':''})
           if row[13] is not None:
               bstData.update({'brand_email_id3':row[13].encode('utf-8').strip()})
           else:
               bstData.update({'brand_email_id3':''})
           if row[14] != "":
               datetime_obj = changeDateFormat(row[14].encode('utf-8').strip())
               bstData.update({'pitch_date1_proposed_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'pitch_date1_proposed_date':''})
           if row[15] is not None:
               bstData.update({'pitch_date1_proposed_time':row[15].encode('utf-8').strip()})
           else:
               bstData.update({'pitch_date1_proposed_time':''})
           if row[16] != "":
               datetime_obj = changeDateFormat(row[16].encode('utf-8').strip())
               bstData.update({'pitch_date1_actual_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'pitch_date1_actual_date':''})
           if row[17] is not None:
               bstData.update({'pitch_date1_sub_issue':row[17].encode('utf-8').strip()})
           else:
               bstData.update({'pitch_date1_sub_issue':''})
           if row[18] != "":
               datetime_obj = changeDateFormat(row[18].encode('utf-8').strip())
               bstData.update({'pitch_date2_proposed_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'pitch_date2_proposed_date':''})
           if row[19] is not None:
               bstData.update({'pitch_date2_proposed_time':row[19].encode('utf-8').strip()})
           else:
               bstData.update({'pitch_date2_proposed_time':''})
           if row[20] != "":
               datetime_obj = changeDateFormat(row[20].encode('utf-8').strip())
               bstData.update({'pitch_date2_actual_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'pitch_date2_actual_date':''})
           if row[21] is not None:
               bstData.update({'pitch_date2_sub_issue':row[21].encode('utf-8').strip()})
           else:
               bstData.update({'pitch_date2_sub_issue':''})
           if row[22] != "":
               datetime_obj = changeDateFormat(row[22].encode('utf-8').strip())
               bstData.update({'training_date1_proposed_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date1_proposed_date':''})
           if row[23] is not None:
               bstData.update({'training_date1_proposed_time':row[23].encode('utf-8').strip()})
           else:
               bstData.update({'training_date1_proposed_time':''})
           if row[24] != "":
               datetime_obj = changeDateFormat(row[24].encode('utf-8').strip())
               bstData.update({'training_date1_actual_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date1_actual_date':''})
           if row[25] is not None:
               bstData.update({'training_date1_sub_issue':row[25].encode('utf-8').strip()})
           else:
               bstData.update({'training_date1_sub_issue':''})
           if row[26] != "":
               datetime_obj = changeDateFormat(row[26].encode('utf-8').strip())
               bstData.update({'training_date2_proposed_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date2_proposed_date':''})
           if row[27] is not None:
               bstData.update({'training_date2_proposed_time':row[27].encode('utf-8').strip()})
           else:
               bstData.update({'training_date2_proposed_time':''})
           if row[28] != "":
               datetime_obj = changeDateFormat(row[28].encode('utf-8').strip())
               bstData.update({'training_date2_actual_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date2_actual_date':''})
           if row[29] is not None:
               bstData.update({'training_date2_sub_issue':row[29].encode('utf-8').strip()})
           else:
               bstData.update({'training_date2_sub_issue':''})
           if row[30] != "":
               datetime_obj = changeDateFormat(row[30].encode('utf-8').strip())
               bstData.update({'training_date3_proposed_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date3_proposed_date':''})
           if row[31] is not None:
               bstData.update({'training_date3_proposed_time':row[31].encode('utf-8').strip()})
           else:
               bstData.update({'training_date3_proposed_time':''})
           if row[32] != "":
               datetime_obj = changeDateFormat(row[32].encode('utf-8').strip())
               bstData.update({'training_date3_actual_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date3_actual_date':''})
           if row[33] is not None:
               bstData.update({'training_date3_sub_issue':row[33].encode('utf-8').strip()})
           else:
               bstData.update({'training_date3_sub_issue':''})
           if row[34] != "":
               datetime_obj = changeDateFormat(row[34].encode('utf-8').strip())
               bstData.update({'training_date4_proposed_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date4_proposed_date':''})
           if row[35] is not None:
               bstData.update({'training_date4_proposed_time':row[35].encode('utf-8').strip()})
           else:
               bstData.update({'training_date4_proposed_time':''})
           if row[36] != "":
               datetime_obj = changeDateFormat(row[36].encode('utf-8').strip())
               bstData.update({'training_date4_actual_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date4_actual_date':''})
           if row[37] is not None:
               bstData.update({'training_date4_sub_issue':row[37].encode('utf-8').strip()})
           else:
               bstData.update({'training_date4_sub_issue':''})
           if row[38] != "":
               datetime_obj = changeDateFormat(row[38].encode('utf-8').strip())
               bstData.update({'training_date5_proposed_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date5_proposed_date':''})
           if row[39] is not None:
               bstData.update({'training_date5_proposed_time':row[39].encode('utf-8').strip()})
           else:
               bstData.update({'training_date5_proposed_time':''})
           if row[40] != "":
               datetime_obj = changeDateFormat(row[40].encode('utf-8').strip())
               bstData.update({'training_date5_actual_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'training_date5_actual_date':''})
           if row[41] is not None:
               bstData.update({'training_date5_sub_issue':row[41].encode('utf-8').strip()})
           else:
               bstData.update({'training_date5_sub_issue':''})
           if row[42] != "":
               datetime_obj = changeDateFormat(row[42].encode('utf-8').strip())
               bstData.update({'brand_store_submission_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'brand_store_submission_date':''})
           if row[43] != "":
               datetime_obj = changeDateFormat(row[43].encode('utf-8').strip())
               bstData.update({'brand_store_approval_date':datetime_obj.date().strftime('%m/%d/%Y')})
           else:
               bstData.update({'brand_store_approval_date':''})
           if row[44] is not None:
               bstData.update({'store_status':row[44].encode('utf-8').strip()})
           else:
               bstData.update({'store_status':''})
           if row[45] is not None:
               bstData.update({'additional_issue_sub_issue':row[45].encode('utf-8').strip()})
           else:
               bstData.update({'additional_issue_sub_issue':''})
           if row[46] is not None:
               bstData.update({'summary':row[46].encode('utf-8').strip()})
           else:
               bstData.update({'summary':''})
           if row[47] is not None:
               bstData.update({'associate_name':row[47].encode('utf-8').strip()})
           else:
               bstData.update({'associate_name':''})
           if row[50] is not None:
               bstData.update({'pitch_date1_remarks':row[50].encode('utf-8').strip()})
           else:
               bstData.update({'pitch_date1_remarks':''})
           if row[51] is not None:
               bstData.update({'pitch_date2_remarks':row[51].encode('utf-8').strip()})
           else:
               bstData.update({'pitch_date2_remarks':''})
           if row[52] is not None:
               bstData.update({'training_date1_remarks':row[52].encode('utf-8').strip()})
           else:
               bstData.update({'training_date1_remarks':''})
           if row[53] is not None:
               bstData.update({'training_date2_remarks':row[53].encode('utf-8').strip()})
           else:
               bstData.update({'training_date2_remarks':''})
           if row[54] is not None:
               bstData.update({'training_date3_remarks':row[54].encode('utf-8').strip()})
           else:
               bstData.update({'training_date3_remarks':''})
           if row[55] is not None:
               bstData.update({'training_date4_remarks':row[55].encode('utf-8').strip()})
           else:
               bstData.update({'training_date4_remarks':''})
           if row[56] is not None:
               bstData.update({'training_date5_remarks':row[56].encode('utf-8').strip()})
           else:
               bstData.update({'training_date5_remarks':''})
           if row[57] is not None:
               bstData.update({'contacted_date':row[57].encode('utf-8').strip()})
           else:
               bstData.update({'contacted_date':''})
           if row[58] is not None:
               bstData.update({'contacted_time':row[58].encode('utf-8').strip()})
           else:
               bstData.update({'contacted_time':''})
           if row[59] is not None:
               bstData.update({'request_type':row[59].encode('utf-8').strip()})
           else:
               bstData.update({'request_type':''})
           if row[60] is not None:
               bstData.update({'query_status':row[60].encode('utf-8').strip()})
           else:
               bstData.update({'query_status':''})
           if row[61] is not None:
               bstData.update({'query_remarks':row[61].encode('utf-8').strip()})			   
           else:
               bstData.update({'query_remarks':''})
           bstArr.append(bstData.copy())
       bst.update({"bst":bstArr})
       cursor.close()
       return jsonify(bst)
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")               
                        	
if __name__ == "__main__":
    context = ('amsjarvis.cognizant.com.crt', 'amsjarvis.cognizant.com.key')
    app.run(host='0.0.0.0', port=443, ssl_context=context,threaded=True)
    

