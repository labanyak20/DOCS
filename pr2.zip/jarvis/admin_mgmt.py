from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
from collections import OrderedDict
import json
import datetime
from flask import Blueprint
from helper import *

admin_mgmt_api = Blueprint('admin_mgmt_api', __name__)

with open('config.json','r') as f:
  data = json.load(f)
  
@admin_mgmt_api.route("/retrieve_attendance_data",methods=['POST'])
def retrieveattendanceData():
    try:
       attendanceJson = request.get_json() 	
       attendanceForm = OrderedDict()
       attendanceArr = []
       attendanceData = OrderedDict()
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='jarvis',
                             user='root',
                             password='mysqlCT5!')
       

       sql_select_query = "select * from agent_attendance"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:
               attendanceData.update({'AssociateId':row[0].encode('utf-8').strip()})
           else:
               attendanceData.update({'Date':''})
           if row[1] is not None:
               attendanceData.update({'Associate Name':row[1].encode('utf-8').strip()})
           else:
               attendanceData.update({'Agent Name':''})
           if row[2] is not None:
               attendanceData.update({'Email Id':row[2].encode('utf-8').strip()})
           else:
               attendanceData.update({'Brand ID':''})
           if row[3] is not None:
               attendanceData.update({'Login Time':row[3].encode('utf-8').strip()})
           else:
               attendanceData.update({'Brand Name':''})
           attendanceArr.append(attendanceData.copy())
       attendanceForm.update({"data":attendanceArr})
       cursor.close()
       #return jsonify(attendanceForm)
       return json.dumps(attendanceForm)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		