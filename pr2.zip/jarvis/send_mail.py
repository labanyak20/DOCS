import smtplib

def send_mail(emailId, OTP):
   body = body = 'Subject: OTP for AMS Jarvis.'+'\n\n' + 'Dear,' + '\n\nYour OTP to login to the Jarvis tool is : ' + str(OTP) + '\n\nThanks,\nJarvis Team'
   
   try:
      server = smtplib.SMTP('APACSMTP.CTS.COM',25)
      server.ehlo()        
      server.sendmail('SJarvis@cognizant.com', emailId, body)
   except Exception as e :
        print ("Unable to send the mail.", e)
   return "Success"  