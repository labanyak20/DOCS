from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
from collections import OrderedDict
import json
import datetime

with open('config.json','r') as f:
    data = json.load(f)

def retrieveAssociateDetails(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_database'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       sql_select_Query = "select * from associates"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       associateRole = None;
       for row in records:
           if associateId == str(row[0]):
               associateRole = str(row[2])   
       cursor.close()
       return associateRole
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")		


def retrieveAssociateName(associateId):
    try:
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_database'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       sql_select_Query = "select * from associates"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_Query)
       records = cursor.fetchall()
       associateName = None;
       for row in records:
           if associateId == str(row[0]):
               associateName = str(row[1])  
       cursor.close()
       return associateName
       
    except Exception as e :
        print ("Error while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")