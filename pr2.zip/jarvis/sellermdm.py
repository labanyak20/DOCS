from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
import datetime, calendar
from collections import OrderedDict
import json
import datetime
from flask import Blueprint
from helper import *

smdm_api = Blueprint('smdm_api', __name__)

with open('config.json','r') as f:
  data = json.load(f)
  
  

@smdm_api.route("/insertinto_seller_mdm",methods=['POST'])
def insertSellerMDM():
    try:
       sellerMDMJson = request.get_json()
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='sellermdmdb',
                             user='root',
                             password='mysqlCT5!')
							 
       merchantid = str(sellerMDMJson.get('merchantid'))
       sellername = str(sellerMDMJson.get('sellername'))
       teamname = str(sellerMDMJson.get('teamname'))
       monthlybudget = str(sellerMDMJson.get('monthlybudget'))
       casenotes1 = str(sellerMDMJson.get('casenotes1'))
       contacted = str(sellerMDMJson.get('contacted'))
       accessgranted = str(sellerMDMJson.get('accessgranted'))
       actioned = str(sellerMDMJson.get('actioned'))
       allocationDateToCTS = str(sellerMDMJson.get('allocationDateToCTS'))
       sellerpocPrimary = str(sellerMDMJson.get('sellerpocPrimary'))
       sellerpocSecondary = str(sellerMDMJson.get('sellerpocSecondary'))
       sellerphonePrimary = str(sellerMDMJson.get('sellerphonePrimary'))
       sellerphoneSecondary = str(sellerMDMJson.get('sellerphoneSecondary'))
       selleremailPrimary = str(sellerMDMJson.get('selleremailPrimary'))
       selleremailSecondary = str(sellerMDMJson.get('selleremailSecondary'))
       sellerStatus = str(sellerMDMJson.get('sellerStatus'))
       removedDate = str(sellerMDMJson.get('removedDate'))
       brandstore = str(sellerMDMJson.get('brandstore'))
       ctsAMName = str(sellerMDMJson.get('ctsAMName'))
       numberofsubbrands = str(sellerMDMJson.get('numberofsubbrands'))
       pitchedcredits = str(sellerMDMJson.get('pitchedcredits'))
       status = "current"
       associateName = retrieveAssociateName(session.get('associateId'))
       date = str(sellerMDMJson.get('date'))
       sql = "update sellermdm SET status = %s where merchantid = %s and status = %s" 
       val = ("history", merchantid, "current")	 
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       
       sql = """insert into sellermdm (merchantid,sellername,teamname,monthlybudget,casenotes,contacted,accessgranted,actioned,allocationDateToCTS,sellerpocPrimary,sellerpocSecondary,sellerphonePrimary,sellerphoneSecondary,selleremailPrimary,selleremailSecondary,sellerStatus,removedDate,brandstore,ctsAMName,numberofsubbrands,pitchedcredits,date,created_by,status) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        
       val = (merchantid,sellername,teamname,monthlybudget,casenotes1,contacted,accessgranted,actioned,allocationDateToCTS,sellerpocPrimary,sellerpocSecondary,sellerphonePrimary,sellerphoneSecondary,selleremailPrimary,selleremailSecondary,sellerStatus,removedDate,brandstore,ctsAMName,numberofsubbrands,pitchedcredits,date,associateName,status)	
       	   
       cursor = mySQLconnection.cursor()
       cursor.execute(sql,val)
       mySQLconnection.commit()
       cursor.close()
       return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

@smdm_api.route("/check_merchant_id",methods=['POST'])
def checkMerchantData():
    try:
       sellerMDMJson = request.get_json()	
       sellerData = {}
       merchantid = str(sellerMDMJson.get('merchantid').encode('utf-8').strip())
       status = "current"
       duplicate = "" 
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='sellermdmdb',
                             user='root',
                             password='mysqlCT5!')

       sql = "select * from sellermdm where merchantid = %s and status = %s"
       val = (merchantid, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql, val)
       records = cursor.fetchall()
       if(len(records) > 0):
           duplicate = "Seller already exists. Please modify the same!!"
       cursor.close()    
       return duplicate
           
    except Exception as e :
        print ("Error while checking seller details",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")                

@smdm_api.route("/retrieve_seller_data",methods=['POST'])
def retrievesellerData():
    try:
       sellerMDMJson = request.get_json()	
       sellerData = {}
       merchantid = str(sellerMDMJson.get('merchantid'))
       status = "current"    
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='sellermdmdb',
                             user='root',
                             password='mysqlCT5!')

       sql = "select * from sellermdm where merchantid = %s and status = %s"
       val = (merchantid, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql, val)
       records = cursor.fetchall()
       for row in records:
           
           if row[0] is not None:	   
               sellerData.update({'merchantid':row[0].encode('utf-8').strip()})
           else:
               sellerData.update({'merchantid':''})		   
           if row[1] is not None:	      
               sellerData.update({'sellername':row[1].encode('utf-8').strip()})
           else:
               sellerData.update({'sellername':''})			   
           if row[2] is not None:
               sellerData.update({'teamname':row[2].encode('utf-8').strip()})
           else:
               sellerData.update({'teamname':''})
           if row[3] is not None:
               sellerData.update({'monthlybudget':row[3].encode('utf-8').strip()})
           else:
               sellerData.update({'monthlybudget':''})
           if row[4] is not None:
               sellerData.update({'casenotes1':row[4].encode('utf-8').strip()})
           else:
               sellerData.update({'casenotes1':''})
           if row[5] is not None:
               sellerData.update({'contacted':row[5].encode('utf-8').strip()})
           else:
               sellerData.update({'contacted':''}) 	   
           if row[6] is not None:
               sellerData.update({'accessgranted':row[6].encode('utf-8').strip()})
           else:
               sellerData.update({'accessgranted':''})			   
           if row[7] is not None:
               sellerData.update({'actioned':row[7].encode('utf-8').strip()})
           else:
               sellerData.update({'actioned':''})			    
           if row[8] is not None:
               sellerData.update({'allocationDateToCTS':row[8].encode('utf-8').strip()})
           else:
               sellerData.update({'allocationDateToCTS':''})
           if row[9] is not None:
               sellerData.update({'sellerpocPrimary':row[9].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerpocPrimary':''})	   
           if row[10] is not None:
               sellerData.update({'sellerpocSecondary':row[10].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerpocSecondary':''})
           if row[11] is not None:
               sellerData.update({'sellerphonePrimary':row[11].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerphonePrimary':''})
           if row[12] is not None:
               sellerData.update({'sellerphoneSecondary':row[12].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerphoneSecondary':''})
           if row[13] is not None:
               sellerData.update({'selleremailPrimary':row[13].encode('utf-8').strip()})
           else:
               sellerData.update({'selleremailPrimary':''})
           if row[14] is not None:
               sellerData.update({'selleremailSecondary':row[14].encode('utf-8').strip()})
           else:
               sellerData.update({'selleremailSecondary':''})
           if row[15] is not None:
               sellerData.update({'sellerStatus':row[15].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerStatus':''})
           if row[16] is not None:
               sellerData.update({'removedDate':row[16].encode('utf-8').strip()})
           else:
               sellerData.update({'removedDate':''})
           if row[17] is not None:
               sellerData.update({'brandstore':row[17].encode('utf-8').strip()})
           else:
               sellerData.update({'brandstore':''})
           if row[18] is not None:
               sellerData.update({'ctsAMName':row[18].encode('utf-8').strip()}) 
           else:
               sellerData.update({'ctsAMName':''})
           if row[19] is not None:
               sellerData.update({'numberofsubbrands':row[19].encode('utf-8').strip()})
           else:
               sellerData.update({'numberofsubbrands':''})
           if row[20] is not None:
               sellerData.update({'pitchedcredits':row[20].encode('utf-8').strip()})
           else:
               sellerData.update({'pitchedcredits':''})
                            
       cursor.close()
       return jsonify(sellerData)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")
			
@smdm_api.route("/retrieve_seller_report",methods=['POST'])
def retrieveSellerReport():
    try:
       filterJson = request.get_json() 	
       seller = {}
       sellerArr = []
       sellerData = {}
       filterCategory = str(filterJson.get('filterCategory'))
       value = str(filterJson.get('filterValue'))
       filterValue = '"{}"'.format(value)  
       filterFromDate = str(filterJson.get('filterFromDate'))
       filterFromDate = '"{}"'.format(filterFromDate) 
       filterToDate = str(filterJson.get('filterToDate'))
       filterToDate = '"{}"'.format(filterToDate)
       status = "current"
       status = '"{}"'.format(status)
       
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='sellermdmdb',
                             user='root',
                             password='mysqlCT5!')
       
       if filterCategory and not filterCategory == "allocationDateToCTS" and not filterCategory == "sellerStatus":
           sql_select_query = "select * from sellermdm where "+filterCategory+ " = " +filterValue + "and status = "+status+" and sellerStatus = 'With CTS'"
       elif filterCategory and filterCategory == "allocationDateToCTS":
           sql_select_query = "select * from sellermdm where allocationDateToCTS >= "+ filterFromDate + "and allocationDateToCTS <= "+filterToDate+ "and status = "+status+" and sellerStatus = 'With CTS'"
       elif filterCategory and filterCategory == "sellerStatus":
           sql_select_query = "select * from sellermdm where "+filterCategory+ " = " +filterValue + "and status = "+status
       elif filterCategory and filterCategory == "team_name":
           sql_select_query = "select * from sellermdm where "+filterCategory+ " = " +filterValue + "and status = "+status		   
       else:
           sql_select_query = "select * from sellermdm where status = " + status + " and sellerStatus = 'With CTS'"
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records: 
           if row[0] is not None:	   
               sellerData.update({'merchantid':row[0].encode('utf-8').strip()})
           else:
               sellerData.update({'merchantid':''})		   
           if row[1] is not None:	      
               sellerData.update({'sellername':row[1].encode('utf-8').strip()})
           else:
               sellerData.update({'sellername':''})			   
           if row[2] is not None:
               sellerData.update({'teamname':row[2].encode('utf-8').strip()})
           else:
               sellerData.update({'teamname':''})
           if row[3] is not None:
               sellerData.update({'monthlybudget':row[3].encode('utf-8').strip()})
           else:
               sellerData.update({'monthlybudget':''})
           if row[4] is not None:
               sellerData.update({'casenotes1':row[4].encode('utf-8').strip()})
           else:
               sellerData.update({'casenotes1':''})
           if row[5] is not None:
               sellerData.update({'contacted':row[5].encode('utf-8').strip()})
           else:
               sellerData.update({'contacted':''}) 	   
           if row[6] is not None:
               sellerData.update({'accessgranted':row[6].encode('utf-8').strip()})
           else:
               sellerData.update({'accessgranted':''})			   
           if row[7] is not None:
               sellerData.update({'actioned':row[7].encode('utf-8').strip()})
           else:
               sellerData.update({'actioned':''})			    
           if row[8] is not None:
               sellerData.update({'allocationDateToCTS':row[8].encode('utf-8').strip()})
           else:
               sellerData.update({'allocationDateToCTS':''})
           if row[9] is not None:
               sellerData.update({'sellerpocPrimary':row[9].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerpocPrimary':''})	   
           if row[10] is not None:
               sellerData.update({'sellerpocSecondary':row[10].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerpocSecondary':''})
           if row[11] is not None:
               sellerData.update({'sellerphonePrimary':row[11].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerphonePrimary':''})
           if row[12] is not None:
               sellerData.update({'sellerphoneSecondary':row[12].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerphoneSecondary':''})
           if row[13] is not None:
               sellerData.update({'selleremailPrimary':row[13].encode('utf-8').strip()})
           else:
               sellerData.update({'selleremailPrimary':''})
           if row[14] is not None:
               sellerData.update({'selleremailSecondary':row[14].encode('utf-8').strip()})
           else:
               sellerData.update({'selleremailSecondary':''})
           if row[15] is not None:
               sellerData.update({'sellerStatus':row[15].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerStatus':''})
           if row[16] is not None:
               sellerData.update({'removedDate':row[16].encode('utf-8').strip()})
           else:
               sellerData.update({'removedDate':''})
           if row[17] is not None:
               sellerData.update({'brandstore':row[17].encode('utf-8').strip()})
           else:
               sellerData.update({'brandstore':''})
           if row[18] is not None:
               sellerData.update({'ctsAMName':row[18].encode('utf-8').strip()}) 
           else:
               sellerData.update({'ctsAMName':''})
           if row[19] is not None:
               sellerData.update({'numberofsubbrands':row[19].encode('utf-8').strip()})
           else:
               sellerData.update({'numberofsubbrands':''})
           if row[20] is not None:
               sellerData.update({'pitchedcredits':row[20].encode('utf-8').strip()})
           else:
               sellerData.update({'pitchedcredits':''})
           sellerArr.append(sellerData.copy())
       seller.update({"seller":sellerArr})
       cursor.close()
       return jsonify(seller)
 
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")			


@smdm_api.route("/retrieve_seller_details",methods=['POST'])
def retrievesellerDetails():
    try:
       sellerMDMJson = request.get_json()          
       sellerData = {}
       merchantid = str(sellerMDMJson.get('merchantid'))
       merchantid = '"{}"'.format(merchantid)
       status = "current" 	   
       mySQLconnection = mysql.connector.connect(host='localhost',
                             database='sellermdmdb',
                             user='root',
                             password='mysqlCT5!')

		   
       sql = "select * from sellermdm where merchantid = " + merchantid + " and status = 'current'"
       cursor = mySQLconnection .cursor()
       cursor.execute(sql)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:	   
               sellerData.update({'merchantid':row[0].encode('utf-8').strip()})
           else:
               sellerData.update({'merchantid':''})		   
           if row[1] is not None:	      
               sellerData.update({'sellername':row[1].encode('utf-8').strip()})
           else:
               sellerData.update({'sellername':''})			   
           if row[2] is not None:
               sellerData.update({'teamname':row[2].encode('utf-8').strip()})
           else:
               sellerData.update({'teamname':''})
           if row[3] is not None:
               sellerData.update({'monthlybudget':row[3].encode('utf-8').strip()})
           else:
               sellerData.update({'monthlybudget':''})
           if row[4] is not None:
               sellerData.update({'casenotes1':row[4].encode('utf-8').strip()})
           else:
               sellerData.update({'casenotes1':''})
           if row[5] is not None:
               sellerData.update({'contacted':row[5].encode('utf-8').strip()})
           else:
               sellerData.update({'contacted':''}) 	   
           if row[6] is not None:
               sellerData.update({'accessgranted':row[6].encode('utf-8').strip()})
           else:
               sellerData.update({'accessgranted':''})			   
           if row[7] is not None:
               sellerData.update({'actioned':row[7].encode('utf-8').strip()})
           else:
               sellerData.update({'actioned':''})			    
           if row[8] is not None:
               sellerData.update({'allocationDateToCTS':row[8].encode('utf-8').strip()})
           else:
               sellerData.update({'allocationDateToCTS':''})
           if row[9] is not None:
               sellerData.update({'sellerpocPrimary':row[9].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerpocPrimary':''})	   
           if row[10] is not None:
               sellerData.update({'sellerpocSecondary':row[10].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerpocSecondary':''})
           if row[11] is not None:
               sellerData.update({'sellerphonePrimary':row[11].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerphonePrimary':''})
           if row[12] is not None:
               sellerData.update({'sellerphoneSecondary':row[12].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerphoneSecondary':''})
           if row[13] is not None:
               sellerData.update({'selleremailPrimary':row[13].encode('utf-8').strip()})
           else:
               sellerData.update({'selleremailPrimary':''})
           if row[14] is not None:
               sellerData.update({'selleremailSecondary':row[14].encode('utf-8').strip()})
           else:
               sellerData.update({'selleremailSecondary':''})
           if row[15] is not None:
               sellerData.update({'sellerStatus':row[15].encode('utf-8').strip()})
           else:
               sellerData.update({'sellerStatus':''})
           if row[16] is not None:
               sellerData.update({'removedDate':row[16].encode('utf-8').strip()})
           else:
               sellerData.update({'removedDate':''})
           if row[17] is not None:
               sellerData.update({'brandstore':row[17].encode('utf-8').strip()})
           else:
               sellerData.update({'brandstore':''})
           if row[18] is not None:
               sellerData.update({'ctsAMName':row[18].encode('utf-8').strip()}) 
           else:
               sellerData.update({'ctsAMName':''})
           if row[19] is not None:
               sellerData.update({'numberofsubbrands':row[19].encode('utf-8').strip()})
           else:
               sellerData.update({'numberofsubbrands':''})
           if row[20] is not None:
               sellerData.update({'pitchedcredits':row[20].encode('utf-8').strip()})
           else:
               sellerData.update({'pitchedcredits':''})
  			   
       cursor.close()
       return jsonify(sellerData)

    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")