from flask import Flask, flash, redirect, render_template, request, session, abort, url_for,jsonify
import mysql.connector
from mysql.connector import Error
import os
import random
from datetime import datetime, timedelta
import datetime, calendar
from collections import OrderedDict
import json
import datetime
from flask import Blueprint
from helper import *

atf_api = Blueprint('atf_api', __name__)

with open('config.json','r') as f:
  data = json.load(f)


@atf_api.route("/insertinto_acquistion_team_form_data",methods=['POST'])
def insertIntoAcquistionTeamForm():
    try:
        acquistionteamJson = request.get_json()
        mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_acquistion'],
                            user=data['sql_userName'],
                            password=data['sql_password'])

        amazonPOC = str(acquistionteamJson.get('amazonPOC')) 
        brandid = str(acquistionteamJson.get('brandid')) 
        brandname = str(acquistionteamJson.get('brandname')) 
        category = str(acquistionteamJson.get('category'))
        contactpointname1 = str(acquistionteamJson.get('contactpointname1'))
        contactpointname2 = str(acquistionteamJson.get('contactpointname2'))
        contactpointname3 = str(acquistionteamJson.get('contactpointname3'))
        contact1 = str(acquistionteamJson.get('contact1'))
        contact2 = str(acquistionteamJson.get('contact2')) 
        contact3 = str(acquistionteamJson.get('contact3')) 
        contactemailid1 = str(acquistionteamJson.get('contactemailid1')) 
        contactemailid2 = str(acquistionteamJson.get('contactemailid2')) 
        contactemailid3 = str(acquistionteamJson.get('contactemailid3')) 
        appointmentcalldate = str(acquistionteamJson.get('appointmentcalldate')) 
        appointmentcallstatus = str(acquistionteamJson.get('appointmentcallstatus')) 
        pitchingdate = str(acquistionteamJson.get('pitchingdate')) 
        pitchingstatus = str(acquistionteamJson.get('pitchingstatus')) 
        registrationdate = str(acquistionteamJson.get('registrationdate')) 
        registrationstatus = str(acquistionteamJson.get('registrationstatus'))
        print registrationstatus
        paymentdate = str(acquistionteamJson.get('paymentdate')) 
        paymentstatus = str(acquistionteamJson.get('paymentstatus')) 
        launchdate = str(acquistionteamJson.get('launchdate')) 
        launchstatus = str(acquistionteamJson.get('launchstatus')) 
        rechargeamount = str(acquistionteamJson.get('rechargeamount')) 
        followupfor = str(acquistionteamJson.get('followupfor')) 
        followupdate = str(acquistionteamJson.get('followupdate')) 
        followuptime = str(acquistionteamJson.get('followuptime')) 
        developmentteamPOC = str(acquistionteamJson.get('developmentteamPOC')) 
        handoverdate = str(acquistionteamJson.get('handoverdate')) 
        casenotes = str(acquistionteamJson.get('casenotes')) 
        date = str(acquistionteamJson.get('date'))
        associateName = retrieveAssociateName(session.get('associateId'))
        status="current"
        sql = "update acquistionteamform SET status = %s where brandid = %s and status = %s" 
        val = ("history", brandid, "current")	 
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
       
        sql = """insert into acquistionteamform (amazonPOC,brandid,brandname,category,contactpointname1,contactpointname2,contactpointname3,contact1,contact2,contact3,contactemailid1,contactemailid2,contactemailid3,appointmentcalldate,appointmentcallstatus,pitchingdate,pitchingstatus,registrationdate,registrationstatus,paymentdate,paymentstatus,launchdate,launchstatus,rechargeamount,followupfor,followupdate,followuptime,developmentteamPOC,handoverdate,casenotes,date,status,createdby) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"""
        
        val = (amazonPOC,brandid,brandname,category,contactpointname1,contactpointname2,contactpointname3,contact1,contact2,contact3,contactemailid1,contactemailid2,contactemailid3,appointmentcalldate,appointmentcallstatus,pitchingdate,pitchingstatus,registrationdate,registrationstatus,paymentdate,paymentstatus,launchdate,launchstatus,rechargeamount,followupfor,followupdate,followuptime,developmentteamPOC,handoverdate,casenotes,date,status,associateName)	
       	   
        cursor = mySQLconnection.cursor()
        cursor.execute(sql,val)
        mySQLconnection.commit()
        cursor.close()
        return 'success'

    except Exception as e :
        print ("Exception occured while connecting to MySQL", e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")
            
@atf_api.route("/check_acquistion_team_form_for_duplicate",methods=['POST'])
def checkAcquistionTeamFormForDuplicate():
    try:
       brandJson = request.get_json()	
       brandData = {}
       brandId = str(brandJson.get('brandid').encode('utf-8').strip())
       status = "current"
       duplicate = "" 
       print brandId                            
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_acquistion'],
                            user=data['sql_userName'],
                            password=data['sql_password'])

       sql = "select * from acquistionteamform where brandid = %s and status = %s"
       val = (brandId, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql, val)
       records = cursor.fetchall()
       if(len(records) > 0):
           duplicate = "Brand already exists. Please modify the same!!"
       cursor.close()    
       return duplicate
           
    except Exception as e :
        print ("Error while checking brand details",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")              

@atf_api.route("/retrieve_acquistion_team_data", methods = ['POST'])
def retrieveAcquistionTeamData():
    try:
       filterJson = request.get_json()	
       atfData = {}
       brandId = str(filterJson.get('brandid'))
       status = "current"
    
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_acquistion'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       
       sql_select_query = "select * from acquistionteamform where brandid = %s and status = %s" 
       val = (brandId, "current")
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query, val)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:
               atfData.update({'amazonPOC':row[0].encode('utf-8').strip()})
           if row[1] is not None:  
               atfData.update({'brandid':row[1].encode('utf-8').strip()})
           if row[2] is not None:
               atfData.update({'brandname':row[2].encode('utf-8').strip()})
           if row[3] is not None:
               atfData.update({'category':row[3].encode('utf-8').strip()})
           if row[4] is not None:
               atfData.update({'contactpointname1':row[4].encode('utf-8').strip()})
           if row[5] is not None:
               atfData.update({'contactpointname2':row[5].encode('utf-8').strip()})
           if row[6] is not None:
               atfData.update({'contactpointname3':row[6].encode('utf-8').strip()})
           if row[7] is not None:
               atfData.update({'contact1':row[7].encode('utf-8').strip()})
           if row[8] is not None:
               atfData.update({'contact2':row[8].encode('utf-8').strip()})
           if row[9] is not None:
               atfData.update({'contact3':row[9].encode('utf-8').strip()})
           if row[10] is not None:
               atfData.update({'contactemailid1':row[10].encode('utf-8').strip()})
           if row[11] is not None:
               atfData.update({'contactemailid2':row[11].encode('utf-8').strip()})
           if row[12] is not None:
               atfData.update({'contactemailid3':row[12].encode('utf-8').strip()})
           if row[13] is not None:
               atfData.update({'appointmentcalldate':row[13].encode('utf-8').strip()})
           if row[14] is not None:
               atfData.update({'appointmentcallstatus':row[14].encode('utf-8').strip()})
           if row[15] is not None:
               atfData.update({'pitchingdate':row[15].encode('utf-8').strip()})
           if row[16] is not None:
               atfData.update({'pitchingstatus':row[16].encode('utf-8').strip()})
           if row[17] is not None:
               atfData.update({'registrationdate':row[17].encode('utf-8').strip()})
           if row[18] is not None:
               atfData.update({'registrationstatus':row[18].encode('utf-8').strip()})
           if row[19] is not None:
               atfData.update({'paymentdate':row[19].encode('utf-8').strip()})
           if row[20] is not None:
               atfData.update({'paymentstatus':row[20].encode('utf-8').strip()})
           if row[21] is not None:
               atfData.update({'launchdate':row[21].encode('utf-8').strip()})
           if row[22] is not None:
               atfData.update({'launchstatus':row[22].encode('utf-8').strip()})
           if row[23] is not None:
               atfData.update({'rechargeamount':row[23].encode('utf-8').strip()})
           if row[24] is not None:
               atfData.update({'followupfor':row[24].encode('utf-8').strip()})
           if row[25] is not None:
               atfData.update({'followupdate':row[25].encode('utf-8').strip()})
           if row[26] is not None:
               atfData.update({'followuptime':row[26].encode('utf-8').strip()})
           if row[27] is not None:
               atfData.update({'developmentteamPOC':row[27].encode('utf-8').strip()})
           if row[28] is not None:
               atfData.update({'handoverdate':row[28].encode('utf-8').strip()})
           if row[29] is not None:
               atfData.update({'casenotes':row[29].encode('utf-8').strip()})
           if row[30] is not None:
               atfData.update({'date':row[30].encode('utf-8').strip()})
           if row[32] is not None:
               atfData.update({'associateName':row[32].encode('utf-8').strip()})
                                       
                                   
       cursor.close()
       return jsonify(atfData)
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")

def add_months(sourcedate,months):
    month = sourcedate.month - 1 + months
    print month
    year = sourcedate.year + month / 12
    print year
    month = month % 12
    print month
    day = min(sourcedate.day,calendar.monthrange(year,month)[1])
    print day
    return datetime.date(year,month,day)

@atf_api.route("/retrieve_acquistion_team_report", methods = ['POST'])
def retrieveAcquistionTeamReport():
    try:
       filterJson = request.get_json()	
       atf = {}
       atfArr = []
       atfData = {}
       filterCategory = str(filterJson.get('filterCategory'))
       value = str(filterJson.get('filterValue'))
       filterValue = '"{}"'.format(value)  
       filterFromDate = str(filterJson.get('filterFromDate'))
       filterFromDate = '"{}"'.format(filterFromDate) 
       filterToDate = str(filterJson.get('filterToDate'))
       filterToDate = '"{}"'.format(filterToDate)
       status = "current"
       status = '"{}"'.format(status)
       
       mySQLconnection = mysql.connector.connect(host='localhost',
                            database=data['sql_acquistion'],
                            user=data['sql_userName'],
                            password=data['sql_password'])
       
            
       if filterCategory and filterCategory == "agent_name":
           sql_select_query = "select * from acquistionteamform where createdby = " +filterValue + "and status = "+status
           print sql_select_query
       elif filterCategory and filterCategory == "pitch_date":
           sql_select_query = "select * from acquistionteamform where date >= "+ filterFromDate + "and date <= "+filterToDate+ "and status = "+status
       else:
           sql_select_query = "select * from acquistionteamform where status = " + status
       
       cursor = mySQLconnection .cursor()
       cursor.execute(sql_select_query)
       records = cursor.fetchall()
       
       for row in records:
           if row[0] is not None:
               atfData.update({'amazonPOC':row[0].encode('utf-8').strip()})
           if row[1] is not None:  
               atfData.update({'brandid':row[1].encode('utf-8').strip()})
           if row[2] is not None:
               atfData.update({'brandname':row[2].encode('utf-8').strip()})
           if row[3] is not None:
               atfData.update({'category':row[3].encode('utf-8').strip()})
           if row[4] is not None:
               atfData.update({'contactpointname1':row[4].encode('utf-8').strip()})
           if row[5] is not None:
               atfData.update({'contactpointname2':row[5].encode('utf-8').strip()})
           if row[6] is not None:
               atfData.update({'contactpointname3':row[6].encode('utf-8').strip()})
           if row[7] is not None:
               atfData.update({'contact1':row[7].encode('utf-8').strip()})
           if row[8] is not None:
               atfData.update({'contact2':row[8].encode('utf-8').strip()})
           if row[9] is not None:
               atfData.update({'contact3':row[9].encode('utf-8').strip()})
           if row[10] is not None:
               atfData.update({'contactemailid1':row[10].encode('utf-8').strip()})
           if row[11] is not None:
               atfData.update({'contactemailid2':row[11].encode('utf-8').strip()})
           if row[12] is not None:
               atfData.update({'contactemailid3':row[12].encode('utf-8').strip()})
           if row[13] is not None:
               datevar=row[13].encode('utf-8').strip()
    
               datevar = add_months(datetime.datetime(*[int(item) for item in datevar.split('-')]), 1).strftime("%m-%d-%Y")
               
               atfData.update({'appointmentcalldate':datevar})
           if row[14] is not None:
               atfData.update({'appointmentcallstatus':row[14].encode('utf-8').strip()})
           if row[15] is not None:
               datevar1=row[15].encode('utf-8').strip()
               datevar1 = add_months(datetime.datetime(*[int(item) for item in datevar1.split('-')]), 1).strftime("%m-%d-%Y")              
               atfData.update({'pitchingdate':datevar1})
           if row[16] is not None:
               atfData.update({'pitchingstatus':row[16].encode('utf-8').strip()})
           if row[17] is not None:
               datevar2=row[17].encode('utf-8').strip()
               print datevar2
               datevar2 = add_months(datetime.datetime(*[int(item) for item in datevar2.split('-')]), 1).strftime("%m-%d-%Y")  
               print str(datevar2)
               atfData.update({'registrationdate':datevar2})
           if row[18] is not None:
               atfData.update({'registrationstatus':row[18].encode('utf-8').strip()})
           
           if row[19] is not None:
               atfData.update({'paymentdate':row[19].encode('utf-8').strip()})
           if row[20] is not None:
               atfData.update({'paymentstatus':row[20].encode('utf-8').strip()})
           if row[21] is not None:
               atfData.update({'launchdate':row[21].encode('utf-8').strip()})
           if row[22] is not None:
               atfData.update({'launchstatus':row[22].encode('utf-8').strip()})
           if row[23] is not None:
               atfData.update({'rechargeamount':row[23].encode('utf-8').strip()})
           if row[24] is not None:
               atfData.update({'followupfor':row[24].encode('utf-8').strip()})
           if row[25] is not None:
               atfData.update({'followupdate':row[25].encode('utf-8').strip()})
           if row[26] is not None:
               atfData.update({'followuptime':row[26].encode('utf-8').strip()})
           if row[27] is not None:
               atfData.update({'developmentteamPOC':row[27].encode('utf-8').strip()})
           if row[28] is not None:
               atfData.update({'handoverdate':row[28].encode('utf-8').strip()})
           if row[29] is not None:
               atfData.update({'casenotes':row[29].encode('utf-8').strip()})
           if row[30] is not None:
               atfData.update({'date':row[30].encode('utf-8').strip()})
           if row[32] is not None:
               atfData.update({'associateName':row[32].encode('utf-8').strip()})
           atfArr.append(atfData.copy())
       atf.update({"atf":atfArr})
       cursor.close()
       return jsonify(atf)
    except Exception as e :
        print ("Error while connecting to MySQL",e)
    finally:
        #closing database connection.
        if(mySQLconnection .is_connected()):
            mySQLconnection.close()
            print("MySQL connection is closed")